/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.novatronic.sixwsg.nextel.transaction.bucketBalanceSearchFactory;

import com.novatronic.formatter.FormatterFactory;
import com.novatronic.formatter.internal.InternalFormat;
import com.novatronic.sixwsg.nextel.sixasincrono.logging.BRKLogger;
import com.novatronic.sixwsg.nextel.transaction.bucketBalanceSearchFactory.TransactionBucketBalanceSearch;
import com.novatronic.proxyws.WS_BucketBalanceSearchStub;
import com.novatronic.proxyws.WS_BucketBalanceSearchStub.SearchBucketBalanceElement;
import com.novatronic.proxyws.WS_BucketBalanceSearchStub.SearchBucketBalanceResponseElement;

import java.rmi.RemoteException;

/**
 *
 * @author ebajalqui
 */
public abstract class TransactionBucketBalanceSearchImp implements TransactionBucketBalanceSearch {

    private static final String MSG_TIMEOUT = "TIME OUT - ERROR TELCO";
    private static final String ID_FORMATEADOR_SALIDA = "FormatoREMPPV";
    private static final String COD_TRANSACCION_APROBADA = "0";
    private static final String COD_ERROR_CONTENT = "1414";
    private static final String COD_ERROR_OUTPUT = "1415";
    private static final String COD_ERROR_RECEIVE_MESSAGE = "1413";
    private static final String COD_ERROR_UNEXPECTED = "1416";

    public SearchBucketBalanceResponseElement process(SearchBucketBalanceElement request, WS_BucketBalanceSearchStub proxy) throws Exception {
        try {
            return handle(request, proxy);
        } catch (Exception ex) {
            BRKLogger.msgError("", TransactionBucketBalanceSearchImp.class.getSimpleName(), " process ", "Error al Enviar Requerimiento", ex);
            throw ex;
        }
    }

    public SearchBucketBalanceElement generarRequest(InternalFormat requestIF) throws Exception {

        try {
            return generarBucketBalanceElement(requestIF);
        } catch (Exception e) {
            BRKLogger.msgError("", TransactionBucketBalanceSearchImp.class.getSimpleName(), " generarRequest ", "Error al Generar Requerimiento", e);
            throw e;
        }
    }

    public String generarResponse(SearchBucketBalanceResponseElement response, InternalFormat requestIF, FormatterFactory formatter) throws Exception {

        try {
            return generarTramaRespuesta(response, requestIF, formatter);
        } catch (Exception e) {
            BRKLogger.msgError("", TransactionBucketBalanceSearchImp.class.getSimpleName(), " generarResponse ", "Error al Generar Respuesta", e);
            throw e;
        }
    }

    public String sendReceiveData(String prCodeTransaccion, InternalFormat requerimientoIF, WS_BucketBalanceSearchStub proxyBucketBalanceSearch, FormatterFactory nextelFormatterFactory) throws Exception {

        String respuesta = "";
        SearchBucketBalanceElement request = null;

        request = generarRequest(requerimientoIF);

        SearchBucketBalanceResponseElement response = process(request, proxyBucketBalanceSearch);
        if (response != null || response.getResult() != null) {

            respuesta = generarResponse(response, requerimientoIF, nextelFormatterFactory);

        } else {

            respuesta = "";
            BRKLogger.msgDebug("", TransactionBucketBalanceSearchImp.class.getSimpleName(), " SendReceiveData", "Se obtuvo una respuesta Nula");

        }

        return respuesta;

    }

    protected abstract SearchBucketBalanceResponseElement handle(SearchBucketBalanceElement request, WS_BucketBalanceSearchStub proxy) throws RemoteException;

    protected abstract SearchBucketBalanceElement generarBucketBalanceElement(InternalFormat requestIF);

    protected abstract String generarTramaRespuesta(SearchBucketBalanceResponseElement response, InternalFormat requestIF, FormatterFactory formatter);
}
