/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.novatronic.sixwsg.nextel.sixasincrono.utils.factories;

import com.novatronic.sixwsg.nextel.sixbws.wsnextel.exception.TrxnException;
import com.novatronic.sixwsg.nextel.transactions.bucketBalanceWriteFactory.TransactionBucketBalanceWriteFactory;

import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 *
 * @author ebajalqui
 */
public class BinAdquirienteFactory {

    private static final Logger log = LoggerFactory.getLogger(TransactionBucketBalanceWriteFactory.class);
    private static Map<String, String> bines_adquiriente;
    private static final String CONF_BINES_ADQ = "bines_acq";
    private static final String BIN_ADQ = "bin.";

    public BinAdquirienteFactory() {
    }

    /**
     * Metodo que carga la configuracion para la fabrica de transacciones
     *
     * @param config - Properties que contiene la estructura de las
     * transacciones a configurar.
     */
    public static void init(Properties config) {
        String binesAdquiriente;
        String[] keys;

        binesAdquiriente = config.getProperty(CONF_BINES_ADQ);

        validateConf(config);

        bines_adquiriente = new HashMap<String, String>();

        log.trace("Configurando transacciones [{}]", binesAdquiriente);
        keys = binesAdquiriente.split(",");

        for (String key : keys) {

            addTransaction(key, config);
            log.debug("Transaccion configurada [ " + key + " ]");
        }

        log.debug("Transacciones configuradas [llaves={}, transacciones={}]", binesAdquiriente, bines_adquiriente);

    }

    private static void validateConf(Properties config) {
        if (!config.containsKey(CONF_BINES_ADQ)) {
            throw new TrxnException("Debe especificar los codigos de transacciones en la propiedad [" + CONF_BINES_ADQ + "]");
        }
    }

    private static void addTransaction(String key, Properties config) {
        String binAdqValue;
        try {

            validateConfTransaction(key, config);

            binAdqValue = config.getProperty(BIN_ADQ + key);

            log.trace("[{}] Nombre transaccion obtenida [{}={}]", new Object[]{key, BIN_ADQ + key, binAdqValue});

            bines_adquiriente.put(key, binAdqValue);
            log.trace("[{}] Transaccion agregada [{}]", key, binAdqValue);
        } catch (Exception e) {
            throw new TrxnException("No se pudo crear la transaccion [" + key + "]", e);
        }
    }

    private static void validateConfTransaction(String key, Properties config) {
        if (!config.containsKey(BIN_ADQ + key)) {
            throw new TrxnException("Debe especificar la configuracion para la transaccion [" + BIN_ADQ + key + "]");
        }
    }

    /**
     * Retorna transaccion de acuerdo a la llave especificada.
     *
     * @param key - Identificador de la transaccion
     * @return {@link Transaction}
     */
    public static String getValue(String key) {
        String binAdqValue;

        try {
            binAdqValue = bines_adquiriente.get(key);
            log.trace("[{}] Clase transaccion instanciada [{}]", key, binAdqValue);
            return binAdqValue;
        } catch (Exception e) {
            throw new TrxnException("No se pudo instanciar la transaccion [" + key + "]", e);
        }
    }

    public static Map<String, String> getListaBinesAdquiriente() {
        return bines_adquiriente;
    }

    public static void setTransactions(Map<String, String> listaBinesAdq) {
        BinAdquirienteFactory.bines_adquiriente = listaBinesAdq;
    }
}
