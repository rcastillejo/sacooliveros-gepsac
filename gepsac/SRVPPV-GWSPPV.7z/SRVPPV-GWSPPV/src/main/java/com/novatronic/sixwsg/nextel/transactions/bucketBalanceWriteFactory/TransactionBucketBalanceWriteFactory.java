package com.novatronic.sixwsg.nextel.transactions.bucketBalanceWriteFactory;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.novatronic.sixwsg.nextel.sixbws.wsnextel.exception.TrxnException;
import com.novatronic.sixwsg.nextel.transactions.bucketBalanceWriteFactory.TransactionBucketBalanceWrite;

/**
 *
 * @author ebajalqui
 */
public final class TransactionBucketBalanceWriteFactory {

    private static final Logger log = LoggerFactory.getLogger(TransactionBucketBalanceWriteFactory.class);
    private static Map<String, String> transactions;
    private static final String PREFIX_TRANSACCION = "com.novatronic.sixwsg.nextel.transaction.";

    private class Config {

        private static final String TRANSACTIONS = "transactionsBucketBalanceWrite";
        private static final String TRANSACTION = "transactionBucketBalanceWrite.";
    }

    private TransactionBucketBalanceWriteFactory() {
    }

    /**
     * Metodo que carga la configuracion para la fabrica de transacciones
     *
     * @param config - Properties que contiene la estructura de las
     * transacciones a configurar.
     */
    public static void init(Properties config) {
        String tnxs;
        String[] keys;

        tnxs = config.getProperty(Config.TRANSACTIONS);

        validateConf(config);

        transactions = new HashMap<String, String>();

        log.trace("Configurando transacciones [{}]", tnxs);
        keys = tnxs.split(",");

        for (String key : keys) {

            addTransaction(key, config);
            log.debug("Transaccion configurada [ " + key + " ]");
        }

        log.debug("Transacciones configuradas [llaves={}, transacciones={}]", tnxs, transactions);

    }

    private static void validateConf(Properties config) {
        if (!config.containsKey(Config.TRANSACTIONS)) {
            throw new TrxnException("Debe especificar los codigos de transacciones en la propiedad [" + Config.TRANSACTIONS + "]");
        }
    }

    private static void addTransaction(String key, Properties config) {
        String txnName;
        String className;
        try {

            validateConfTransaction(key, config);

            txnName = config.getProperty(Config.TRANSACTION + key);

            log.trace("[{}] Nombre transaccion obtenida [{}={}]", new Object[]{key, Config.TRANSACTION + key, txnName});

            className = PREFIX_TRANSACCION + txnName;
            log.trace("[{}] Agregando transaccion [{}]", key, className);

            transactions.put(key, className);
            log.trace("[{}] Transaccion agregada [{}]", key, className);
        } catch (Exception e) {
            throw new TrxnException("No se pudo crear la transaccion [" + key + "]", e);
        }
    }

    private static void validateConfTransaction(String key, Properties config) {
        if (!config.containsKey(Config.TRANSACTION + key)) {
            throw new TrxnException("Debe especificar la configuracion para la transaccion [" + Config.TRANSACTION + key + "]");
        }
    }

    /**
     * Retorna transaccion de acuerdo a la llave especificada.
     *
     * @param key - Identificador de la transaccion
     * @return {@link Transaction}
     */
    public static TransactionBucketBalanceWrite getInstance(String key) {
        String className;

        try {
            className = transactions.get(key);
            log.trace("[{}] Clase transaccion instanciada [{}]", key, className);
            return (TransactionBucketBalanceWrite) Class.forName(className).newInstance();
        } catch (Exception e) {
            throw new TrxnException("No se pudo instanciar la transaccion [" + key + "]", e);
        }
    }

    public static Map<String, String> getTransactions() {
        return transactions;
    }

    public static void setTransactions(Map<String, String> transactions) {
        TransactionBucketBalanceWriteFactory.transactions = transactions;
    }
}
