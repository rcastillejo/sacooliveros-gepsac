package com.novatronic.sixwsg.nextel.sixasincrono.server.filterImpl;

import com.novatronic.sixwsg.nextel.sixasincrono.server.FilterMessage;
import com.novatronic.sixwsg.nextel.sixasincrono.server.exception.FilterException;
import java.util.Properties;

/**
 * Clase que configura el filtro de BIN y realiza el filtrado de la trama
 *
 * @author Ricardo Castillejo Luna - NOVATRONIC SAC
 * @version 01.00.00
 * @since Created 23-11-2012 <br> <table border=1> <tr> <td
 * align='center'>Version</td> <td align='center'>Fecha</td> <td
 * align='center'>Modificado por</td><td align='center'>Metodo Modificado</td>
 * <td align='center'>Explicacion del cambio</td> </tr>
 * <tr><td>01.00.00</td><td>05-12-2012</td><td>Ricardo Castillejo Luna
 * (RCL)</td><td>todos</td><td>Refactorizacion de Código</td></tr> </table>
 */
public class BinFilterMessage implements FilterMessage {

    private String alias;
    private int binLength;

    /**
     * {@inheritDoc }
     */
    public void configure(Properties configuration) throws FilterException {
        try {
            this.binLength = Integer.parseInt(configuration.getProperty("binLength"));
        } catch (Exception e) {
            //No se ha hecho pruebas de cobertura para los casos alternos
            throw new FilterException("Longitud de BIN mal especificada", e);
        }
    }

    /**
     * {@inheritDoc }
     */
    public byte[] filterOut(byte[] message) throws FilterException {
        try {
            byte[] retorno = new byte[message.length - binLength];
            System.arraycopy(message, binLength, retorno, 0, retorno.length);
            return retorno;
        } catch (Exception e) {
            //No se ha hecho pruebas de cobertura para los casos alternos
            throw new FilterException("No se pudo aplicar filtro de salida", e);
        }
    }

    /**
     * {@inheritDoc }
     */
    public byte[] filterIn(byte[] message) throws FilterException {
        return message;
    }

    /**
     * {@inheritDoc }
     */
    public String getAlias() {
        if (alias != null && alias.trim().length() > 0) {
            return alias;
        } else {
            return BinFilterMessage.class.getName();
        }
    }

    /**
     * {@inheritDoc }
     */
    public void setAlias(String alias) {
        this.alias = alias;
    }
}
