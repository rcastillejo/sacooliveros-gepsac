/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.novatronic.sixwsg.nextel.sixbws.wsnextel.exception;

/**
 *
 * @author rcastillejo
 */
public class TrxnException extends RuntimeException{

    public TrxnException() {
    }

    public TrxnException(String message) {
        super(message);
    }

    public TrxnException(String message, Throwable cause) {
        super(message, cause);
    }

    public TrxnException(Throwable cause) {
        super(cause);
    }
    
}
