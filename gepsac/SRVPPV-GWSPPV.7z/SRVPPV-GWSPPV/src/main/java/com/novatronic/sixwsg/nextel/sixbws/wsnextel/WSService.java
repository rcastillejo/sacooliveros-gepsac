package com.novatronic.sixwsg.nextel.sixbws.wsnextel;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import com.novatronic.formatter.internal.InternalFormat;
import java.net.URL;
import java.util.Map;


/**
 *
 * @author rcastillejo
 */
public abstract class WSService<P> {

    private URL url;
    private String qname;
    private String serviceName;
    private String portClass;
    private P port;

    public abstract Map<String, String> call(InternalFormat requerimiento);

    public URL getUrl() {
        return url;
    }

    public void setUrl(URL url) {
        this.url = url;
    }

    public String getQname() {
        return qname;
    }

    public void setQname(String qname) {
        this.qname = qname;
    }

    public String getServiceName() {
        return serviceName;
    }

    public void setServiceName(String serviceName) {
        this.serviceName = serviceName;
    }

    public String getPortClass() {
        return portClass;
    }

    public void setPortClass(String portClass) {
        this.portClass = portClass;
    }

    public P getPort() {
        return port;
    }

    public void setPort(P port) {
        this.port = port;
    }
}
