/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.novatronic.sixwsg.nextel.transactions.chkConectivityPrepayReadFactory;

import com.novatronic.formatter.FormatterFactory;
import com.novatronic.formatter.internal.InternalFormat;
import com.novatronic.proxyws.WS_CheckConectivityPrepayReadStub;
import com.novatronic.proxyws.WS_CheckConectivityPrepayReadStub.ReadCheckConectivityPrepayElement;
import com.novatronic.proxyws.WS_CheckConectivityPrepayReadStub.ReadCheckConectivityPrepayResponseElement;

/**
 *
 * @author ebajalqui
 */
public interface TransactionChkConectivityPrepayRead {

    public ReadCheckConectivityPrepayResponseElement process(ReadCheckConectivityPrepayElement request, WS_CheckConectivityPrepayReadStub proxy) throws Exception;

    public ReadCheckConectivityPrepayElement generarRequest(InternalFormat requestIF) throws Exception;

    public String generarResponse(ReadCheckConectivityPrepayResponseElement response, InternalFormat requestIF, FormatterFactory formatter) throws Exception;

    public String sendReceiveData(String prCodeTransaccion, InternalFormat requerimientoIF, WS_CheckConectivityPrepayReadStub proxyCheckConectivityPrepayRead, FormatterFactory nextelFormatterFactory) throws Exception;
}
