/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.novatronic.sixwsg.nextel.transaction.bucketBalanceSearchFactory;

import com.novatronic.formatter.FormatterFactory;
import com.novatronic.formatter.internal.InternalFormat;
import com.novatronic.proxyws.WS_BucketBalanceSearchStub;
import com.novatronic.proxyws.WS_BucketBalanceSearchStub.SearchBucketBalanceElement;
import com.novatronic.proxyws.WS_BucketBalanceSearchStub.SearchBucketBalanceResponseElement;

/**
 *
 * @author ebajalqui
 */
public interface TransactionBucketBalanceSearch {

    public SearchBucketBalanceResponseElement process(SearchBucketBalanceElement request, WS_BucketBalanceSearchStub proxy) throws Exception;

    public SearchBucketBalanceElement generarRequest(InternalFormat requestIF) throws Exception;

    public String generarResponse(SearchBucketBalanceResponseElement response, InternalFormat requestIF, FormatterFactory formatter) throws Exception;

    public String sendReceiveData(String prCodeTransaccion, InternalFormat requerimientoIF, WS_BucketBalanceSearchStub proxyBucketBalanceSearch, FormatterFactory nextelFormatterFactory) throws Exception;
}
