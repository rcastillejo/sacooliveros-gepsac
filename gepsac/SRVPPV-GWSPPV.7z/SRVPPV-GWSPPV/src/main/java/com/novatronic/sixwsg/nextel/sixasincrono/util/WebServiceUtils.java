/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.novatronic.sixwsg.nextel.sixasincrono.util;

import java.util.Hashtable;

import com.novatronic.formatter.Formatter;
import com.novatronic.formatter.FormatterFactory;
import com.novatronic.formatter.internal.InternalFormat;
import com.novatronic.proxyws.WS_BucketBalanceSearchStub;
import com.novatronic.proxyws.WS_BucketBalanceSearchStub.BucketBalanceSearchOut;
import com.novatronic.proxyws.WS_BucketBalanceSearchStub.SearchBucketBalanceElement;
import com.novatronic.proxyws.WS_BucketBalanceSearchStub.SearchBucketBalanceResponseElement;
import com.novatronic.proxyws.WS_BucketBalanceWriteStub;
import com.novatronic.proxyws.WS_BucketBalanceWriteStub.BucketBalanceWriteOut;
import com.novatronic.proxyws.WS_BucketBalanceWriteStub.BucketBalancesOut;
import com.novatronic.proxyws.WS_BucketBalanceWriteStub.WriteBucketBalanceElement;
import com.novatronic.proxyws.WS_BucketBalanceWriteStub.WriteBucketBalanceResponseElement;
import com.novatronic.proxyws.WS_CheckConectivityPrepayReadStub;
import com.novatronic.proxyws.WS_CheckConectivityPrepayReadStub.CheckConectivityPrepayReadOut;
import com.novatronic.proxyws.WS_CheckConectivityPrepayReadStub.ReadCheckConectivityPrepayElement;
import com.novatronic.proxyws.WS_CheckConectivityPrepayReadStub.ReadCheckConectivityPrepayResponseElement;
import com.novatronic.sixwsg.entel.mapper.MapperFactory;
import com.novatronic.sixwsg.entel.mapper.PpvMapper;
import com.novatronic.sixwsg.nextel.sixasincrono.bd.SingletonBDClient;
import com.novatronic.sixwsg.nextel.sixasincrono.logging.BRKLogger;
import com.novatronic.sixwsg.nextel.sixasincrono.utils.factories.CodigoRespuestaFactory;
import com.novatronic.sixwsg.nextel.transaction.bucketBalanceSearchFactory.TransactionBucketBalanceSearch;
import com.novatronic.sixwsg.nextel.transaction.bucketBalanceSearchFactory.TransactionBucketBalanceSearchFactory;
import com.novatronic.sixwsg.nextel.transactions.bucketBalanceWriteFactory.TransactionBucketBalanceWrite;
import com.novatronic.sixwsg.nextel.transactions.bucketBalanceWriteFactory.TransactionBucketBalanceWriteFactory;
import com.novatronic.sixwsg.nextel.transactions.chkConectivityPrepayReadFactory.TransactionChkConectivityPrepayRead;
import com.novatronic.sixwsg.nextel.transactions.chkConectivityPrepayReadFactory.TransactionChkConectivityPrepayReadFactory;
import com.pe.nova.components.bd.BDStoredProgramReq;
import java.util.Properties;
import javax.ws.rs.core.MultivaluedMap;

/**
 *
 * @author ebajalqui
 */
public class WebServiceUtils {

    private static final String MSG_TIMEOUT = "TIME OUT - ERROR TELCO";
    private static final String ID_FORMATEADOR_SALIDA = "FormatoREMPPV";
    private static final String COD_TRANSACCION_APROBADA = "0";
    private static final String COD_ERROR_CONTENT = "1414";
    private static final String COD_ERROR_OUTPUT = "1415";
    private static final String COD_ERROR_RECEIVE_MESSAGE = "1413";
    private static final String COD_ERROR_UNEXPECTED = "1416";

    public WebServiceUtils() {
    }

    /**
     * Metodo que envia el objeto al web services BBVA (proxyws), creado para el
     * Gateway Web Services de Banca Móvil
     *
     * @param prCodeTransaccion
     *            - id de la transaccion
     * @param requerimientoIF
     *            - objeto a enviar
     * @return Object - objeto de respuesta del web services BBVA
     */
    public static String sendReceiveData(String prCodeTransaccion, InternalFormat requerimientoIF,
            WS_BucketBalanceSearchStub proxyBucketBalanceSearch,
            WS_BucketBalanceWriteStub proxyBucketBalanceWrite,
            WS_CheckConectivityPrepayReadStub proxyCheckConectivityPrepayRead,
            FormatterFactory nextelFormatterFactory) throws Exception {

        String respuesta = "";

        if (TransactionBucketBalanceSearchFactory.getTransactions().containsKey(prCodeTransaccion)) {

            TransactionBucketBalanceSearch transaccionBucketBalanceSearch = null;
            SearchBucketBalanceElement request = null;

            try {

                transaccionBucketBalanceSearch = TransactionBucketBalanceSearchFactory
                        .getInstance(prCodeTransaccion);
                BRKLogger.msgDebug("", WebServiceUtils.class.getSimpleName(), " SendReceiveData",
                        "Se Instancio la clase de Id [" + prCodeTransaccion + "] Tipo ["
                                + transaccionBucketBalanceSearch.getClass().getSimpleName() + "]");

            } catch (Exception e) {

                BRKLogger.msgError("", WebServiceUtils.class.getSimpleName(), " SendReceiveData ",
                        "Error al obtener instancia de la Transaccion", e);
                throw e;

            }

            request = transaccionBucketBalanceSearch.generarRequest(requerimientoIF);

            SearchBucketBalanceResponseElement response = transaccionBucketBalanceSearch.process(
                    request, proxyBucketBalanceSearch);
            if (response != null || response.getResult() != null) {

                if (response.getResult().getCodError().equals(COD_TRANSACCION_APROBADA)) {

                    respuesta = transaccionBucketBalanceSearch.generarResponse(response,
                            requerimientoIF, nextelFormatterFactory);

                } else {

                    String codRespValue = response.getResult().getCodError();

                    if (CodigoRespuestaFactory.getCodigosError().containsKey(codRespValue)) {

                        String mensajeError = CodigoRespuestaFactory.getMensajeError(response
                                .getResult().getCodError());
                        BRKLogger.msgDebug("", WebServiceUtils.class.getSimpleName(),
                                " SendReceiveData", mensajeError);

                        if (codRespValue.equals(COD_ERROR_CONTENT)
                                || codRespValue.equals(COD_ERROR_OUTPUT)
                                || codRespValue.equals(COD_ERROR_RECEIVE_MESSAGE)
                                || codRespValue.equals(COD_ERROR_UNEXPECTED)) {

                            respuesta = "";

                        } else {

                            if (!requerimientoIF.getValue("tip_msg").equals("0420")) {

                                Formatter formateador = nextelFormatterFactory
                                        .getFormatter(ID_FORMATEADOR_SALIDA);
                                InternalFormat respuestaErrorIF = FormaterUtils.generarTimeoutIF(
                                        requerimientoIF, MSG_TIMEOUT);
                                respuesta = formateador
                                        .getFrameFromInternalFormat(respuestaErrorIF).toString();

                            } else {

                                respuesta = "";

                            }

                        }

                    } else {

                        respuesta = "";

                    }
                }

            } else {

                respuesta = "";
                BRKLogger.msgDebug("", WebServiceUtils.class.getSimpleName(), " SendReceiveData",
                        "Se obtuvo una respuesta Nula");

            }

        } else {

            String tipMsgPrCode = requerimientoIF.getValue("tip_msg") + prCodeTransaccion;

            if (TransactionBucketBalanceWriteFactory.getTransactions().containsKey(tipMsgPrCode)) {

                TransactionBucketBalanceWrite transaccionBucketBalanceWrite = null;
                WriteBucketBalanceElement request = null;

                try {

                    transaccionBucketBalanceWrite = TransactionBucketBalanceWriteFactory
                            .getInstance(tipMsgPrCode);
                    BRKLogger.msgDebug("", WebServiceUtils.class.getSimpleName(),
                            " SendReceiveData", "Se Instancio la clase de Id [" + tipMsgPrCode
                                    + "] Tipo ["
                                    + transaccionBucketBalanceWrite.getClass().getSimpleName()
                                    + "]");

                } catch (Exception e) {

                    BRKLogger.msgError("", WebServiceUtils.class.getSimpleName(),
                            " SendReceiveData ", "Error al obtener instancia de la Transaccion", e);
                    throw e;
                }

                request = transaccionBucketBalanceWrite.generarRequest(requerimientoIF);
                WriteBucketBalanceResponseElement response = transaccionBucketBalanceWrite.process(
                        request, proxyBucketBalanceWrite);

                if (response != null || response.getResult() != null) {

                    if (response.getResult().getCodError().equals(COD_TRANSACCION_APROBADA)) {

                        respuesta = transaccionBucketBalanceWrite.generarResponse(response,
                                requerimientoIF, nextelFormatterFactory);

                    } else {

                        String codRespValue = response.getResult().getCodError();

                        if (CodigoRespuestaFactory.getCodigosError().containsKey(codRespValue)) {

                            String mensajeError = CodigoRespuestaFactory.getMensajeError(response
                                    .getResult().getCodError());
                            BRKLogger.msgDebug("", WebServiceUtils.class.getSimpleName(),
                                    " SendReceiveData", mensajeError);

                            if (codRespValue.equals(COD_ERROR_CONTENT)
                                    || codRespValue.equals(COD_ERROR_OUTPUT)
                                    || codRespValue.equals(COD_ERROR_RECEIVE_MESSAGE)
                                    || codRespValue.equals(COD_ERROR_UNEXPECTED)) {

                                respuesta = "";

                            } else {

                                if (!requerimientoIF.getValue("tip_msg").equals("0420")) {

                                    Formatter formateador = nextelFormatterFactory
                                            .getFormatter(ID_FORMATEADOR_SALIDA);
                                    InternalFormat respuestaErrorIF = FormaterUtils
                                            .generarTimeoutIF(requerimientoIF, MSG_TIMEOUT);
                                    respuesta = formateador.getFrameFromInternalFormat(
                                            respuestaErrorIF).toString();

                                } else {

                                    respuesta = "";

                                }

                            }

                        } else {

                            respuesta = "";

                        }
                    }

                } else {

                    if (!requerimientoIF.getValue("tip_msg").equals("0420")) {

                        Formatter formateadorSalidaError = nextelFormatterFactory
                                .getFormatter(ID_FORMATEADOR_SALIDA);
                        InternalFormat respuestaErrorIF = FormaterUtils.generarTimeoutIF(
                                requerimientoIF, MSG_TIMEOUT);
                        respuesta = formateadorSalidaError.getFrameFromInternalFormat(
                                respuestaErrorIF).toString();

                    } else {

                        respuesta = "";
                        BRKLogger.msgDebug("", WebServiceUtils.class.getSimpleName(),
                                " SendReceiveData", "Se obtuvo una respuesta Nula");

                    }
                }

            } else {

                if (TransactionChkConectivityPrepayReadFactory.getTransactions().containsKey(
                        prCodeTransaccion)) {

                    TransactionChkConectivityPrepayRead transaccionChkConectivityPrepayRead = null;
                    ReadCheckConectivityPrepayElement request = null;

                    try {

                        transaccionChkConectivityPrepayRead = TransactionChkConectivityPrepayReadFactory
                                .getInstance(prCodeTransaccion);
                        BRKLogger.msgDebug("", WebServiceUtils.class.getSimpleName(),
                                " SendReceiveData", "Se Instancio la clase de Id ["
                                        + prCodeTransaccion
                                        + "] Tipo ["
                                        + transaccionChkConectivityPrepayRead.getClass()
                                                .getSimpleName() + "]");

                    } catch (Exception e) {

                        BRKLogger.msgError("", WebServiceUtils.class.getSimpleName(),
                                " SendReceiveData ",
                                "Error al obtener instancia de la Transaccion", e);
                        throw e;

                    }

                    request = transaccionChkConectivityPrepayRead.generarRequest(requerimientoIF);
                    ReadCheckConectivityPrepayResponseElement response = transaccionChkConectivityPrepayRead
                            .process(request, proxyCheckConectivityPrepayRead);

                    if ((response != null) || response.getResult() != null) {

                        if (response.getResult().getCodError().equals(COD_TRANSACCION_APROBADA)) {

                            respuesta = transaccionChkConectivityPrepayRead.generarResponse(
                                    response, requerimientoIF, nextelFormatterFactory);

                        } else {

                            String codRespValue = response.getResult().getCodError();

                            if (CodigoRespuestaFactory.getCodigosError().containsKey(
                                    response.getResult().getCodError())) {

                                String mensajeError = CodigoRespuestaFactory
                                        .getMensajeError(response.getResult().getCodError());
                                BRKLogger.msgDebug("", WebServiceUtils.class.getSimpleName(),
                                        " SendReceiveData", mensajeError);

                                if (codRespValue.equals(COD_ERROR_CONTENT)
                                        || codRespValue.equals(COD_ERROR_OUTPUT)
                                        || codRespValue.equals(COD_ERROR_RECEIVE_MESSAGE)
                                        || codRespValue.equals(COD_ERROR_UNEXPECTED)) {

                                    respuesta = "";

                                } else {

                                    if (!requerimientoIF.getValue("tip_msg").equals("0420")) {

                                        Formatter formateador = nextelFormatterFactory
                                                .getFormatter(ID_FORMATEADOR_SALIDA);
                                        InternalFormat respuestaErrorIF = FormaterUtils
                                                .generarTimeoutIF(requerimientoIF, MSG_TIMEOUT);
                                        respuesta = formateador.getFrameFromInternalFormat(
                                                respuestaErrorIF).toString();

                                    } else {

                                        respuesta = "";

                                    }
                                }

                            } else {

                                respuesta = "";

                            }
                        }

                    } else {

                        respuesta = "";
                        BRKLogger.msgDebug("", WebServiceUtils.class.getSimpleName(),
                                " SendReceiveData", "Se obtuvo una respuesta Nula");

                    }

                }
            }
        }

        return respuesta;
    }

    public static String enviarReqRecibirRespuesta(String prCodeTransaccion,
            InternalFormat requerimientoIF, WS_BucketBalanceSearchStub proxyBucketBalanceSearch,
            WS_BucketBalanceWriteStub proxyBucketBalanceWrite,
            WS_CheckConectivityPrepayReadStub proxyCheckConectivityPrepayRead,
            FormatterFactory nextelFormatterFactory, String outputApp,
            String spBDBucketBalanceSearch, String spBDBucketBalanceWrite,
            String spBDChckConectivityPrepayRead) throws Exception {
        
        return enviarReqRecibirRespuesta(prCodeTransaccion, requerimientoIF, proxyBucketBalanceSearch, 
                proxyBucketBalanceWrite, proxyCheckConectivityPrepayRead, nextelFormatterFactory, 
                outputApp, spBDBucketBalanceSearch, spBDBucketBalanceWrite, spBDChckConectivityPrepayRead, 
                null, null, null);
        
    }

    
    public static String enviarReqRecibirRespuesta(String prCodeTransaccion,
            InternalFormat requerimientoIF, WS_BucketBalanceSearchStub proxyBucketBalanceSearch,
            WS_BucketBalanceWriteStub proxyBucketBalanceWrite,
            WS_CheckConectivityPrepayReadStub proxyCheckConectivityPrepayRead,
            FormatterFactory nextelFormatterFactory, String outputApp,
            String spBDBucketBalanceSearch, String spBDBucketBalanceWrite,
            String spBDChckConectivityPrepayRead, DTOSMSMessage smsPorEnviar, 
            MultivaluedMap reqKiwoxPorEnviar, Properties propiedades) throws Exception {

        String respuesta = "";
        if (TransactionBucketBalanceSearchFactory.getTransactions().containsKey(prCodeTransaccion)) {

            TransactionBucketBalanceSearch transaccionBucketBalanceSearch = null;

            try {
                transaccionBucketBalanceSearch = TransactionBucketBalanceSearchFactory
                        .getInstance(prCodeTransaccion);
                BRKLogger.msgDebug("", WebServiceUtils.class.getSimpleName(),
                        " EnviarReqRecibirRespuesta", "Se Instancio la clase de Id ["
                                + prCodeTransaccion + "] Tipo ["
                                + transaccionBucketBalanceSearch.getClass().getSimpleName() + "]");
            } catch (Exception e) {
                BRKLogger.msgError("", WebServiceUtils.class.getSimpleName(),
                        " EnviarReqRecibirRespuesta ",
                        "Error al obtener instancia de la Transaccion", e);
                throw e;
            }

            try {
                if (outputApp.equals(Constants.BD)) {
                    SearchBucketBalanceElement request;
                    SearchBucketBalanceResponseElement response;
                    BucketBalanceSearchOut item;
                    BDStoredProgramReq req;
                    Hashtable result;
                    // Consultando el secuencial de id de pago
                    req = new BDStoredProgramReq();

                    request = transaccionBucketBalanceSearch.generarRequest(requerimientoIF);
                    // Insertar pago
                    req.setId("BalanceSearch" + System.currentTimeMillis());
                    req.setSentencia(spBDBucketBalanceSearch);

                    req.setParametro("AV_COD_APP", request.getBucketBalanceSearchIn().getIdApp());
                    req.setParametro("AV_ID_PARAM", request.getBucketBalanceSearchIn()
                            .getAV_ID_PARAM());
                    req.setParametro("AV_DES_PARAM", request.getBucketBalanceSearchIn()
                            .getAV_DES_PARAM());
                    req.setParametro("AV_ALIAS_BUCKET", request.getBucketBalanceSearchIn()
                            .getAV_ALIAS_BUCKET());
                    BRKLogger.msgDebug(null, WebServiceUtils.class.getSimpleName(), "EnviarReqRecibirRespuesta", "Request: "+request.getBucketBalanceSearchIn().getIdApp()+"\n"+
                            request.getBucketBalanceSearchIn()
                            .getAV_ID_PARAM()+"\n"+
                            request.getBucketBalanceSearchIn()
                            .getAV_DES_PARAM()+"\n"+
                            request.getBucketBalanceSearchIn()
                            .getAV_ALIAS_BUCKET());
                    // ejecuta procedure
                    result = SingletonBDClient.execute(req);
                    BRKLogger.msgDebug(null, WebServiceUtils.class.getSimpleName(), "EnviarReqRecibirRespuesta", "Response: "+result);
                    response = new SearchBucketBalanceResponseElement();
                    item = new BucketBalanceSearchOut();
                    
                    String aux;
                    
                    item.setAV_PHONE_NUMBER(result.get("AV_PHONE_NUMBER")!=null && result.get("AV_PHONE_NUMBER").toString().equals("__VALOR_NULO")?null:(String)result.get("AV_PHONE_NUMBER"));
                    item.setAV_BUCKET_UNIT(result.get("AV_BUCKET_UNIT")!=null && result.get("AV_BUCKET_UNIT").toString().equals("__VALOR_NULO")?null:(String)result.get("AV_BUCKET_UNIT"));
                    item.setAF_BUCKET_BALANCE(Double
                            .parseDouble(result.get("AF_BUCKET_BALANCE") != null && !result.get("AF_BUCKET_BALANCE").toString().equals("__VALOR_NULO") ? result.get(
                                    "AF_BUCKET_BALANCE").toString() : "0"));
                    item.setAD_BUCKET_EXP_DATE(result.get("AD_BUCKET_EXP_DATE")!=null && result.get("AD_BUCKET_EXP_DATE").toString().equals("__VALOR_NULO")?null:(String) result.get("AD_BUCKET_EXP_DATE"));
                    item.setCodError(result.get("AV_ERR")==null || (result.get("AV_ERR")!=null && result.get("AV_ERR").toString().equals("__VALOR_NULO"))?"0":"9");                        
                    if(item.getCodError().equals("0")){                            
                        if(result.get("AV_MESSAGE")!=null && result.get("AV_MESSAGE").toString().equals("__VALOR_NULO")){
                            item.setErrMsg("OK");
                        }else{                                
                            item.setErrMsg(result.get("AV_MESSAGE")!=null?result.get("AV_MESSAGE").toString():"");
                        }
                    }else{                                                    
                        item.setErrMsg(result.get("AV_ERR").toString()+" - "+(result.get("AV_MESSAGE")!=null && !result.get("AV_MESSAGE").toString().equals("__VALOR_NULO")?result.get("AV_MESSAGE").toString():""));
                    }

                    response.setResult(item);
                    
                    respuesta = transaccionBucketBalanceSearch.generarResponse(response,
                            requerimientoIF, nextelFormatterFactory);

                } else {
                    respuesta = transaccionBucketBalanceSearch.sendReceiveData(prCodeTransaccion,
                            requerimientoIF, proxyBucketBalanceSearch, nextelFormatterFactory);
                }
                BRKLogger.msgDebug("", WebServiceUtils.class.getSimpleName(),
                        " EnviarReqRecibirRespuesta",
                        "Se Envio y Recibio Respuesta del Autorizador satisfactoriamente ");

            } catch (Exception e) {
                BRKLogger.msgError("", WebServiceUtils.class.getSimpleName(),
                        " EnviarReqRecibirRespuesta ",
                        "Error al Enviar Requerimiento - Recibir Respuesta", e);
                throw e;
            }

        } else {

            String tipMsgPrCode = requerimientoIF.getValue("tip_msg") + prCodeTransaccion;

            if (TransactionBucketBalanceWriteFactory.getTransactions().containsKey(tipMsgPrCode)) {

                TransactionBucketBalanceWrite transaccionBucketBalanceWrite = null;

                try {
                    transaccionBucketBalanceWrite = TransactionBucketBalanceWriteFactory
                            .getInstance(tipMsgPrCode);
                    BRKLogger.msgDebug("", WebServiceUtils.class.getSimpleName(),
                            " EnviarReqRecibirRespuesta", "Se Instancio la clase de Id ["
                                    + tipMsgPrCode + "] Tipo ["
                                    + transaccionBucketBalanceWrite.getClass().getSimpleName()
                                    + "]");
                } catch (Exception e) {
                    BRKLogger.msgError("", WebServiceUtils.class.getSimpleName(),
                            " EnviarReqRecibirRespuesta ",
                            "Error al obtener instancia de la Transaccion TransaccionBucketBalanceWrite "
                                    + tipMsgPrCode, e);
                    throw e;
                }

                try {
                    if (outputApp.equals(Constants.BD)) {
                        WriteBucketBalanceElement request;
                        WriteBucketBalanceResponseElement response;
                        BucketBalanceWriteOut item;
                        BucketBalancesOut balance;
                        BDStoredProgramReq req;
                        Hashtable result;
                        // Consultando el secuencial de id de pago

                        request = transaccionBucketBalanceWrite.generarRequest(requerimientoIF);

                        req = prepararTransaccionBD("BalanceWrite" + System.currentTimeMillis(),spBDBucketBalanceWrite,request);
                        BRKLogger.msgDebug(null, WebServiceUtils.class.getSimpleName(), "EnviarReqRecibirRespuesta", "Request: "+req.getParametro("av_cod_app")+"\n"+
                                req.getParametro("av_bucket_unit")+"\n"+
                                req.getParametro("av_bucket_operation")+"\n"+
                                req.getParametro("av_id_param")+"\n"+
                                req.getParametro("av_des_param")+"\n"+
                                req.getParametro("av_bucket_alias")+"\n"+
                                req.getParametro("av_operation_date")+"\n"+
                                req.getParametro("av_operation_num")+"\n"+
                                req.getParametro("av_operation_num_orig")+"\n"+
                                req.getParametro("an_recharge_amount")+"\n"+
                                req.getParametro("av_entity_code")+"\n"+
                                req.getParametro("av_operation_carem")+"\n"+
                                req.getParametro("av_username")+"\n");
                        // ejecuta procedure
                        
                        
                        BRKLogger.msgDebug(null, WebServiceUtils.class.getSimpleName(), "error123456 ", "monto: "+req.getParametro("an_recharge_amount"));
                        
                        result = SingletonBDClient.execute(req);             
                        
                        BRKLogger.msgDebug(null, WebServiceUtils.class.getSimpleName(), "EnviarReqRecibirRespuesta", "Response: "+result);
                        response = new WriteBucketBalanceResponseElement();
                        item = new BucketBalanceWriteOut();
                        balance = new BucketBalancesOut();
                        balance.setBUCKET_EXP_DATE(result.get("AV_BUCKET_EXP_DATE")!=null && result.get("AV_BUCKET_EXP_DATE").toString().equals("__VALOR_NULO")?null:(String) result.get("AV_BUCKET_EXP_DATE"));
                        balance.setMSG_REC(result.get("av_msg_rec")!=null && result.get("av_msg_rec").toString().equals("__VALOR_NULO")?null:(String) result.get("av_msg_rec"));
                        balance.setMSG_MKT(result.get("av_msg_mkt")!=null && result.get("av_msg_mkt").toString().equals("__VALOR_NULO")?null:(String) result.get("av_msg_mkt"));
                        balance.setOPERATION_ID(Long
                                .parseLong(result.get("AN_OPERATION_ID") != null && !result.get("AN_OPERATION_ID").toString().equals("__VALOR_NULO")  ? result
                                        .get("AN_OPERATION_ID").toString():"0"));
                        balance.setBUCKET_AMOUNT(Double
                                .parseDouble(result.get("AN_BUCKET_AMOUNT") != null && !result.get("AN_BUCKET_AMOUNT").toString().equals("__VALOR_NULO") ? result.get("AN_BUCKET_AMOUNT").toString():"0"));
                        balance.setBUCKET_BALANCE(Double.parseDouble(result
                                .get("AF_BUCKET_BALANCE") != null && !result.get("AF_BUCKET_BALANCE").toString().equals("__VALOR_NULO") ? result.get(
                                "AF_BUCKET_BALANCE").toString():"0"));                                                
                        item.setCodError(result.get("AV_ERR")==null || (result.get("AV_ERR")!=null && result.get("AV_ERR").toString().equals("__VALOR_NULO"))?"0":"9");                        
                        if(item.getCodError().equals("0")){                            
                            if(result.get("AV_MESSAGE")!=null && result.get("AV_MESSAGE").toString().equals("__VALOR_NULO")){
                                item.setErrMsg("OK");
                            }else{                                
                                item.setErrMsg(result.get("AV_MESSAGE")!=null?result.get("AV_MESSAGE").toString():"");
                            }
                        }else{                                                        
                            item.setErrMsg(result.get("AV_ERR").toString()+" - "+(result.get("AV_MESSAGE")!=null && !result.get("AV_MESSAGE").toString().equals("__VALOR_NULO")?result.get("AV_MESSAGE").toString():""));
                        }
                        //item.setErrMsg(result.get("AV_MESSAGE")!=null && result.get("AV_MESSAGE").toString().equals("__VALOR_NULO")?null:(String) result.get("AV_MESSAGE"));
                        item.setBucketBalancesOut(new BucketBalancesOut[] { balance });
                        response.setResult(item);
                        
                        
                        //BRKLogger.msgDebug(null, null, null,"SMSPOREnviar ["+smsPorEnviar+"]"+"tipMsgPrCode :["+tipMsgPrCode+"]");
                        if(smsPorEnviar!=null && tipMsgPrCode.equals("0200970000")){
                            //BRKLogger.msgDebug(null, null, null,"result : ["+result+"]");
                            if(result.get("AV_MSG_REC")!=null && !result.get("AV_MSG_REC").toString().equals("__VALOR_NULO") && result.get("AV_MSG_REC").toString().trim().length()>0){
                                
                                smsPorEnviar.setArea(propiedades.getProperty("webServiceSetArea"));
                                smsPorEnviar.setMensaje((String)result.get("AV_MSG_REC"));
                                
                                if(request.getBucketBalanceWriteIn().getDES_PARAM().length() == 11){
                                smsPorEnviar.setTelefono(request.getBucketBalanceWriteIn().getDES_PARAM());
                                }
                                if(request.getBucketBalanceWriteIn().getDES_PARAM().length() == 9){
                                    smsPorEnviar.setTelefono(propiedades.getProperty("PreFijoNumero")+request.getBucketBalanceWriteIn().getDES_PARAM());
                                }
                            } 
                        }
                        
                        respuesta = transaccionBucketBalanceWrite.generarResponse(response,
                                requerimientoIF, nextelFormatterFactory);

                    } else {
                        respuesta = transaccionBucketBalanceWrite.sendReceiveData(
                                prCodeTransaccion, requerimientoIF, proxyBucketBalanceWrite,
                                nextelFormatterFactory);
                    }
                    
                    createKiwoxMessage(tipMsgPrCode, reqKiwoxPorEnviar, requerimientoIF);
                    
                    BRKLogger.msgDebug("", WebServiceUtils.class.getSimpleName(),
                            " EnviarReqRecibirRespuesta",
                            "Se Envio y Recibio Respuesta del Autorizador satisfactoriamente ");
                } catch (Exception e) {
                    BRKLogger.msgError("", WebServiceUtils.class.getSimpleName(),
                            " EnviarReqRecibirRespuesta ",
                            "Error al Enviar Requerimiento - Recibir Respuesta", e);
                    throw e;
                }

            } else {

                if (TransactionChkConectivityPrepayReadFactory.getTransactions().containsKey(
                        prCodeTransaccion)) {

                    TransactionChkConectivityPrepayRead transaccionChkConectivityPrepayRead = null;

                    try {
                        transaccionChkConectivityPrepayRead = TransactionChkConectivityPrepayReadFactory
                                .getInstance(prCodeTransaccion);
                        BRKLogger.msgDebug("", WebServiceUtils.class.getSimpleName(),
                                " EnviarReqRecibirRespuesta", "Se Instancio la clase de Id ["
                                        + prCodeTransaccion
                                        + "] Tipo ["
                                        + transaccionChkConectivityPrepayRead.getClass()
                                                .getSimpleName() + "]");
                    } catch (Exception e) {
                        BRKLogger.msgError("", WebServiceUtils.class.getSimpleName(),
                                " EnviarReqRecibirRespuesta ",
                                "Error al obtener instancia de la Transaccion", e);
                        throw e;
                    }

                    try {
                        if (outputApp.equals(Constants.BD)) {
                            ReadCheckConectivityPrepayResponseElement response;
                            CheckConectivityPrepayReadOut item;
                            BDStoredProgramReq req;
                            Hashtable result;
                            // Consultando el secuencial de id de pago
                            req = new BDStoredProgramReq();

                            // Insertar pago
                            req.setId("ChkConectivity" + System.currentTimeMillis());
                            req.setSentencia(spBDChckConectivityPrepayRead);
                            req.setParametro("av_cod_app", transaccionChkConectivityPrepayRead
                                    .generarRequest(requerimientoIF)
                                    .getCheckConectivityPrepayReadIn().getIdApp());
                            BRKLogger.msgDebug(
                                    "",
                                    WebServiceUtils.class.getSimpleName(),
                                    " EnviarReqRecibirRespuesta",
                                    "Request:"
                                            + transaccionChkConectivityPrepayRead
                                                    .generarRequest(requerimientoIF)
                                                    .getCheckConectivityPrepayReadIn().getIdApp());
                            // ejecuta procedure
                            result = SingletonBDClient.execute(req);
                            BRKLogger.msgDebug("", WebServiceUtils.class.getSimpleName(),
                                    " EnviarReqRecibirRespuesta", "Response:" + result);
                            response = new ReadCheckConectivityPrepayResponseElement();
                            item = new CheckConectivityPrepayReadOut();
                            item.setFcil(result.get("AV_FCIL")!=null && result.get("AV_FCIL").toString().equals("__VALOR_NULO")?null:(String) result.get("AV_FCIL"));                            
                            item.setCodError(result.get("AV_ERR")==null || (result.get("AV_ERR")!=null && result.get("AV_ERR").toString().equals("__VALOR_NULO"))?"0":"9");
                            item.setErrMsg(result.get("AV_MESSAGE")!=null && result.get("AV_MESSAGE").toString().equals("__VALOR_NULO")?null:(String) result.get("AV_MESSAGE"));
                            response.setResult(item);

                            respuesta = transaccionChkConectivityPrepayRead.generarResponse(
                                    response, requerimientoIF, nextelFormatterFactory);
                        } else {
                            respuesta = transaccionChkConectivityPrepayRead.sendReceiveData(
                                    prCodeTransaccion, requerimientoIF,
                                    proxyCheckConectivityPrepayRead, nextelFormatterFactory);
                        }
                        BRKLogger.msgDebug("", WebServiceUtils.class.getSimpleName(),
                                " EnviarReqRecibirRespuesta",
                                "Se Envio y Recibio Respuesta del Autorizador satisfactoriamente ");
                    } catch (Exception e) {
                        BRKLogger.msgError("", WebServiceUtils.class.getSimpleName(),
                                " EnviarReqRecibirRespuesta ",
                                "Error al Enviar Requerimiento - Recibir Respuesta", e);
                        throw e;
                    }

                }

            }

        }

        return respuesta;

    }

    private static BDStoredProgramReq prepararTransaccionBD(String id, String storedProcedure, WriteBucketBalanceElement request) {
        BDStoredProgramReq req = new BDStoredProgramReq();
        req.setId(id);

        req.setSentencia(storedProcedure);
        
        if (request.getBucketBalanceWriteIn().getIdApp() != null) {
            req.setParametro("av_cod_app", request.getBucketBalanceWriteIn().getIdApp());
        } else {
            req.setParametroNulo("av_cod_app");
        }
        if (request.getBucketBalanceWriteIn().getBUCKET_UNIT() != null) {
            req.setParametro("av_bucket_unit", request.getBucketBalanceWriteIn().getBUCKET_UNIT());
        } else {
            req.setParametroNulo("av_bucket_unit");
        }
        if (request.getBucketBalanceWriteIn().getBUCKET_OPERATION() != null) {
            req.setParametro("av_bucket_operation", request.getBucketBalanceWriteIn()
                    .getBUCKET_OPERATION());
        } else {
            req.setParametroNulo("av_bucket_operation");
        }
        if (request.getBucketBalanceWriteIn().getID_PARAM() != null) {
            req.setParametro("av_id_param", request.getBucketBalanceWriteIn().getID_PARAM());
        } else {
            req.setParametroNulo("av_id_param");
        }
        if (request.getBucketBalanceWriteIn().getDES_PARAM() != null) {
            req.setParametro("av_des_param", request.getBucketBalanceWriteIn().getDES_PARAM());
        } else {
            req.setParametroNulo("av_des_param");
        }
        if (request.getBucketBalanceWriteIn().getBUCKET_ALIAS() != null) {
            req.setParametro("av_bucket_alias", request.getBucketBalanceWriteIn().getBUCKET_ALIAS());
        } else {
            req.setParametroNulo("av_bucket_alias");
        }
        if (request.getBucketBalanceWriteIn().getOPERATION_DATE() != null) {
            req.setParametro("av_operation_date", request.getBucketBalanceWriteIn()
                    .getOPERATION_DATE());
        } else {
            req.setParametroNulo("av_operation_date");
        }
        if (request.getBucketBalanceWriteIn().getOPERATION_NUM() != null) {
            req.setParametro("av_operation_num", request.getBucketBalanceWriteIn()
                    .getOPERATION_NUM());
        } else {
            req.setParametroNulo("av_operation_num");
        }
        if (request.getBucketBalanceWriteIn().getOPERATION_NUM_ORIG() != null) {
            req.setParametro("av_operation_num_orig", request.getBucketBalanceWriteIn()
                    .getOPERATION_NUM_ORIG());
        } else {
            req.setParametroNulo("av_operation_num_orig");
        }
        req.setParametro("an_recharge_amount", request.getBucketBalanceWriteIn()
                .getRECHARGE_AMOUNT()+"");
        // SE MODIFICA EL MONTO

        if (request.getBucketBalanceWriteIn().getENTITY_CODE() != null) {
            req.setParametro("av_entity_code", request.getBucketBalanceWriteIn().getENTITY_CODE());
        } else {
            req.setParametroNulo("av_entity_code");
        }
        if (request.getBucketBalanceWriteIn().getOPERATION_CAREM() != null) {
            req.setParametro("av_operation_carem", request.getBucketBalanceWriteIn()
                    .getOPERATION_CAREM());
        } else {
            req.setParametroNulo("av_operation_carem");
        }
        if (request.getBucketBalanceWriteIn().getUSERNAME() != null) {
            req.setParametro("av_username", request.getBucketBalanceWriteIn().getUSERNAME());
        } else {
            req.setParametroNulo("av_username");
        }
        return req;
    }
    
        /**
         * Se realiza la llamada asincrona a kiwox para la operacion de recarga
         * (970000) de requerimiento (0200)
         */
    private static void createKiwoxMessage(String tipMsgPrCode, MultivaluedMap reqKiwoxPorEnviar, InternalFormat requerimientoIF) {
        if (reqKiwoxPorEnviar != null && tipMsgPrCode.equals("0200970000")) {
            PpvMapper mapper = MapperFactory.getMapper();
            String msisdn = mapper.getMsisdn(requerimientoIF.getValue("datos_ppv.numdoc"));
            String producto = mapper.getProducto(requerimientoIF.getValue("datos_ppv.codproc"));
            String monto = requerimientoIF.getValue("monto");
            String medioPago = mapper.getMedioPago(requerimientoIF.getValue("datos_ppv.med_pag"));
            String vendedor = requerimientoIF.getValue("datos_ppv.codvend");
            String institucion = requerimientoIF.getValue("datos_adquiriente_acreedor.codinst");
            String entidad = mapper.getEntidad(vendedor, institucion);
            String canal = mapper.getCanal(requerimientoIF.getValue("canal"));

            reqKiwoxPorEnviar.addFirst("msisdn", msisdn);
            reqKiwoxPorEnviar.addFirst("product", producto);
            reqKiwoxPorEnviar.addFirst("purchaseValue", monto);

            reqKiwoxPorEnviar.addFirst("paymentType", medioPago);
            reqKiwoxPorEnviar.addFirst("retailer", entidad);
            reqKiwoxPorEnviar.addFirst("branch", canal);
        }
    }
}
