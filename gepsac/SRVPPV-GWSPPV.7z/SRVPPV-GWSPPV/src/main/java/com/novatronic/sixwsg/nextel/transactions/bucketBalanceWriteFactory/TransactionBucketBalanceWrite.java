/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.novatronic.sixwsg.nextel.transactions.bucketBalanceWriteFactory;

import com.novatronic.formatter.FormatterFactory;
import com.novatronic.formatter.internal.InternalFormat;
import com.novatronic.proxyws.WS_BucketBalanceWriteStub;
import com.novatronic.proxyws.WS_BucketBalanceWriteStub.WriteBucketBalanceElement;
import com.novatronic.proxyws.WS_BucketBalanceWriteStub.WriteBucketBalanceResponseElement;

/**
 *
 * @author ebajalqui
 */
public interface TransactionBucketBalanceWrite {

    public WriteBucketBalanceResponseElement process(WriteBucketBalanceElement request, WS_BucketBalanceWriteStub proxy) throws Exception;

    public WriteBucketBalanceElement generarRequest(InternalFormat requestIF) throws Exception;

    public String generarResponse(WriteBucketBalanceResponseElement response, InternalFormat requestIF, FormatterFactory formatter) throws Exception;

    public String sendReceiveData(String prCodeTransaccion, InternalFormat requerimientoIF, WS_BucketBalanceWriteStub proxyBucketBalanceWrite, FormatterFactory nextelFormatterFactory) throws Exception;
}
