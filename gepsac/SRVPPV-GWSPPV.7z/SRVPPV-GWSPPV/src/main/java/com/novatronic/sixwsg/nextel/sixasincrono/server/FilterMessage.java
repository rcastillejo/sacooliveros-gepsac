package com.novatronic.sixwsg.nextel.sixasincrono.server;

import com.novatronic.sixwsg.nextel.sixasincrono.server.exception.FilterException;
import java.util.Properties;

/**
 * Esta interfaz sirve para las implementaciones de tratamientos de mensajes
 * para procesos Asincronos; segun el driver de donde provenga el requerimiento.
 * Se debe considerar las implementaciones de drivers asincronos son diferentes
 * presentandose los siguientes escenarios. 1. La interfaz asociada al driver
 * agrega un token que se incluyen antes del mensaje de requerimiento y debe ser
 * incluido tambien en el mensaje de respuesta. Es posible que el valor sea
 * validado. 2. La interfaz asociada al driver no modifica el mensaje. 3. La
 * interfaz asociada al driver agrega un valor en el requerimiento, el cual no
 * necesariamente debe ser incluido en la repuesta.
 *
 * Cada worker debe tener una instancia de un filtro. En la inicializacion del
 * worker debe instanciar y configurar el filtro. Los workers llaman al filtro
 * en caso este configurado: PRIMERO al metodo filterOut Antes de enviar el
 * mensaje al externo. SEGUNDO al metodo filterIn antes de devolver el mensaje
 * al Worker.
 *
 * @author Ricardo Castillejo Luna - NOVATRONIC SAC
 * @version 01.00.00
 * @since Created 23-11-2012 <br> <table border=1> <tr> <td
 * align='center'>Version</td> <td align='center'>Fecha</td> <td
 * align='center'>Modificado por</td><td align='center'>Metodo Modificado</td>
 * <td align='center'>Explicacion del cambio</td> </tr>
 * <tr><td>01.00.00</td><td>05-12-2012</td><td>Ricardo Castillejo Luna
 * (RCL)</td><td>todos</td><td>Refactorizacion de Código</td></tr> </table>
 *
 */
public interface FilterMessage {

    /**
     * Metodo para condifurar la instancia del filtro. Permite pasar desde la
     * configuracion los elementos necesarios para configurar el filtro, segun
     * sea necesario.
     *
     * @param configuration Propiedades de configuracion.
     */
    void configure(Properties configuration) throws FilterException;

    /**
     * Proceso previo antes de enviar el mensaje
     *
     * @param message Mensaje de la interfaz del driver
     * @return Mensaje a ser procesado
     */
    byte[] filterOut(byte[] message) throws FilterException;

    /**
     * Proceso inmediato despues de recibir el mensaje
     *
     * @param message Mensaje de respuesta del procesamiento
     * @return Mensaje a devolver a SIX
     */
    byte[] filterIn(byte[] message) throws FilterException;

    /**
     * Devuelde el alias del filtro
     *
     * @return
     */
    String getAlias();

    /**
     * Establece el alias del filtro
     *
     * @param alias
     */
    void setAlias(String alias);
}
