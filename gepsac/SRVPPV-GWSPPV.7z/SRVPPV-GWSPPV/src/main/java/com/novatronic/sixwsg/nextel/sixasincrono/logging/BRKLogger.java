/*
 * @(#)BRKLogger.java
 * Copyright (c) 2006 NOVATRONIC SAC
 * All rights reserved.
 * Creado el 22 de Febrero 2006
 */
package com.novatronic.sixwsg.nextel.sixasincrono.logging;

import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Properties;
import org.apache.log4j.BasicConfigurator;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

/**
 * Clase para la configuracion y mantenimiento del log para el componente
 *
 * @author Ricardo CastillejoMerino - NOVATRONIC SAC
 * @version 01.00.00
 * @since Creado 23-11-2012 <br> <table border=1> <tr> <td
 * align='center'>Version</td> <td align='center'>Fecha</td> <td
 * align='center'>Modificado por</td><td align='center'>Metodo Modificado</td>
 * <td align='center'>Explicacion del cambio</td> </tr>
 * <tr><td>01.00.00</td><td>05-12-2012</td><td>Ricardo Castillejo Luna
 * (RCL)</td><td>todos</td><td>Refactorizacion de Código</td></tr> </table>
 */
public final class BRKLogger {
    
    private BRKLogger(){}

    /**
     * Objeto de log para el trazado del componente
     */
    private static final Logger LOG_TRAZADO = Logger.getLogger("trazBRK");
    /**
     * Objeto de log para errores del componente
     */
    private static final Logger LOG_ERROR = Logger.getLogger("errBRK");
    /**
     * Objeto de log para performance del componente
     */
    private static final Logger LOG_PERFORMANCE = Logger.getLogger("perfBRK");

    /**
     * Objeto formateador de la fecha
     */
    /**
     * Bloque de inicializacion que carga y configura el log
     *
     * @param properties Objeto con los parametros de configuracion
     */
    public static void init(String properties) {

        try {
            //  Declara los objetos
            Properties prop = null;
            InputStream inputStream = null;

            //  Inicializa los objetos a utilizar
            prop = new Properties();
            inputStream = BRKLogger.class.getClassLoader().getResourceAsStream(properties);

            if (inputStream != null) {
                //  Carga las propiedades de configuracion para el log desde el archivo de propiedades
                prop.load(inputStream);

                // Aunque la siguiente linea no es repetitiva lo correcto es cerrar el InputStream
                inputStream.close();

                PropertyConfigurator.configure(prop);
            } else {
                //  Sino carga la configuracion por defecto del JDK
                BasicConfigurator.configure();
            }
        } catch (Exception e) {
        }

    }

    /**
     * Metodo que devuelve la referencia al log, con el nombre pasado
     *
     * @param name Nombre del log
     * @return Objeto Logger
     */
    public static Logger getLogger(String name) {

        return Logger.getLogger(name);
    }

    /**
     * Metodo que graba un registro de informacion en el log de trazado del
     * componente
     *
     * @param id Identificador de la operacion
     * @param clase Nombre de la clase desde donde se escribe en el log
     * @param metodo Nombre del metodo desde donde se escribe en el log
     * @param descripcion Informacion a escribir en el log
     */
    public static void msgInfo(String id,
            String clase,
            String metodo,
            String descripcion) {

        String mensaje = "";
        mensaje += id;
        mensaje += "\t";
        mensaje += clase;
        mensaje += "\t";
        mensaje += metodo;
        mensaje += "\t";
        mensaje += descripcion;
        LOG_TRAZADO.info(mensaje);
    }

    /**
     * Metodo que graba un registro para depuracion en el log de trazado del
     * componente
     *
     * @param id Identificador de la operacion
     * @param clase Nombre de la clase desde donde se escribe en el log
     * @param metodo Nombre del metodo desde donde se escribe en el log
     * @param descripcion Informacion a escribir en el log
     */
    public static void msgDebug(String id,
            String clase,
            String metodo,
            String descripcion) {

        String mensaje = "";
        mensaje += id;
        mensaje += "\t";
        mensaje += clase;
        mensaje += "\t";
        mensaje += metodo;
        mensaje += "\t";
        mensaje += descripcion;
        LOG_TRAZADO.debug(mensaje);
    }

    /**
     * Metodo que graba un registro de error en el log de errores y de trazado
     * del componente
     *
     * @param id Identificador de la operacion
     * @param clase Nombre de la clase desde donde se escribe en el log
     * @param metodo Nombre del metodo desde donde se escribe en el log
     * @param mensaje Mensaje descriptivo del error ocurrido
     * @param error Objeto throwable del error
     */
    public static void msgError(String id,
            String clase,
            String metodo,
            String mensaje,
            Throwable error) {

        String mensajeLog = "";
        mensajeLog += id;
        mensajeLog += "\t";
        mensajeLog += clase;
        mensajeLog += "\t";
        mensajeLog += metodo;
        mensajeLog += "\t";
        mensajeLog += mensaje;

        LOG_TRAZADO.error(mensajeLog);
        LOG_ERROR.error(mensajeLog, error);
    }

    /**
     * Metodo que graba un registro con los tiempos en el log de performance del
     * componente
     *
     * @param id Identificador de la operacion
     * @param nivel Numero indicando el nivel del metodo en el componente
     * @param clase Nombre de la clase desde donde se escribe en el log
     * @param metodo Nombre del metodo desde donde se escribe en el log
     * @param fechaInicio Fecha en que inicia el metodo
     * @param fechaFin Fecha en que termina el metodo
     */
    public static void msgPerf(String id,
            int nivel,
            String clase,
            String metodo,
            long fechaInicio,
            long fechaFin) {

        //  Inicializa el formato de la fecha para el log de performance
        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd HH:mm:ss:SSS");
        String mensaje = "";
        mensaje += id;
        mensaje += "\t";
        mensaje += nivel;
        mensaje += "\t";
        mensaje += clase;
        mensaje += "\t";
        mensaje += metodo;
        mensaje += "\t";
        mensaje += sdf.format(new Date(fechaInicio));
        mensaje += "\t";
        mensaje += sdf.format(new Date(fechaFin));
        mensaje += "\t";
        mensaje += (fechaFin - fechaInicio);
        LOG_PERFORMANCE.info(mensaje);
    }
}
