/*
 * @(#)Constants.java
 * Copyright (c) 2006 NOVATRONIC SAC
 * All rights reserved.
 * Creado el 3 de febrero del 2006
 */
package com.novatronic.sixwsg.nextel.sixasincrono.util;

/**
 * Clase con las constantes del Six Asincrono
 *
 * @author Ricardo Castillejo Luna - NOVATRONIC SAC
 * @version 01.00.00
 * @since Created 23-11-2012 <br> <table border=1> <tr> <td
 * align='center'>Version</td> <td align='center'>Fecha</td> <td
 * align='center'>Modificado por</td><td align='center'>Metodo Modificado</td>
 * <td align='center'>Explicacion del cambio</td> </tr>
 * <tr><td>01.00.00</td><td>05-12-2012</td><td>Ricardo Castillejo Luna
 * (RCL)</td><td>todos</td><td>Refactorizacion de Código</td></tr> </table>
 */
public final class Constants {

    private Constants() {
    }
    /**
     * Constantes de campo Formateador
     */
    public static final String C_I_PINBLOCK = "bmp.52";
    public static final String DA_PINBLOCK = "52";
    public static final String I_PRCODE = "3";
    //
    // Status
    //
    /**
     * Constante para el estado 'en proceso'
     */
    public static final String STATUS_PROCESS = "PROCESS";
    /**
     * Constante para el estado 'leyendo'
     */
    public static final String STATUS_READING = "READING";
    /**
     * Constante para el estado 'detenido'
     */
    public static final String STATUS_DOWN = "DOWN";
    /**
     * Constante para el estado 'iniciado'
     */
    public static final String STATUS_UP = "UP";
    //
    // Formatters
    //
    /**
     * Se agrego contantes para el proceso de Gateway Web Service Banca Móvil
     * Autor: Ricardo Castillejo Luna
     */
    /**
     * Constante para el formateador de transacción financiera de requerimiento
     */
    public static final String TF_TX_REQ = "0200";
    /**
     * Constante para el formateador de transacción financiera de respuesta
     */
    public static final String TF_TX_RES = "0210";
    /**
     * Constante para el tag inicial de la cabecera xml
     */
    public static final String OPENTAG_CABECERA = "<cabecera>";
    /**
     * Constante para el tag final de la cabecera xml
     */
    public static final String ENDTAG_CABECERA = "</cabecera>";
    /**
     * Constante para el tag inicial del detalle xml
     */
    public static final String OPENTAG_DETALLE = "<detalle>";
    /**
     * Constante para el tag final del detalle xml
     */
    public static final String ENDTAG_DETALLE = "</detalle>";
    /**
     * Constante para la longitud de caracteres del id de la transaccion
     */
    public static final int COD_PROC_LENGTH = 6;
    /**
     * Constante para convertir de milis a seg
     */
    public static final int MILIS = 1000;
    /**
     * Constante para el metodo run
     */
    public static final String METHOD_RUN = "run";
    /**
     * Constante para el metodo main
     */
    public static final String METHOD_MAIN = "main";
    /**
     * Mensaje de error al leer de la cola de API SIX
     */
    public static final String MSG_ERROR_APIXSIX_QUEUE = "Ocurrio un error en el mecanismo de lectura de la cola del API SIX";
    /**
     * Mensaje de error al escribir de los workers
     */
    public static final String MSG_ERROR_WRITE_WORKER_QUEUE = "Obtuvo falso al escribir en cola de workers";
    /**
     * Mensaje de error al escribir de los workers
     */
    public static final String MSG_ERROR_WORKER_QUEUE = "Obtuvo excepcion al escribir en cola de workers";
    /**
     * Mensaje de inicio para los hilos
     */
    public static final String MSG_RUN_START = "Iniciando hilo {0}";
    /**
     * Mensaje de fin para los hilos
     */
    public static final String MSG_RUN_END = "Finalizando hilo {0}";
    /**
     * Lista de Bines Adquieriente
     */
    public static final String BINES_ACQ = "bines_acq";
    /**
     * Lista de Bines Adquieriente
     */
    public static final String PREIFIJO_BIN_ACQ = "bin.";
    /*
     * Indicador de Certificado Habilitado
     */
    public static final String CERTIFICADO_HABILITADO = "1";
        /*
     * Indicador de Certificado Habilitado
     */
    public static final String METHOD_GENERAR_TRAMA_RESPUESTA = "generarTramaRespuesta";
    
    /**
     * Aplicacion de salida BD
     */
    public static final String BD = "BD";
    
    /**
     * Aplicacion de salida web service
     */
    public static final String WS = "WS";
    
    
    
    
}
