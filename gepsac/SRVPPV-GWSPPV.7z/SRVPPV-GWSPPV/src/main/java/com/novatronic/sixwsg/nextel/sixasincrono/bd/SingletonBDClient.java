package com.novatronic.sixwsg.nextel.sixasincrono.bd;

import java.util.Hashtable;
import java.util.Properties;

import org.apache.log4j.Logger;

import com.novatronic.sixwsg.nextel.sixasincrono.bd.exception.CompBDConfigurationException;
import com.pe.nova.components.bd.BDConnection;
import com.pe.nova.components.bd.BDConnectionFactory;
import com.pe.nova.components.bd.BDStoredProgramReq;
import com.pe.nova.components.bd.exception.BDException;
import com.pe.nova.components.bd.exception.RollBackTransactionException;

public class SingletonBDClient {

    private static final Logger log = Logger.getLogger(SingletonBDClient.class);

    private static BDConnectionFactory bdFactory = null;

    public synchronized static void init(Properties conexion, Properties pool) throws BDException {
        if (bdFactory == null) {
            bdFactory = BDConnectionFactory.createConnectionFactory(conexion, pool);
        }
    }

    public synchronized static void init(BDConnectionFactory bdFactoryImpl) {
        if (bdFactory == null) {
            if (bdFactoryImpl != null) {
                bdFactory = bdFactoryImpl;
            } else {
                throw new CompBDConfigurationException("La instancia proporcionada es nula");
            }
        }
    }

    public static BDConnection getBDConnection() throws BDException {
        if (bdFactory == null) {
            throw new CompBDConfigurationException("El componente de BD no ha sido configurado todavia."
                    + " invoque al metodo SingletonBDClientFactory.init()");
        } else {
            return bdFactory.getConnection();
        }
    }

    public synchronized static void destroy() {
        if (bdFactory != null) {
            try {
                bdFactory.destroy();
                bdFactory = null;
            } catch (BDException e) {
                log.error("No se pudo cerrar la conexion con la base de datos", e);
            }
        }
    }

    public static Hashtable execute(BDStoredProgramReq req) throws Exception{
    	String id = req.getId();
    	
        Hashtable hresult = null;
        BDConnection conn = null;
        try {
            conn = bdFactory.getConnection();
            conn.iniciarTransaccion();
            hresult = conn.execute(req);
            conn.commitTransaccion();
		} catch (Exception e) {
			if(conn!=null){
				try {
					conn.rollbackTransaccion();
				} catch (RollBackTransactionException e1) {
					log.warn("["+id+"]No pudo hacer rollback de la transaccion",e1);
				}
			}
			throw e;
		}finally{
			if(conn!=null){
				try {
					conn.close();
				} catch (BDException e) {
					log.warn("["+id+"]No pudo devolverla conexion al pool", e);
				}
			}
		}
        return hresult;
    }
}
