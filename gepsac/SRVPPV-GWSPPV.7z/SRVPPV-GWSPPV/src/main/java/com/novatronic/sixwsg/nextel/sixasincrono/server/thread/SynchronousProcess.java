package com.novatronic.sixwsg.nextel.sixasincrono.server.thread;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.text.MessageFormat;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Properties;
import java.util.regex.Pattern;

import org.apache.axis2.AxisFault;

import com.novatronic.formatter.Formatter;
import com.novatronic.formatter.FormatterFactory;
import com.novatronic.formatter.exception.FormatterException;
import com.novatronic.formatter.internal.InternalFormat;
import com.novatronic.proxyws.WS_BucketBalanceSearchStub;
import com.novatronic.proxyws.WS_BucketBalanceWriteStub;
import com.novatronic.proxyws.WS_CheckConectivityPrepayReadStub;
import com.novatronic.sixwsg.nextel.sixasincrono.logging.BRKLogger;
import com.novatronic.sixwsg.nextel.sixasincrono.logging.Identificador;
import com.novatronic.sixwsg.nextel.sixasincrono.server.Broker;
import com.novatronic.sixwsg.nextel.sixasincrono.server.Data;
import com.novatronic.sixwsg.nextel.sixasincrono.server.FilterMessage;
import com.novatronic.sixwsg.nextel.sixasincrono.server.exception.FilterException;
import com.novatronic.sixwsg.nextel.sixasincrono.util.Constants;
import com.novatronic.sixwsg.nextel.sixasincrono.util.DTOSMSMessage;
import com.novatronic.sixwsg.nextel.sixasincrono.util.KiwoxMessage;
import com.novatronic.sixwsg.nextel.sixasincrono.util.WebServiceUtils;
import java.util.concurrent.BlockingQueue;
import javax.ws.rs.core.MultivaluedHashMap;
import javax.ws.rs.core.MultivaluedMap;

/**
 * @author rromero
 *
 */
public class SynchronousProcess implements Runnable {

    /**
     * Constante con el nombre de la clase
     */
    public static final String onlyClassName = "SynchronousProcess";
    /**
     * constante de separacion dentro de los mensajes
     */
    private static final String CTE_SEPARADOR = "|";
    /**
     * Identificador de Formatrador de Entrada
     */
    private static final String ID_FORMATEADOR_ENTRADA = "FormatoPPVREM";
    /**
     * Variable indicadora para continuar la ejecucion del Hilo de la instancia
     * de broker
     */
    private boolean continuaBroker = true;
    /**
     * Mapa para de token sincrono
     */
    private Map<String, FilterMessage> filtersMap;
    private Map<String, Pattern> patronesSeleccionFiltro;
    private Map<String, String> mapeoInterfacesFiltrosMap;
    /**
     * Clase utilizada para el formateo de las tramas XML e ISO de requerimiento
     * y respuesta
     *
     */
    private FormatterFactory nextelPPVFormatFactory;
    private String requestInterface;
    /**
     * Clase para el proxyws
     */
    private WS_BucketBalanceSearchStub proxyBucketBalanceSearch;
    private WS_BucketBalanceWriteStub proxyBucketBalanceWrite;
    private WS_CheckConectivityPrepayReadStub proxyConectivityPrepayRead;
    private static final String MSG_THREADS_ENABLE = "Aceptamos transaccion. [{0}] transacciones en curso.";
    private static final String MSG_APISIX_SHUTDOWN = "Se recibe del SIX un mensaje de shutdown.";
    private static final String MSG_APISIX_TIMEOUT = "Timeout recibido mientras se espera leer requerimiento del SIX";
    private static final String MSG_APISIX_ERROR_CODE = "Codigo de retorno inesperado desde el SIX: rc({0})";
    private static final String MSG_APISIX_SEND = "Se leyeron [{0}]bytes del SIX. Interfaz solicitante [{1}]";
    private static final String MSG_THREAD_RELEASE = "Liberamos transaccion. [{0}] transacciones en curso.";
    private static final String MSG_THREAD_CAPABILITY_ERROR = "ADVERTENCIA. Transacciones en curso [{0}] no deberia ser menor a cero.";
    private static final String MSG_APISIX_RECV = "Se enviaron [{0}] bytes al SIX. rc({1}) con la interface [{2}]";
    private static final String MSG_TIMEOUT = "TIME OUT - ERROR TELCO";
    private static final String ID_FORMATEADOR_SALIDA = "FormatoREMPPV";
    /**
     * Clase que permite el manejo del API SIX
     */
    @SuppressWarnings("rawtypes")
    private final Class classApiSix;
    /**
     * Variable para referenciar instacia de API SIX
     */
    private Object instanceApiSix;
    private int brokerId;
    private String brokerName;
    private int numThreads;
    private short maxMsgLen;
    private int timeoutMiliSearchBucketBalance;
    private int timeoutMiliWriteBucketBalance;
    private int timeoutMiliChckConectivityPrepayRead;
    private String serverName;
    private int timeoutShutdownMili;
    private int timeForThreadsMili;
    private int brokerIntervalMili;
    private Identificador idf;
    private Data dataThread;
    /**
     * Objeto de token sincrono
     */
    private Object tokenSynchro;
    /**
     * Nombre de stored procedures para insercion a BD
     */
    private String spBDBucketBalanceSearch;
    private String spBDBucketBalanceWrite;
    private String spBDChckConectivityPrepayRead;
    
    private String outputApp;
    
    private BlockingQueue<DTOSMSMessage> colaSms;
    private BlockingQueue<KiwoxMessage> colaKiwox;
    private final Properties propiedades;
    
    /**
     * Metodo constructor de la clase, para una instancia en particular
     *
     * @param brkId Numero del hilo
     * @param brokerName Nombre del broker
     * @param numThreads Numero de threads
     * @param maxMsgLen Maximo longitud para el mensaje
     * @param serverName Nombre del servidor
     * @param timeForThreads Maximo tiempo de espera para finalizar threads
     * @param brokerInterval intervalo de esperas
     * @param spBDChckConectivityPrepayRead 
     * @param spBDBucketBalanceWrite 
     * @param spBDBucketBalanceSearch 
     * @param outputApp 
     * @param hostName Nombre del servidor
     */
    @SuppressWarnings("rawtypes")
    public SynchronousProcess(int brokerId, String brokerName, int numThreads,
            short maxMsgLen, int timeoutSearchBucketBalance, int timeoutWriteBucketBalance, int timeoutChckConectivityPrepayRead, String serverName, int timeForThreads, int brokerInterval,
            Class classApiSix, Data dataThread, String requestInterface, Object tokenSynchro,
            Map<String, Object> infoFiltros, FormatterFactory nextelFormatFactory, String urlWSBucketBalanceSearch, String urlWSBucketBalanceWrite, String urlWSChckConectivityPrepayRead, String spBDBucketBalanceSearch, String spBDBucketBalanceWrite, String spBDChckConectivityPrepayRead, 
            String outputApp, BlockingQueue<DTOSMSMessage> colaSms, BlockingQueue<KiwoxMessage> colaKiwox, Properties propiedades)
            throws InstantiationException, IllegalAccessException, ClassNotFoundException, AxisFault {

        this.brokerId = brokerId;
        this.brokerName = brokerName;
        this.numThreads = numThreads;
        this.maxMsgLen = maxMsgLen;
        this.timeoutMiliSearchBucketBalance = timeoutSearchBucketBalance * 1000;
        this.timeoutMiliWriteBucketBalance = timeoutWriteBucketBalance * 1000;
        this.timeoutMiliChckConectivityPrepayRead = timeoutChckConectivityPrepayRead * 1000;
        this.serverName = serverName;
        //this.timeoutShutdownMili = timeForShutdown * 1000;
        this.timeForThreadsMili = timeForThreads * 1000;
        this.brokerIntervalMili = brokerInterval * 1000;
        this.requestInterface = requestInterface;
        this.idf = Identificador.getInstance(this.brokerName);
        this.classApiSix = classApiSix;
        this.instanceApiSix = classApiSix.newInstance();
        this.dataThread = dataThread;
        this.tokenSynchro = tokenSynchro;
        this.colaSms = colaSms;
        this.colaKiwox = colaKiwox;
        
        this.propiedades = propiedades;

        if (infoFiltros != null) {
            this.mapeoInterfacesFiltrosMap = (Map<String, String>) infoFiltros.get("mapeoInterfacesFiltrosMap");

            this.patronesSeleccionFiltro = new LinkedHashMap<String, Pattern>();

            this.filtersMap = new HashMap<String, FilterMessage>();

            for (String regex : mapeoInterfacesFiltrosMap.keySet()) {
                Pattern pattern = Pattern.compile(regex);
                patronesSeleccionFiltro.put(regex, pattern);
            }

            Map<String, Properties> configFiltersMap = (Map<String, Properties>) infoFiltros.get("configFiltersMap");

            for (String aliasFiltro : configFiltersMap.keySet()) {
                Properties propiedadesFiltro = configFiltersMap.get(aliasFiltro);
                Class classFilter = Class.forName(propiedadesFiltro.getProperty("class"));
                FilterMessage filtro = (FilterMessage) classFilter.newInstance(); 
                filtro.setAlias(aliasFiltro);
                filtro.configure(propiedadesFiltro);
                filtersMap.put(aliasFiltro, filtro);
            }

        }

        this.nextelPPVFormatFactory = nextelFormatFactory; 
        
        this.outputApp = outputApp;
        
        if(outputApp.equals(Constants.BD)){
            this.spBDBucketBalanceSearch =spBDBucketBalanceSearch; 
            this.spBDBucketBalanceWrite = spBDBucketBalanceWrite; 
            this.spBDChckConectivityPrepayRead = spBDChckConectivityPrepayRead;            
        }else if(outputApp.equals(Constants.WS)){
            proxyBucketBalanceSearch = new WS_BucketBalanceSearchStub(urlWSBucketBalanceSearch);
            proxyBucketBalanceSearch._getServiceClient().getOptions().setTimeOutInMilliSeconds(timeoutMiliSearchBucketBalance);
    
            proxyBucketBalanceWrite = new WS_BucketBalanceWriteStub(urlWSBucketBalanceWrite);
            proxyBucketBalanceWrite._getServiceClient().getOptions().setTimeOutInMilliSeconds(timeoutMiliWriteBucketBalance);
    
            proxyConectivityPrepayRead = new WS_CheckConectivityPrepayReadStub(urlWSChckConectivityPrepayRead);
            proxyConectivityPrepayRead._getServiceClient().getOptions().setTimeOutInMilliSeconds(timeoutMiliChckConectivityPrepayRead);
        }
        
    }


    /**
     * Metodo con el contexto de ejecucion del hilo, realiza: <br> 1) La lectura
     * de un mensaje de SIX <br> 2) Arma y envia la trama del controlador <br>
     * 3) Recibe y desdobla la trama del controlador <br> 4) Escribe el mensaje
     * en el SIX <br>
     */
    @SuppressWarnings("unchecked")
    public void run() {

        int rc;
        BRKLogger.msgInfo(null, onlyClassName, "run", "Iniciando el thread[" + brokerId + "] de atencion");

        // ----------------------------------------------------------------------------------------------------------------------- //
        //
        // MAIN LOOP - PROCESS MESSAGES
        //
        // ----------------------------------------------------------------------------------------------------------------------- //
        //boolean sendMsgShutdown = true;
        String id = null;

        Field fieldHostName = null;
        Field fieldUserName = null;
        Field fieldMaxLen = null;
        Method method = null;
        Field fieldMesgData = null;
        Field fieldMesgLen = null;
        Field fieldServerName = null;
        Field fieldSixClose = null;

        short shortParamSIXRECV = -1;
        short shortParamSIXCLOSE = -1;
        short shortParamSIXSEND = -1;
        byte[] byteArrMensajeRespuesta = new byte[maxMsgLen];

        try {
            fieldHostName = classApiSix.getDeclaredField("host_name");
            fieldUserName = classApiSix.getDeclaredField("user_name");
            fieldMaxLen = classApiSix.getDeclaredField("max_len");
            method = classApiSix.getMethod("javasix_apiloc", short.class);
            fieldMesgData = classApiSix.getDeclaredField("mesg_data");
            shortParamSIXRECV = classApiSix.getDeclaredField("SIX_RCVREQ").getShort(null);
            fieldMesgLen = classApiSix.getDeclaredField("mesg_len");
            shortParamSIXSEND = classApiSix.getDeclaredField("SIX_SNDRSP").getShort(null);
            fieldServerName = classApiSix.getDeclaredField("serv_name");
            fieldSixClose = classApiSix.getDeclaredField("SIX_CLOSE");


        } catch (Exception e) {
            BRKLogger.msgError(id, AsynchronousReader.class.getSimpleName(), Constants.METHOD_RUN, Constants.MSG_ERROR_APIXSIX_QUEUE, e);
            return;
        }

        int longitudMensaje = -1;
        byte[] byteArrMessage;
        String requestingInterfaceFromSix;

        String paramUserNameAfterRead = null;

        while (continuaBroker && Broker.isContinuaTodoBroker()) {
            // -------------------------------------------------------------------------------------------------------------- //
            //
            // CALL SIX_RCVREQ FUNCTION (Receive request from SIX)
            //
            // -------------------------------------------------------------------------------------------------------------- //

            try {

                fieldHostName.set(this.instanceApiSix, "");
                fieldUserName.set(this.instanceApiSix, "");
                fieldMaxLen.setShort(this.instanceApiSix, (short) maxMsgLen);
                BRKLogger.msgDebug(null, onlyClassName, "run", "Esperando leer de la cola...");

                rc = ((Integer) method.invoke(instanceApiSix, shortParamSIXRECV)).intValue();

                paramUserNameAfterRead = (String) fieldUserName.get(instanceApiSix);
                BRKLogger.msgDebug(null, onlyClassName, "run", "UserName after read is [" + paramUserNameAfterRead + "]");

                synchronized (tokenSynchro) {
                    int txnEnCurso = Broker.getCurrentTransactions().incrementAndGet();
                    BRKLogger.msgDebug(null, AsynchronousReader.class.getSimpleName(), Constants.METHOD_RUN, MessageFormat.format(MSG_THREADS_ENABLE, new Object[]{txnEnCurso}));
                }

            } catch (Exception e) {

                BRKLogger.msgError(id, onlyClassName, Constants.METHOD_RUN, Constants.MSG_ERROR_APIXSIX_QUEUE, e);
                continuaBroker = false;
                continue;

            }

            id = idf.getCode();

            switch (rc) {
                case 0:
                    //                  SUCCESS
                    this.dataThread.setStatus(Constants.STATUS_PROCESS);
                    break;

                case 413:
                case -413:
                    //                  SHUTDOWN
                    BRKLogger.msgDebug(id, SynchronousProcess.class.getSimpleName(), Constants.METHOD_RUN, MSG_APISIX_SHUTDOWN);
                    continuaBroker = false;
                    Broker.shutdownControlador(id, numThreads, timeForThreadsMili, brokerIntervalMili);
                    continue;

                case 415:
                case -415:
                    //                  TIMEOUT
                    BRKLogger.msgDebug(id, SynchronousProcess.class.getSimpleName(), Constants.METHOD_RUN, MSG_APISIX_TIMEOUT);
                    this.dataThread.setStatus(Constants.STATUS_READING);
                    continue;

                default:
                    //                  DEFAULT
                    BRKLogger.msgDebug(id, SynchronousProcess.class.getSimpleName(), Constants.METHOD_RUN, MessageFormat.format(MSG_APISIX_ERROR_CODE, new Object[]{rc}));
                    continuaBroker = false;
                    continue;
            }
            //  Deja rastro del consumo de memoria en el log de performance
            BRKLogger.msgDebug(id, SynchronousProcess.class.getSimpleName(), Constants.METHOD_RUN, "MM:["
                    + Runtime.getRuntime().maxMemory() + "] " + "FM:["
                    + Runtime.getRuntime().freeMemory() + "] " + "TM:["
                    + Runtime.getRuntime().totalMemory() + "] " + "AT:["
                    + Thread.currentThread().getThreadGroup().activeCount()
                    + "]");

            //  Cadena leida

            try {
                longitudMensaje = fieldMaxLen.getInt(instanceApiSix);
                byteArrMessage = new byte[longitudMensaje];
                System.arraycopy((byte[]) fieldMesgData.get(instanceApiSix), 0, byteArrMessage, 0, longitudMensaje);
                requestingInterfaceFromSix = (String) fieldUserName.get(instanceApiSix);
                BRKLogger.msgDebug(id, SynchronousProcess.class.getSimpleName(), Constants.METHOD_RUN, "Interface obtenida [" + requestingInterfaceFromSix + "], Ijnterfaz parametrizada [" + this.requestInterface + "]");
                requestingInterfaceFromSix = this.requestInterface == null || this.requestInterface.isEmpty() ? requestingInterfaceFromSix : this.requestInterface;
                BRKLogger.msgDebug(id, SynchronousProcess.class.getSimpleName(), Constants.METHOD_RUN, MessageFormat.format(MSG_APISIX_SEND, new Object[]{longitudMensaje, requestingInterfaceFromSix}));
            } catch (Exception e1) {
                BRKLogger.msgError(id, SynchronousProcess.class.getSimpleName(), Constants.METHOD_RUN, Constants.MSG_ERROR_APIXSIX_QUEUE, e1);
                continuaBroker = false;
                continue;
            }

            long checkInBroker = System.currentTimeMillis();
            String tramaLeida = new String(byteArrMessage, 0, longitudMensaje);
            BRKLogger.msgDebug(id, onlyClassName, "run", "Trama de (" + longitudMensaje + ") bytes leida del SIX: [" + tramaLeida + "]");


            /*
             * PREPARACION de mensaje
             * Filtro de salida
             * 
             * Si no hay filtros no se hace nada con el mensajey se envia tal cual
             */

            FilterMessage filtroAAplicar = null;

            if (mapeoInterfacesFiltrosMap != null) {
                // Hay filtros
                // Identificamos la interfaz de donde viene
                // Evaluamos a que patron aplica
                for (String regex : patronesSeleccionFiltro.keySet()) {
                    Pattern pattern = patronesSeleccionFiltro.get(regex);
                    if (pattern.matcher(requestingInterfaceFromSix).matches()) {
                        filtroAAplicar = filtersMap.get(mapeoInterfacesFiltrosMap.get(regex));
                        BRKLogger.msgDebug(id, SynchronousProcess.class.getSimpleName(), Constants.METHOD_RUN, "Aplica por expresion regular [" + regex + "] Alias de filtro encontrado [" + filtroAAplicar.getAlias() + "]");
                        try {
                            byteArrMessage = filtroAAplicar.filterOut(byteArrMessage);
                        } catch (FilterException e) {
                            BRKLogger.msgError(id, SynchronousProcess.class.getSimpleName(), Constants.METHOD_RUN, "FilterException procesar mensaje antes de enviar", e);
                            continuaBroker = false;
                            continue;
                        }
                        break;
                    }
                }
                if (filtroAAplicar == null) {
                    BRKLogger.msgDebug(id, SynchronousProcess.class.getSimpleName(), Constants.METHOD_RUN, "No se encontro ningun filtro por aplicar a interfaz [" + requestingInterfaceFromSix + "]");
                }
            }

            // ----------------------------------------------------------------------------------------------------------------------- //
            //
            // RECEIVE RESPONSE MESSAGE (from Controlador Java)
            //
            // ----------------------------------------------------------------------------------------------------------------------- //
            short longitudTramaLeida;
            String mensajeEnviar;
            InternalFormat requerimientoIF = null;
            String tramaRespuestaGenerada = null;

            boolean esTimeOut = false;

            try {

                long checkOutToSCJ = System.currentTimeMillis();

                // 1. Se obtiene trama ISO a partir del arreglo de bytes obtenido del SIX
                mensajeEnviar = new String(byteArrMessage);
                BRKLogger.msgDebug(id, SynchronousProcess.class.getSimpleName(), Constants.METHOD_RUN, " trama ISO recibida = {" + mensajeEnviar + "}");


                //2. Convertir la trama ISO obtenida en el paso anterior a Internal Format
                Formatter formaterEntrada = nextelPPVFormatFactory.getFormatter(ID_FORMATEADOR_ENTRADA);

                try {

                    requerimientoIF = formaterEntrada.createInternalFormatFromFrame(mensajeEnviar);
                    BRKLogger.msgDebug(id, SynchronousProcess.class.getSimpleName(), Constants.METHOD_RUN, " internal format de la trama ISO leida = " + requerimientoIF + "");

                } catch (FormatterException fe) {
                    BRKLogger.msgError(id, SynchronousProcess.class.getSimpleName(), Constants.METHOD_RUN, "FormatterException al formatear mensaje ISO", fe);
                    throw fe;
                }
                

                String strTransaccion = requerimientoIF.getValue("prcode");
                Integer intTransaccion = Integer.valueOf(strTransaccion);

                BRKLogger.msgDebug(id, SynchronousProcess.class.getSimpleName(), Constants.METHOD_RUN, " strTransaccion = " + strTransaccion + ", transaccion = " + intTransaccion);
                //BRKLogger.msgDebug(id, Worker.class.getSimpleName(), Constants.METHOD_RUN, " enviando transaccion{" + intTransaccion + "} request{cabecera:" + request.getCabecera() + "}{detalle:" + request.getDetalle() + "}");
                //BRKLogger.msgDebug(id, Worker.class.getSimpleName(), Constants.METHOD_RUN, " recibido transaccion{" + intTransaccion + "} response{cabecera:" + response.getCabecera() + "}{detalle:" + response.getDetalle() + "}");

                //3. Se envía el requerimiento y se recibe la respuesta del Autorizador, con la cual se arma la trama xml                

                DTOSMSMessage smsPorEnviar = new DTOSMSMessage();
                MultivaluedMap reqKiwoxPorEnviar = new MultivaluedHashMap();
                
                tramaRespuestaGenerada = WebServiceUtils.enviarReqRecibirRespuesta(strTransaccion, requerimientoIF, 
                        proxyBucketBalanceSearch, proxyBucketBalanceWrite, proxyConectivityPrepayRead, nextelPPVFormatFactory, 
                        outputApp, spBDBucketBalanceSearch, spBDBucketBalanceWrite, spBDChckConectivityPrepayRead, smsPorEnviar,
                        reqKiwoxPorEnviar, this.propiedades);

                BRKLogger.msgDebug(id, SynchronousProcess.class.getSimpleName(), Constants.METHOD_RUN, " se armo la data aplicativa xml=" + tramaRespuestaGenerada);

                long checkInFromSCJ = System.currentTimeMillis();

                BRKLogger.msgPerf(id, 1, SynchronousProcess.class.getSimpleName(), "", checkOutToSCJ, checkInFromSCJ);

                if (tramaRespuestaGenerada == null || tramaRespuestaGenerada.isEmpty()) {
                    BRKLogger.msgError(id, SynchronousProcess.class.getSimpleName(), Constants.METHOD_RUN, "Longitud de la respuesta menor a cero. Descartaremos el mensaje simulando un timeout.", null);
                    byteArrMensajeRespuesta = new byte[0];
                    /*
                     * Identifico el escenario de TIMEOUT para no responder nada hacia el SIX
                     */

                    esTimeOut = true;
                } else {
                    //  Preparando el mensaje para escribir en el SIX
                    longitudTramaLeida = (short) tramaRespuestaGenerada.length();
                    BRKLogger.msgDebug(id, SynchronousProcess.class.getSimpleName(), Constants.METHOD_RUN, "Respuesta: [" + longitudTramaLeida + "] bytes recibidos del controlador.");

                    byteArrMensajeRespuesta = tramaRespuestaGenerada.getBytes();
                    
                    // Enviar SMS--rafa
                    // Add element in queue
                    BRKLogger.msgDebug(id, onlyClassName, Constants.METHOD_RUN, "Se solicita envio de SMS a numero["+smsPorEnviar+"]");
                    if(smsPorEnviar!=null && smsPorEnviar.getMensaje()!=null && smsPorEnviar.getMensaje().trim().length()>0){
                        this.colaSms.offer(smsPorEnviar);
                    }
                    
                    // Enviar Kiwox
                    // Add element in queue
                    BRKLogger.msgDebug(id, onlyClassName, Constants.METHOD_RUN, "Se solicita envio de Bono a kiwox a numero["+reqKiwoxPorEnviar+"]");
                    if(reqKiwoxPorEnviar != null && !reqKiwoxPorEnviar.isEmpty()){
                        this.colaKiwox.offer(new KiwoxMessage(id, reqKiwoxPorEnviar));
                    }
                }

            } catch (Exception e) {
                if (e.getCause() instanceof FormatterException) {

                    tramaRespuestaGenerada = "";
                    byteArrMensajeRespuesta = tramaRespuestaGenerada.getBytes();
                    esTimeOut = true;

                } else {

                    BRKLogger.msgError(id, SynchronousProcess.class.getSimpleName(), Constants.METHOD_RUN, "ConnectTimeoutException al enviar o recibir mensaje de respuesta del controlador: [" + e.getMessage() + "]", e);

                    tramaRespuestaGenerada = "";
                    byteArrMensajeRespuesta = tramaRespuestaGenerada.getBytes();
                    esTimeOut = true;
                }
            } catch (Throwable e) {
                BRKLogger.msgError(id, SynchronousProcess.class.getSimpleName(), Constants.METHOD_RUN, "Throwable al enviar o recibir del web services: [" + e.getMessage() + "]", e);
                continuaBroker = false;
                /**
                 * Consultar, si hay un error, se decrece la cantidad de
                 * atencion o se mantiene, de ser mantenido y persistir esta
                 * excepcion lo mas probable es que llegue en un momento e que
                 * dejara de atender
                 */
                continue;
            }

            /**
             * Fin de la modificacion para el Gateway Web Services de Banca
             * Móvil
             *
             * Autor: Ricardo Castillejo Luna
             */
            /*
             * SI ES TIMEOUT
             * No mandamos Nada de regreso al SIX
             * Tampoco confirmamos 
             */
            if (!esTimeOut) {

                /*
                 * Tratamiento de mensaje
                 * Filtro entrada
                 * 
                 * Si no hay filtros no se hace nada con el mensaje y se envia tal cual
                 */
                if (filtroAAplicar != null) {
                    try {
                        byteArrMensajeRespuesta = filtroAAplicar.filterIn(byteArrMensajeRespuesta);
                    } catch (FilterException e) {
                        BRKLogger.msgError(id, SynchronousProcess.class.getSimpleName(), Constants.METHOD_RUN, "FilterException procesar mensaje despues de recibir", e);
                        continuaBroker = false;
                        continue;
                    }
                }

            }

            /*
             * Reducimos los contadores de transacciones en curso
             */
            synchronized (tokenSynchro) {
                int txnEnCurso = Broker.getCurrentTransactions().decrementAndGet();
                if (txnEnCurso < 0) {
                    /*
                     * No deberia bajar menos de CERO, en todo caso, lo dejamos abierto para ver si pasa.
                     */
                    BRKLogger.msgError(id, SynchronousProcess.class.getSimpleName(), Constants.METHOD_RUN, MessageFormat.format(MSG_THREAD_CAPABILITY_ERROR, new Object[]{txnEnCurso}), null);
                } else {
                    tokenSynchro.notify();
                    BRKLogger.msgDebug(id, SynchronousProcess.class.getSimpleName(), Constants.METHOD_RUN, MessageFormat.format(MSG_THREAD_RELEASE, new Object[]{txnEnCurso}));
                }
            }

            // ----------------------------------------------------------------------------------------------------------------------- //
            //
            // CALL SIX_SNDRSP FUNCTION
            //
            // ----------------------------------------------------------------------------------------------------------------------- //       


            try {

                fieldMesgLen.setShort(instanceApiSix, (short) (byteArrMensajeRespuesta.length));
                System.arraycopy(byteArrMensajeRespuesta, 0, (byte[]) fieldMesgData.get(instanceApiSix), 0, byteArrMensajeRespuesta.length);

                rc = ((Integer) method.invoke(instanceApiSix, shortParamSIXSEND)).intValue();

                BRKLogger.msgDebug(id, SynchronousProcess.class.getSimpleName(), Constants.METHOD_RUN, "Trama de Respuesta: [" + tramaRespuestaGenerada + "] a enviar al SIX.");
                BRKLogger.msgDebug(id, SynchronousProcess.class.getSimpleName(), Constants.METHOD_RUN, MessageFormat.format(MSG_APISIX_RECV, byteArrMessage.length, rc, requestingInterfaceFromSix));

            } catch (Exception e1) {
                BRKLogger.msgError(id, SynchronousProcess.class.getSimpleName(), Constants.METHOD_RUN, Constants.MSG_ERROR_APIXSIX_QUEUE, e1);
                continuaBroker = false;
                continue;
            }

            long checkOutBroker = System.currentTimeMillis();
            BRKLogger.msgPerf(id, 0, SynchronousProcess.class.getSimpleName(), "", checkInBroker, checkOutBroker);
            this.dataThread.setStatus(Constants.STATUS_READING);

        }

        BRKLogger.msgInfo(null, SynchronousProcess.class.getSimpleName(), Constants.METHOD_RUN, MessageFormat.format(Constants.MSG_RUN_END, new Object[]{brokerId}));
        this.dataThread.setStatus(Constants.STATUS_DOWN);

        // ----------------------------------------------------------------------------------------------------------------------- //
        //
        // CALL SIX_CLOSE FUNCTION
        //
        // ----------------------------------------------------------------------------------------------------------------------- //
        BRKLogger.msgDebug(id, onlyClassName,
                "run", "Finalizando hilo-" + brokerId + ". Cerramos la conexion con el SIX.");

        try {

            fieldServerName.set(instanceApiSix, serverName);
            shortParamSIXRECV = fieldSixClose.getShort(null);
            rc = ((Integer) method.invoke(instanceApiSix, shortParamSIXCLOSE)).intValue();
            BRKLogger.msgDebug(null, onlyClassName, "run", "Fin del hilo[" + brokerId + "] y cierre de API SIX rc[" + rc + "]");
        } catch (Exception e1) {
            BRKLogger.msgError(id, onlyClassName, "run", "Ocurrio un error en el mecanismo de lectura de la cola del API SIX", e1);
        }
    }

    public Data getData() {
        return dataThread;
    }
}
