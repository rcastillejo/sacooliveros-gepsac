/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.novatronic.sixwsg.nextel.sixasincrono.util;

/**
 *
 * @author jbejar
 */
public class DTOSMSMessage {
    
    private String mensaje;
    private String telefono;
    private String area;

    public DTOSMSMessage(String mensaje, String telefono, String area) {
        this.mensaje = mensaje;
        this.telefono = telefono;
        this.area = area;
    }

    public DTOSMSMessage() {
    }


    public String getMensaje() {
        return mensaje;
    }

    public void setMensaje(String mensaje) {
        this.mensaje = mensaje;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public String getArea() {
        return area;
    }

    public void setArea(String area) {
        this.area = area;
    }

    @Override
    public String toString() {
        return "DTOSMSMessage{" + "mensaje=" + mensaje + ", telefono=" + telefono + ", area=" + area + '}';
    }
        
    
}
