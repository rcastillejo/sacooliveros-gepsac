/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.novatronic.sixwsg.nextel.sixasincrono.util;

import com.novatronic.formatter.internal.InternalFormat;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import org.apache.commons.lang.StringUtils;

/**
 *
 * @author ebajalqui
 */
public class FormaterUtils {

    protected static final int LONGITUD_MAXIMA_FORMATO_NUMERO = 12;

    public FormaterUtils() {
    }

    public static String formatearNumero(String numero, int longitud) {

        String numeroFormateado = "";

        int diferencia = longitud - numero.length();

        if (diferencia >= 0) {
            int longitudNroFormateado = numero.length() + diferencia;
            numeroFormateado = StringUtils.leftPad(numero, longitudNroFormateado, '0');
        } else {
            numeroFormateado = numero.substring(0, longitud);
        }
                                
        return numeroFormateado;
    }

    public static String formatearCadena(String cadena, int longitud) {

        String numeroFormateado = "";

        int diferencia = longitud - cadena.length();

        if (diferencia >= 0) {
            int longitudCadenaFormateada = cadena.length() + diferencia;
            numeroFormateado = StringUtils.rightPad(cadena, longitudCadenaFormateada, ' ');
        } else {
            numeroFormateado = cadena.substring(0, longitud);
        }

        return numeroFormateado;
    }

    public static Double formatearDoubleReq(String numeroFormatear) {

        int montoValueInt = Integer.valueOf(numeroFormatear);

        Double montoDouble = montoValueInt * 0.01;

        DecimalFormatSymbols simbolo = new DecimalFormatSymbols();
        simbolo.setDecimalSeparator('.');
        simbolo.setGroupingSeparator(',');
        DecimalFormat formateadorDecimal = new DecimalFormat("###.##", simbolo);

        String montoFormateado = formateadorDecimal.format(montoDouble);

        Double monto = Double.parseDouble(montoFormateado);

        return monto;
    }

    public static String formatearDoubleResp(Double numeroFormatear) {

        Double montoDouble = numeroFormatear * 100;

        DecimalFormatSymbols simbolo = new DecimalFormatSymbols();
        simbolo.setDecimalSeparator('.');
        simbolo.setGroupingSeparator(',');
        DecimalFormat formateadorDecimal = new DecimalFormat("###", simbolo);

        String montoFormateado = formateadorDecimal.format(montoDouble);

        return montoFormateado;
    }

    public static InternalFormat generarTimeoutIF(InternalFormat requestIF, String mensajeError) {

        InternalFormat respuestaIFTimeout = new InternalFormat("FormatoREMPPV");

        String tipoMensajeValue = obtenerTipoMensajeResouesta(requestIF.getValue("tip_msg"));

        respuestaIFTimeout.add("tip_msg", tipoMensajeValue);

        String panReqValue = requestIF.getValue("pan");
        respuestaIFTimeout.add("pan", panReqValue);

        String prCodeReqValue = requestIF.getValue("prcode");
        respuestaIFTimeout.add("prcode", prCodeReqValue);

        String prMontoReqValue = requestIF.getValue("monto");
        respuestaIFTimeout.add("monto", String.valueOf(prMontoReqValue));

        String fecTxnReqValue = requestIF.getValue("fec_txn");
        respuestaIFTimeout.add("fec_txn", fecTxnReqValue);

        String horTxnReqValue = requestIF.getValue("hor_txn");
        respuestaIFTimeout.add("hor_txn", horTxnReqValue);

        String traceReqValue = requestIF.getValue("trace");
        respuestaIFTimeout.add("trace", traceReqValue);

        String fecCapReqValue = requestIF.getValue("fec_cap");
        respuestaIFTimeout.add("fec_cap", fecCapReqValue);

        String binAcqReqValue = requestIF.getValue("bin_acq");
        respuestaIFTimeout.add("bin_acq", binAcqReqValue);

        String numRefReqValue = requestIF.getValue("num_ref");
        respuestaIFTimeout.add("num_ref", numRefReqValue);

        String codAutReqValue = requestIF.getValue("cod_aut");
        respuestaIFTimeout.add("cod_aut", codAutReqValue);

        respuestaIFTimeout.add("cod_rsp", "99");

        String termIdReqValue = requestIF.getValue("term_id");
        respuestaIFTimeout.add("term_id", termIdReqValue);

        String comercioReqValue = requestIF.getValue("comercio");
        respuestaIFTimeout.add("comercio", comercioReqValue);

        /* Datos PPV*/

        String formatoDatosPPVValue = FormaterUtils.formatearCadena("", 2);
        respuestaIFTimeout.add("datos_ppv1.formato", formatoDatosPPVValue);

        String codProcDatosPPVValue = FormaterUtils.formatearCadena("", 11);
        respuestaIFTimeout.add("datos_ppv1.cod_proc", codProcDatosPPVValue);

        String codTelcDatosPPVValue = FormaterUtils.formatearCadena("", 11);
        respuestaIFTimeout.add("datos_ppv1.cod_telc", codTelcDatosPPVValue);

        String codProdDatosPPVValue = FormaterUtils.formatearCadena("", 8);
        respuestaIFTimeout.add("datos_ppv1.cod_prod", codProdDatosPPVValue);

        String tipIdDatosPPVValue = FormaterUtils.formatearCadena("", 2);
        respuestaIFTimeout.add("datos_ppv1.tipid", tipIdDatosPPVValue);

        String idDatosPPVValue = FormaterUtils.formatearCadena("", 20);
        respuestaIFTimeout.add("datos_ppv1.id", idDatosPPVValue);

        String oriRspDatosPPVValue = FormaterUtils.formatearCadena("", 1);
        respuestaIFTimeout.add("datos_ppv1.orirsp", oriRspDatosPPVValue);

        String rspExtDatosPPVValue = FormaterUtils.formatearCadena("", 2);
        respuestaIFTimeout.add("datos_ppv1.rspext", rspExtDatosPPVValue);

        String desExtDatosPPVValue = FormaterUtils.formatearCadena("", 16);
        respuestaIFTimeout.add("datos_ppv1.desext", desExtDatosPPVValue);

        String tipTxnDatosPPVValue = FormaterUtils.formatearCadena("", 2);
        respuestaIFTimeout.add("datos_ppv1.tiptxn", tipTxnDatosPPVValue);

        String medPagDatosPPVValue = FormaterUtils.formatearCadena("", 2);
        respuestaIFTimeout.add("datos_ppv1.medpag", medPagDatosPPVValue);

        String tipCtaDatosPPVValue = FormaterUtils.formatearCadena("", 2);
        respuestaIFTimeout.add("datos_ppv1.tipcta", tipCtaDatosPPVValue);

        String fillerDatosPPVValue = FormaterUtils.formatearCadena("", 176);
        respuestaIFTimeout.add("datos_ppv1.filler", fillerDatosPPVValue);

        /**/

        String monedaReqValue = requestIF.getValue("moneda");
        respuestaIFTimeout.add("moneda", monedaReqValue);

        String bin1ReqValue = requestIF.getValue("bin1");
        respuestaIFTimeout.add("bin1", bin1ReqValue);

        String acct1ReqValue = requestIF.getValue("acct_1");
        respuestaIFTimeout.add("acct_1", acct1ReqValue);

        String bin2ReqValue = requestIF.getValue("bin2");
        respuestaIFTimeout.add("bin2", bin2ReqValue);

        String acct2ReqValue = requestIF.getValue("acct_2");
        respuestaIFTimeout.add("acct_2", acct2ReqValue);

        String codautOReqValue = requestIF.getValue("prcode");
        respuestaIFTimeout.add("codaut_o", codautOReqValue);

        String datosAdmValue = FormaterUtils.formatearCadena("", 40);
        respuestaIFTimeout.add("datos_adm", datosAdmValue);

        /* Completando los datos del datos_ppv_2*/

        String formatoReqValue = requestIF.getValue("datos_ppv.formato");
        respuestaIFTimeout.add("datos_ppv2.formato", formatoReqValue);

        String codProcReqValue = requestIF.getValue("datos_ppv.codproc");
        respuestaIFTimeout.add("datos_ppv2.cod_proc", codProcReqValue);

        String codTelcReqValue = requestIF.getValue("datos_ppv.codtelc");
        respuestaIFTimeout.add("datos_ppv2.cod_telc", codTelcReqValue);

        String codProdReqValue = requestIF.getValue("datos_ppv.codprod");
        respuestaIFTimeout.add("datos_ppv2.cod_prod", codProdReqValue);

        String tipIdReqValue = requestIF.getValue("datos_ppv.tipid");
        respuestaIFTimeout.add("datos_ppv2.tipid", tipIdReqValue);

        String idReqValue = requestIF.getValue("datos_ppv.id");
        respuestaIFTimeout.add("datos_ppv2.id", idReqValue);

        String pinIndReqValue = FormaterUtils.formatearNumero("", 1);
        respuestaIFTimeout.add("datos_ppv2.pin_ind", pinIndReqValue);

        String pinBinReqValue = FormaterUtils.formatearCadena("", 11);
        respuestaIFTimeout.add("datos_ppv2.pin_bin", pinBinReqValue);

        String pinMetodoReqValue = FormaterUtils.formatearNumero("", 2);
        respuestaIFTimeout.add("datos_ppv2.pin_metodo", pinMetodoReqValue);

        String pinLongitudReqValue = FormaterUtils.formatearNumero("", 2);
        respuestaIFTimeout.add("datos_ppv2.pin_longitud", pinLongitudReqValue);

        String pinCifradoReqValue = FormaterUtils.formatearCadena("", 32);
        respuestaIFTimeout.add("datos_ppv2.pin_cifrado", pinCifradoReqValue);

        respuestaIFTimeout.add("datos_ppv2.saldo_moneda", monedaReqValue);

        String saldoImporteValue = FormaterUtils.formatearNumero("0", 12);
        respuestaIFTimeout.add("datos_ppv2.saldo_importe", saldoImporteValue);

        String saldoMinutosValue = FormaterUtils.formatearNumero("0", 6);
        respuestaIFTimeout.add("datos_ppv2.saldo_minutos", saldoMinutosValue);

        String recCaducidad = FormaterUtils.formatearCadena("", 8);
        respuestaIFTimeout.add("datos_ppv2.rec_caducidad", recCaducidad);


        String recVigenciaValue = FormaterUtils.formatearNumero("0", 4);
        respuestaIFTimeout.add("datos_ppv2.rec_vigencia", recVigenciaValue);

        String mkt1Value = FormaterUtils.formatearCadena("", 40);
        respuestaIFTimeout.add("datos_ppv2.mkt1", mkt1Value);

        String mkt2Value = FormaterUtils.formatearCadena("", 40);
        respuestaIFTimeout.add("datos_ppv2.mkt2", mkt2Value);

        String oriRspValue = FormaterUtils.formatearCadena("2", 1);
        respuestaIFTimeout.add("datos_ppv2.orirsp", oriRspValue);

        respuestaIFTimeout.add("datos_ppv2.rspext", "0666");

        String desextValue = FormaterUtils.formatearCadena(mensajeError, 30);
        respuestaIFTimeout.add("datos_ppv2.desext", desextValue);

        String numPpvReqValue = requestIF.getValue("datos_ppv.numppv");
        respuestaIFTimeout.add("datos_ppv2.no_ope_ppv", numPpvReqValue);

        String noDocAutValue = FormaterUtils.formatearCadena("", 16);
        respuestaIFTimeout.add("datos_ppv2.no_doc_aut", noDocAutValue);

        String noDocTelcoValue = FormaterUtils.formatearCadena("", 16);
        respuestaIFTimeout.add("datos_ppv2.no_doc_telco", noDocTelcoValue);

        String impTotalValue = FormaterUtils.formatearNumero("0", 6);
        respuestaIFTimeout.add("datos_ppv2.imp_total", impTotalValue);

        String numRegTotalValue = FormaterUtils.formatearNumero("0", 3);
        respuestaIFTimeout.add("datos_ppv2.num_reg_total", numRegTotalValue);

        String numRegEnviadoValue = FormaterUtils.formatearNumero("0", 3);
        respuestaIFTimeout.add("datos_ppv2.num_reg_enviado", numRegEnviadoValue);

        String denominacionValue = FormaterUtils.formatearNumero("0", 4);
        respuestaIFTimeout.add("datos_ppv2.denominacion", denominacionValue);

        String cantidadValue = FormaterUtils.formatearNumero("0", 6);
        respuestaIFTimeout.add("datos_ppv2.cantidad", cantidadValue);

        String fillerValue = FormaterUtils.formatearCadena("", 521);
        respuestaIFTimeout.add("datos_ppv2.filler", fillerValue);

        /**/

        String macReqValue = requestIF.getValue("mac");
        respuestaIFTimeout.add("mac", macReqValue);

        return respuestaIFTimeout;

    }

    public static String obtenerTipoMensajeResouesta(String tipoMensajeRequerimiento) {

        String tipoMensajeRespuesta = "";

        if (tipoMensajeRequerimiento.equals("0200")) {

            tipoMensajeRespuesta = "0210";

        } else {

            if (tipoMensajeRequerimiento.equals("0400")) {

                tipoMensajeRespuesta = "0410";

            } else {

                if (tipoMensajeRequerimiento.equals("0800")) {

                    tipoMensajeRespuesta = "0810";
                }
            }
        }

        return tipoMensajeRespuesta;

    }
}
