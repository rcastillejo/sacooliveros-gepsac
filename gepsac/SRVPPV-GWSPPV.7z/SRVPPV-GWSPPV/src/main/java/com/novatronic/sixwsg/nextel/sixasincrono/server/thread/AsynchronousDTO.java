package com.novatronic.sixwsg.nextel.sixasincrono.server.thread;

/**
 * Clase que almacena las propiedades de la trama ISO
 *
 * @author Ricardo Castillejo Luna - NOVATRONIC SAC
 * @version 01.00.00
 * @since Created 23-11-2012 <br> <table border=1> <tr> <td
 * align='center'>Version</td> <td align='center'>Fecha</td> <td
 * align='center'>Modificado por</td><td align='center'>Metodo Modificado</td>
 * <td align='center'>Explicacion del cambio</td> </tr>
 * <tr><td>01.00.00</td><td>05-12-2012</td><td>Ricardo Castillejo Luna
 * (RCL)</td><td>todos</td><td>Refactorizacion de Código</td></tr> </table>
 */
public class AsynchronousDTO {

    /**
     * Identificador del DTO
     */
    private String id;
    /**
     * Arreglo bytes de la trama
     */
    private byte[] byteArrMessage;
    /**
     * Interfaz de requerimiento de la trama
     */
    private String requestingInterface;
    /**
     * Identificador del hilo en que se procesa el DTO
     */
    private int workerId;
    /**
     * Codigo de respuesta obtenido del six
     */
    private int responseCode;
    /**
     * Tiempo en milisegundos para medir el inicio del worker
     */
    private long checkInBroker;
    /**
     * Tiempo en milisegundos para medir el inicio del envio de la trama
     */
    private long checkOutToSCJ;
    /**
     * Tiempo en milisegundos para medir el final de la obtencion de la trama
     */
    private long checkInFromSCJ;
    /**
     * Tiempo en milisegundos para medir el fin del worker
     */
    private long checkOutBroker;

    /**
     * Retorna el Identificador del DTO
     *
     * @return String
     */
    public String getId() {
        return id;
    }

    /**
     * Establece el Identificador del DTO
     *
     * @param id
     */
    public void setId(String id) {
        this.id = id;
    }

    /**
     * Retorna el Interfaz de requerimiento de la trama
     *
     * @return String
     */
    public String getRequestingInterface() {
        return requestingInterface;
    }

    /**
     * Establece el Interfaz de requerimiento de la trama
     *
     * @param requestingInterface
     */
    public void setRequestingInterface(String requestingInterface) {
        this.requestingInterface = requestingInterface;
    }

    /**
     * Retorna el Identificador del hilo en que se procesa el DTO
     *
     * @return int
     */
    public int getWorkerId() {
        return workerId;
    }

    /**
     * Establece el Identificador del hilo en que se procesa el DTO
     *
     * @param workerId
     */
    public void setWorkerId(int workerId) {
        this.workerId = workerId;
    }

    /**
     * Etablece el Arreglo bytes de la trama
     *
     * @param byteArrMessage
     */
    public void setByteArrMessage(byte[] byteArrMessage) {
        this.byteArrMessage = new byte[byteArrMessage.length];
        System.arraycopy(byteArrMessage, 0, this.byteArrMessage, 0, byteArrMessage.length);
    }

    /**
     * Retorna el Arreglo bytes de la trama
     *
     * @return byte[]
     */
    public byte[] getByteArrMessage() {
        return byteArrMessage;
    }

    /**
     * Etablece el Codigo de respuesta obtenido del six
     *
     * @param int
     */
    public void setResponseCode(int responseCode) {
        this.responseCode = responseCode;
    }

    /**
     * Retorna el Codigo de respuesta obtenido del six
     *
     * @return int
     */
    public int getResponseCode() {
        return responseCode;
    }

    /**
     * Etablece el Tiempo en milisegundos para medir el inicio del worker
     *
     * @return long
     */
    public long getCheckInBroker() {
        return checkInBroker;
    }

    /**
     * Etablece el Tiempo en milisegundos para medir el envio de la trama
     *
     * @return long
     */
    public long getCheckOutToSCJ() {
        return checkOutToSCJ;
    }

    /**
     * Retorna el Tiempo en milisegundos para medir el final de la obtencion de
     * la trama
     *
     * @return long
     */
    public long getCheckInFromSCJ() {
        return checkInFromSCJ;
    }

    /**
     * Retorna el Tiempo en milisegundos para medir el fin del worker
     *
     * @return long
     */
    public long getCheckOutBroker() {
        return checkOutBroker;
    }

    /**
     * Metodo que establece el tiempo del sistema en milisegundos para medir el
     * inicio del worker
     */
    public void checkInBroker() {
        checkInBroker = System.currentTimeMillis();
    }

    /**
     * Metodo que establece el tiempo del sistema en milisegundos para medir el
     * envio de la trama
     */
    public void checkOutToSCJ() {
        checkOutToSCJ = System.currentTimeMillis();
    }

    /**
     * Metodo que establece el tiempo del sistema en milisegundos para medir el
     * final de la obtencion de la trama
     */
    public void checkInFromSCJ() {
        checkInFromSCJ = System.currentTimeMillis();
    }

    /**
     * Metodo que establece el tiempo del sistema en milisegundos para medir el
     * final del worker
     */
    public void checkOutBroker() {
        checkOutBroker = System.currentTimeMillis();
    }

    /**
     * {@inheritDoc }
     */
    @Override
    public String toString() {
        final int maxLen = 10;
        StringBuilder builder = new StringBuilder();
        builder.append("AsynchronousDTO [id=")
                .append(id)
                .append(", byteArrMessage=")
                .append(byteArrMessage != null ? arrayToString(byteArrMessage,
                byteArrMessage.length, maxLen) : null)
                .append(", requestingInterface=").append(requestingInterface)
                .append(", workerId=").append(workerId)
                .append(", responseCode=").append(responseCode)
                .append(", checkInBroker=").append(checkInBroker)
                .append(", checkOutToSCJ=").append(checkOutToSCJ)
                .append(", checkInFromSCJ=").append(checkInFromSCJ)
                .append(", checkOutBroker=").append(checkOutBroker).append("]");
        return builder.toString();
    }

    private String arrayToString(Object array, int len, int maxLen) {
        int longitud = len;
        StringBuilder builder = new StringBuilder();
        longitud = Math.min(longitud, maxLen);
        builder.append("[");
        for (int i = 0; i < longitud; i++) {
            if (i > 0) {
                builder.append(", ");
            }
            if (array instanceof byte[]) {
                builder.append(((byte[]) array)[i]);
            }
        }
        builder.append("]");
        return builder.toString();
    }
}
