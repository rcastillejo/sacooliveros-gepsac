package com.novatronic.sixwsg.nextel.sixasincrono.util;

/**
 * Clase que identifica el tipo de broker
 *
 * @author Ricardo Castillejo Luna - NOVATRONIC SAC
 * @version 01.00.00
 * @since Created 23-11-2012 <br> <table border=1> <tr> <td
 * align='center'>Version</td> <td align='center'>Fecha</td> <td
 * align='center'>Modificado por</td><td align='center'>Metodo Modificado</td>
 * <td align='center'>Explicacion del cambio</td> </tr>
 * <tr><td>01.00.00</td><td>05-12-2012</td><td>Ricardo Castillejo Luna
 * (RCL)</td><td>todos</td><td>Refactorizacion de Código</td></tr> </table>
 */
public enum BrokerType {

    SYN("JPapiloc.Japiloc"),
    ASY("JPapigen.Japigen");
    /**
     * Variable para establecer la clase de API SIX de acuerdo al tipo
     *
     */
    private String className;

    /**
     * Metodo constructor
     *
     * @param className - clase de API SIX de acuerdo al tipo
     *
     */
    BrokerType(String className) {
        this.className = className;
    }

    /**
     * Retorna la clase de API SIX de acuerdo al tipo
     *
     * @return String
     *
     */
    public String getClassName() {
        return this.className;
    }
}
