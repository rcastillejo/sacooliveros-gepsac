
package com.novatronic.sixwsg.nextel.proxyws.jaxws.handlers;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.Set;

import javax.xml.namespace.QName;
import javax.xml.soap.SOAPException;
import javax.xml.soap.SOAPMessage;
import javax.xml.ws.handler.MessageContext;
import javax.xml.ws.handler.soap.SOAPHandler;
import javax.xml.ws.handler.soap.SOAPMessageContext;

import com.novatronic.sixwsg.nextel.sixasincrono.logging.BRKLogger;

/**
 *
 * @author jbejar
 */
public class LogHandler implements SOAPHandler<SOAPMessageContext> {

    public Set<QName> getHeaders() {
    	//log.trace("Ejecutando getHeaders()");
        return null;
    }

    public boolean handleMessage(SOAPMessageContext context) {
        boolean isRequest = (Boolean) context.get(MessageContext.MESSAGE_OUTBOUND_PROPERTY);
        ByteArrayOutputStream output = new ByteArrayOutputStream();

        try {
            SOAPMessage message = context.getMessage();
            message.writeTo(output);
            if (isRequest) {
            	BRKLogger.msgDebug((String)context.get("MsgId"), "LogHandler", "handleMessage", "Request=["+output.toString()+"]");
            } else {
                long startTime = System.currentTimeMillis();
                context.put("StartTime", startTime);
                BRKLogger.msgDebug((String)context.get("MsgId"), "LogHandler", "handleMessage", "Response=["+output.toString()+"]");
            }
        } catch (SOAPException ex) {
        	BRKLogger.msgError((String)context.get("MsgId"), "LogHandler", "handleMessage", "Hubo un error al externalizar el SOAPMessage", ex);
        } catch (IOException ex) {
        	BRKLogger.msgError((String)context.get("MsgId"), "LogHandler", "handleMessage", "Hubo un error al tratar de leer SOAPMessageContext", ex);
        } catch (Exception ex) {
        	BRKLogger.msgError((String)context.get("MsgId"), "LogHandler", "handleMessage", "Error no esperado", ex);
        }
        
        return true;
    }

    public boolean handleFault(SOAPMessageContext context) {
    	boolean isRequest = (Boolean) context.get(MessageContext.MESSAGE_OUTBOUND_PROPERTY);
    	ByteArrayOutputStream output = new ByteArrayOutputStream();

        try {
            SOAPMessage message = context.getMessage();
            message.writeTo(output);
            if (isRequest) {
            	BRKLogger.msgDebug((String)context.get("MsgId"), "LogHandler", "handleFault", "FAULT Request=["+output.toString()+"]");
            } else {
                long startTime = System.currentTimeMillis();
                context.put("StartTime", startTime);
                BRKLogger.msgDebug((String)context.get("MsgId"), "LogHandler", "handleFault", "FAULT Response=["+output.toString()+"]");
            }
        } catch (SOAPException ex) {
            BRKLogger.msgError((String)context.get("MsgId"), "LogHandler", "handleFault", "Hubo un error al externalizar el SOAPMessage", ex);
        } catch (IOException ex) {
        	BRKLogger.msgError((String)context.get("MsgId"), "LogHandler", "handleFault", "Hubo un error al tratar de leer SOAPMessageContext", ex);
        } catch (Exception ex) {
            BRKLogger.msgError((String)context.get("MsgId"), "LogHandler", "handleFault", "Error no esperado", ex);
        }
        return true;
    }

    public void close(MessageContext context) {
    	//log.trace("Ejecutando close(MessageContext context)");
    }
}
