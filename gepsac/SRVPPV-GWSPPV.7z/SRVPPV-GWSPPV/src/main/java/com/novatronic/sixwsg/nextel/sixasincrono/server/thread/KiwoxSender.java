package com.novatronic.sixwsg.nextel.sixasincrono.server.thread;

import com.novatronic.sixwsg.entel.model.EventResponse;
import com.novatronic.sixwsg.entel.proxyrs.Proxy;
import com.novatronic.sixwsg.entel.proxyrs.ProxyFactory;
import com.novatronic.sixwsg.entel.proxyrs.exception.ExecuteOperationException;
import com.novatronic.sixwsg.entel.proxyrs.exception.ExecuteRequestException;
import java.util.Properties;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.TimeUnit;

import com.novatronic.sixwsg.nextel.sixasincrono.logging.BRKLogger;
import com.novatronic.sixwsg.nextel.sixasincrono.server.Data;
import com.novatronic.sixwsg.nextel.sixasincrono.util.Constants;
import com.novatronic.sixwsg.nextel.sixasincrono.util.KiwoxMessage;
import java.util.HashMap;

/**
 *
 * @author jbejar
 */
public class KiwoxSender implements Runnable {
    private static final int DEFAULT_RETRY = 0;
    private static final long DEFAULT_RETRY_WAIT = 1000;
    private static final String OPERATION = "comprasOneShoot";
    private static final String onlyClassname = KiwoxSender.class.getSimpleName();
    private final BlockingQueue<KiwoxMessage> colaMensajes;
    private final Proxy proxyEnvioKiwox;

    private final int retry;
    private long retryWait;
    private final Data status;

    public KiwoxSender(BlockingQueue<KiwoxMessage> colaMensajes, Properties propiedades) throws Exception {
        this.colaMensajes = colaMensajes;
        this.proxyEnvioKiwox = ProxyFactory.create();
        this.proxyEnvioKiwox.setContext(new HashMap());
        /**
         * serviceKiwox.retry = 5 serviceKiwox.retryWait = 1000
         */
        this.retry = propiedades.containsKey("serviceKiwox.retry") ? 
                Integer.parseInt(propiedades.getProperty("serviceKiwox.retry")) : DEFAULT_RETRY;        
        if(retry > DEFAULT_RETRY){
            this.retryWait = propiedades.containsKey("serviceKiwox.retryWait") ?
                    Long.parseLong(propiedades.getProperty("serviceKiwox.retryWait")): DEFAULT_RETRY_WAIT;
        }
        this.status = new Data();
    }

    @Override
    public void run() {
        String id = null;
        KiwoxMessage request;
        while (true) {
            try {

                this.status.setStatus(Constants.STATUS_READING);
                request = this.colaMensajes.poll(5, TimeUnit.SECONDS);
                if (request == null) {
                    continue;
                }
                id = request.getId();
                this.status.setStatus(Constants.STATUS_PROCESS);
                try {
                    execute(request);
                    request.finish();
                } catch (Exception ex) {
                    BRKLogger.msgError(request.getId(), onlyClassname, "run", "Error en el primer envio a Kiwox [" + ex.getMessage() + "], se procede a reintentar", ex);
                    request.retry();
                    executeRetry(request);
                }

            } catch (InterruptedException ex) {
                BRKLogger.msgError(id, onlyClassname, "run", "Error al obtener el mensaje de la cola", ex);
            }
        }
    }

    private void execute(KiwoxMessage request) {
        int retryExe = request.getRetry();
        BRKLogger.msgDebug(request.getId(), onlyClassname, "run", "Reintento[" + retryExe + "]-Requerimiento a enviar a Kiwox [" + request + "] ...");
        EventResponse response = (EventResponse) proxyEnvioKiwox.send(OPERATION, request.getRequest());
        request.setResponse(response);
        BRKLogger.msgDebug(request.getId(), onlyClassname, "run", "Reintento[" + retryExe + "]-Envio a Kiwox[" + request + "] response[" + response + "]");
    }

    private void executeRetry(KiwoxMessage request) {
        while (request.getRetry() <= retry && !request.hasResponse()) {
            int retryExe = request.getRetry();
            try {
                execute(request);
                try {
                    Thread.sleep(retryWait);
                } catch (Exception e) {
                }
            } catch (ExecuteOperationException ex) {
                BRKLogger.msgError(request.getId(), onlyClassname, "run", "Reintento[" + retryExe + "]-Error en el reenvio a Kiwox [" + ex.getMessage() + "]", ex);
                request.retry();
            } catch (ExecuteRequestException ex) {
                BRKLogger.msgError(request.getId(), onlyClassname, "run", "Reintento[" + retryExe + "]-Error recibido de Kiwox [" + ex.getType() + "]", ex);
                request.retry();
            } catch (Exception ex) {
                BRKLogger.msgError(request.getId(), onlyClassname, "run", "Reintento[" + retryExe + "]-Error del sistema al enviar a Kiwox", ex);
                request.retry();
            }
        }
        request.finish();
    }

    public Data getStatus() {
        return status;
    }

    public int getRetry() {
        return retry;
    }

    public long getRetryWait() {
        return retryWait;
    }

    @Override
    public String toString() {
        return "KiwoxSender{" + "retry=" + retry + ", retryWait=" + retryWait + ", status=" + status + '}';
    }

}
