package com.novatronic.sixwsg.nextel.sixbws.wsnextel;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import com.novatronic.sixwsg.nextel.sixbws.wsnextel.exception.TrxnException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.xml.namespace.QName;
import javax.xml.ws.Service;
import org.jdom.Document;
import org.jdom.Element;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Clase para la configuracion y mapeo de las Transacciones
 *
 * @author Ricardo Castillejo Luna - NOVATRONIC SAC
 * @version 01.00.00
 * @since Creado 05-04-2013
 */
public final class WSServiceFactory {

    private static final Logger log = LoggerFactory.getLogger(WSServiceFactory.class);
    private static Map<String, WSService> serviciosxTransaccion;
    private static Map<String, WSService> servicios;
    private static final String PREFIX_TRANSACCION = "com.novatronic.bancamovil.sixbws.wsnextel.service.";
    private static final String PREFIX_PORT_CLASS = "com.novatronic.sms.ws.";

    private class Config {

        private static final String TAG_TRANSACCIONES = "Transacciones";
        private static final String TAG_SERVICIOS = "Servicios";
        private static final String TIPO_CLASE_SERVICIO = "Tipo";
        private static final String URL_SERVICIO = "Url";
        private static final String QNAME_SERVICIO = "Qname";
        private static final String NOMBRE_SERVICIO = "NombreServicio";
        private static final String CLASE_PUERTO_SERVICIO = "PortClass";
        private static final String ID_SERVICIO = "IdServicio";
        private static final String ID_TRANSACCION = "IdTransaccion";
        private static final String TAG_CONFIGURACION = "Configuracion";
    }

    private WSServiceFactory() {
    }

    /**
     * Metodo que carga la configuracion para la fabrica de transacciones
     *
     * @param config - Properties que contiene la estructura de las
     * transacciones a configurar.
     */
    public static void init(Document configuracionGeneral) {

        servicios = new HashMap<String, WSService>();
        serviciosxTransaccion = new HashMap<String, WSService>();
        Element bloqueConfiguracion = configuracionGeneral.getRootElement();

        validateConf(bloqueConfiguracion);
        servicios = configurarServicios(bloqueConfiguracion);



        Element bloqueTransacciones = bloqueConfiguracion.getChild(Config.TAG_TRANSACCIONES);
        List listaTransacciones = bloqueTransacciones.getChildren();

        for (int iServicioxTransaccion = 0; iServicioxTransaccion < listaTransacciones.size(); iServicioxTransaccion++) {

            Element transaccion = (Element) listaTransacciones.get(iServicioxTransaccion);
            validateConfServicioxTransaccion(transaccion);
            String idServicio = transaccion.getAttributeValue(Config.ID_SERVICIO);
            String idTransaccion = transaccion.getAttributeValue(Config.ID_TRANSACCION);

            serviciosxTransaccion.put(idTransaccion, servicios.get(idServicio));
        }

        log.debug("Servicios configurados [Servicios={}]", serviciosxTransaccion);

    }

    private static Map<String, WSService> configurarServicios(Element confServicios) {

        Map<String, WSService> serviciosConfigurados = new HashMap<String, WSService>();

        Element bloqueServicios = confServicios.getChild(Config.TAG_SERVICIOS);

        List listaServicios = bloqueServicios.getChildren();

        for (int iServicio = 0; iServicio < listaServicios.size(); iServicio++) {

            Element servicio = (Element) listaServicios.get(iServicio);

            validateConfServicio(servicio);
            String idServicio = servicio.getAttributeValue(Config.ID_SERVICIO);
            String claseServicio = servicio.getAttributeValue(Config.TIPO_CLASE_SERVICIO);
            String urlServicioStr = servicio.getAttributeValue(Config.URL_SERVICIO);
            String qnameServicio = servicio.getAttributeValue(Config.QNAME_SERVICIO);
            String nombreServicio = servicio.getAttributeValue(Config.NOMBRE_SERVICIO);
            String clasePort = servicio.getAttributeValue(Config.CLASE_PUERTO_SERVICIO);
            String nombreClaseInstanciar = PREFIX_TRANSACCION + claseServicio;

            try {

                WSService servicioConfigurado = (WSService) Class.forName(nombreClaseInstanciar).newInstance();
                URL urlServicio = new URL(urlServicioStr);
                servicioConfigurado.setUrl(urlServicio);
                servicioConfigurado.setQname(qnameServicio);
                servicioConfigurado.setServiceName(nombreServicio);
                servicioConfigurado.setPortClass(clasePort);
                String nombreClasePuerto = PREFIX_PORT_CLASS + clasePort;
                servicioConfigurado.setPort(createPort(Class.forName(nombreClasePuerto), qnameServicio, nombreServicio, urlServicio));

                serviciosConfigurados.put(idServicio, servicioConfigurado);

            } catch (MalformedURLException ex) {
                log.error("Error al generar el objeto URL", ex);
            } catch (ClassNotFoundException ex) {
                log.error("Error al instanciar el servicio", ex);
            } catch (InstantiationException ex) {
                log.error("Error al instanciar el servicio", ex);
            } catch (IllegalAccessException ex) {
                log.error("Error al instanciar el servicio", ex);
            }


        }

        return serviciosConfigurados;

    }

    /**
     *
     * @param config
     */
    public static void validateConf(Element config) {
        if (config.getChild(Config.TAG_SERVICIOS) == null || config.getChild(Config.TAG_TRANSACCIONES) == null) {
            throw new TrxnException("La configuración General no se ha especificado correctamente");
        }
    }

    /**
     *
     * @param configServicio
     */
    public static void validateConfServicio(Element configServicio) {
        if (configServicio.getAttribute(Config.ID_SERVICIO) == null || configServicio.getAttribute(Config.TIPO_CLASE_SERVICIO) == null
                || configServicio.getAttribute(Config.URL_SERVICIO) == null || configServicio.getAttribute(Config.QNAME_SERVICIO) == null
                || configServicio.getAttribute(Config.NOMBRE_SERVICIO) == null || configServicio.getAttribute(Config.CLASE_PUERTO_SERVICIO) == null) {
            throw new TrxnException("La configuración  de Servicios no se ha especificado correctamente");
        }
    }

    /**
     *
     * @param configServicio
     */
    public static void validateConfServicioxTransaccion(Element configServicio) {
        if (configServicio.getAttribute(Config.ID_SERVICIO) == null || configServicio.getAttribute(Config.ID_TRANSACCION) == null) {
            throw new TrxnException("La configuración de Servicios por Transacciones no se ha especificado correctamente");
        }
    }

    /**
     * Retorna transaccion de acuerdo a la llave especificada.
     *
     * @param key - Identificador de la transaccion
     * @return {@link WSService}
     */
    public static WSService getInstance(String key) {
        try {
            log.trace("[{}] Clase transaccion instanciada [{}]", key);
            return (WSService) serviciosxTransaccion.get(key);
        } catch (Exception e) {
            throw new TrxnException("No se pudo instanciar la transaccion [" + key + "]", e);
        }
    }

    /**
     *
     * @param <T>
     * @param claz
     * @param qname
     * @param serviceName
     * @param url
     * @return
     */
    private static <T> T createPort(Class<T> claz, String qname, String serviceName, URL url) {
        T port;
        QName qName;
        Service service;

        port = null;
        try {
            qName = new QName(qname, serviceName);
            service = Service.create(url, qName);
            port = service.getPort(claz);
        } catch (Exception ex) {
            log.error("Error al crear al servicio", ex);
        }

        return port;
    }
}
