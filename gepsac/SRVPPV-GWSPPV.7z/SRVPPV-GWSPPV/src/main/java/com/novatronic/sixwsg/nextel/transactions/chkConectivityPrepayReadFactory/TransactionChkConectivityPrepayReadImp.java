/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.novatronic.sixwsg.nextel.transactions.chkConectivityPrepayReadFactory;

import com.novatronic.formatter.FormatterFactory;
import com.novatronic.formatter.internal.InternalFormat;
import com.novatronic.sixwsg.nextel.sixasincrono.logging.BRKLogger;
import com.novatronic.sixwsg.nextel.transactions.chkConectivityPrepayReadFactory.TransactionChkConectivityPrepayRead;
import com.novatronic.sixwsg.nextel.transactions.chkConectivityPrepayReadFactory.TransactionChkConectivityPrepayReadImp;
import com.novatronic.proxyws.WS_CheckConectivityPrepayReadStub;
import com.novatronic.proxyws.WS_CheckConectivityPrepayReadStub.ReadCheckConectivityPrepayElement;
import com.novatronic.proxyws.WS_CheckConectivityPrepayReadStub.ReadCheckConectivityPrepayResponseElement;

import java.rmi.RemoteException;

/**
 *
 * @author ebajalqui
 */
public abstract class TransactionChkConectivityPrepayReadImp implements TransactionChkConectivityPrepayRead {

    private static final String MSG_TIMEOUT = "TIME OUT - ERROR TELCO";
    private static final String ID_FORMATEADOR_SALIDA = "FormatoREMPPV";
    private static final String COD_TRANSACCION_APROBADA = "0";
    private static final String COD_ERROR_CONTENT = "1414";
    private static final String COD_ERROR_OUTPUT = "1415";
    private static final String COD_ERROR_RECEIVE_MESSAGE = "1413";
    private static final String COD_ERROR_UNEXPECTED = "1416";

    public ReadCheckConectivityPrepayResponseElement process(ReadCheckConectivityPrepayElement request, WS_CheckConectivityPrepayReadStub proxy) throws Exception {
        try {
            return handle(request, proxy);
        } catch (Exception ex) {

            BRKLogger.msgError("", TransactionChkConectivityPrepayReadImp.class.getSimpleName(), " process ", "Error al Enviar Requerimiento", ex);
            throw ex;
        }
    }

    public ReadCheckConectivityPrepayElement generarRequest(InternalFormat requestIF) throws Exception {

        try {
            return generarCheckConectivityPrepayElement(requestIF);
        } catch (Exception e) {

            BRKLogger.msgError("", TransactionChkConectivityPrepayReadImp.class.getSimpleName(), " generarRequest ", "Error al Generar Requerimiento", e);
            throw e;
        }
    }

    public String generarResponse(ReadCheckConectivityPrepayResponseElement response, InternalFormat requestIF, FormatterFactory formatter) throws Exception {

        try {
            return generarTramaRespuesta(response, requestIF, formatter);
        } catch (Exception e) {

            BRKLogger.msgError("", TransactionChkConectivityPrepayReadImp.class.getSimpleName(), " generarResponse ", "Error al Generar Respuesta", e);
            throw e;
        }
    }

    public String sendReceiveData(String prCodeTransaccion, InternalFormat requerimientoIF, WS_CheckConectivityPrepayReadStub proxyCheckConectivityPrepayRead, FormatterFactory nextelFormatterFactory) throws Exception {

        String respuesta = "";
        ReadCheckConectivityPrepayElement request = null;

        request = generarRequest(requerimientoIF);
        ReadCheckConectivityPrepayResponseElement response = process(request, proxyCheckConectivityPrepayRead);

        if ((response != null) || response.getResult() != null) {

            respuesta = generarResponse(response, requerimientoIF, nextelFormatterFactory);

        } else {

            respuesta = "";
            BRKLogger.msgDebug("", TransactionChkConectivityPrepayReadImp.class.getSimpleName(), " SendReceiveData", "Se obtuvo una respuesta Nula");

        }

        return respuesta;

    }

    protected abstract ReadCheckConectivityPrepayResponseElement handle(ReadCheckConectivityPrepayElement request, WS_CheckConectivityPrepayReadStub proxy) throws RemoteException;

    protected abstract ReadCheckConectivityPrepayElement generarCheckConectivityPrepayElement(InternalFormat requestIF);

    protected abstract String generarTramaRespuesta(ReadCheckConectivityPrepayResponseElement response, InternalFormat requestIF, FormatterFactory formatter);
}
