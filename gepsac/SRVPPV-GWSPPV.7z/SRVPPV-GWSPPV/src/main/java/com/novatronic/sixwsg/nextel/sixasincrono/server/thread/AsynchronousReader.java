package com.novatronic.sixwsg.nextel.sixasincrono.server.thread;

import com.novatronic.sixwsg.nextel.sixasincrono.logging.BRKLogger;
import com.novatronic.sixwsg.nextel.sixasincrono.logging.Identificador;
import com.novatronic.sixwsg.nextel.sixasincrono.server.Broker;
import com.novatronic.sixwsg.nextel.sixasincrono.server.Data;
import com.novatronic.sixwsg.nextel.sixasincrono.util.Constants;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.text.MessageFormat;
import java.util.concurrent.BlockingQueue;

/**
 * @author rcastillejo
 *
 */
/**
 * Clase que obtiene la trama ISO desde el API SIX y almacena en un DTO para
 * agregarlo en la cola de comunicacion
 *
 * @author Ricardo Castillejo Luna - NOVATRONIC SAC
 * @version 01.00.00
 * @since Created 23-11-2012 <br> <table border=1> <tr> <td
 * align='center'>Version</td> <td align='center'>Fecha</td> <td
 * align='center'>Modificado por</td><td align='center'>Metodo Modificado</td>
 * <td align='center'>Explicacion del cambio</td> </tr>
 * <tr><td>01.00.00</td><td>05-12-2012</td><td>Ricardo Castillejo Luna
 * (RCL)</td><td>todos</td><td>Refactorizacion de Código</td></tr> </table>
 */
public class AsynchronousReader implements Runnable {

    /**
     * Variable indicadora para continuar la ejecucion del Hilo de la instancia
     * de broker
     */
    private boolean continuaBroker = true;
    /**
     * Clase que permite el manejo del API SIX
     */
    private final Class classApiSix;
    /**
     * Variable para referenciar instacia de API SIX
     */
    private Object instanceApiSix;
    /**
     * Variable para establecer la cantidad de hilos a atender
     */
    private int numThreads;
    /**
     * Variable para establecer el tamaño de la trama ISO
     */
    private short maxMsgLen;
    /**
     * Variable para establecer el nombre del servidor six
     */
    private String serverName;
    /**
     * Variable para establecer el tiempo total en milisegundos para la
     * evaluacion de los hilos
     */
    private int timeForThreadsMili;
    /**
     * Variable para establecer el intervalo en milisegundos para la
     * verificacion de hilos
     */
    private int brokerIntervalMili;
    /**
     * Clase que permite generar un Identificador
     */
    private Identificador idf;
    /**
     * Clase que permite el manejo de estados
     */
    private Data dataThread;
    /**
     * Cola de comunicacion
     */
    private BlockingQueue<AsynchronousDTO> colaSixToScj;
    /**
     * Objeto que permite establecer un token sincrono
     */
    private Object tokenSynchro;
    private String requestInterface;
    private static final String MSG_RUN_APISIX_END = "Fin de hilo {0} y cierre de API SIX rc[{1}]";
    private static final String MSG_NO_THREADS_ENABLE = "NO SE ACEPTAN transacciones, no hay capacidad de coperacion disponible. [{0}] transacciones en curso.";
    private static final String MSG_THREADS_ENABLE = "Aceptamos transaccion. [{0}] transacciones en curso.";
    private static final String MSG_APISIX_SHUTDOWN = "Se recibe del SIX un mensaje de shutdown.";
    private static final String MSG_APISIX_TIMEOUT = "Timeout recibido mientras se espera leer requerimiento del SIX";
    private static final String MSG_APISIX_ERROR_CODE = "Codigo de retorno inesperado desde el SIX: rc({0})";
    private static final String MSG_APISIX_SEND = "Se leyeron [{0}]bytes del SIX. Interfaz solicitante [{1}]";

    /**
     * Metodo constructor de la clase, para una instancia en particular
     *
     * @param brokerName Nombre del broker
     * @param numThreads Numero de threads
     * @param maxMsgLen Maximo longitud para el mensaje
     * @param serverName Nombre del servidor
     * @param timeForThreads Maximo tiempo de espera para finalizar threads
     * @param brokerInterval intervalo de esperas
     * @param classApiSix clase del ApiSix
     * @param dataThread clase de estados
     * @param colaSixToScj cola de comunicacion
     * @param tokenSynchro objeto de token sincrono
     * @throws InstantiationException
     * @throws IllegalAccessException
     */
    public AsynchronousReader(String brokerName, int numThreads, short maxMsgLen,
            String serverName, int timeForThreads,
            int brokerInterval, Class classApiSix, Data dataThread,
            BlockingQueue<AsynchronousDTO> colaSixToScj,
            Object tokenSynchro, String requestInterface) throws InstantiationException,
            IllegalAccessException {

        this.numThreads = numThreads;
        this.maxMsgLen = maxMsgLen;
        this.serverName = serverName;
        this.timeForThreadsMili = timeForThreads * Constants.MILIS;
        this.brokerIntervalMili = brokerInterval * Constants.MILIS;

        idf = Identificador.getInstance(brokerName);

        this.classApiSix = classApiSix;
        this.instanceApiSix = classApiSix.newInstance();

        this.dataThread = dataThread;

        this.colaSixToScj = colaSixToScj;

        this.tokenSynchro = tokenSynchro;

        this.requestInterface = requestInterface;
    }

    /**
     * Metodo con el contexto de ejecucion del hilo, realiza: <br> 1) La lectura
     * de un mensaje de SIX <br> 2) Pone el mensaje en cola de comunicacion
     * entre Threads <br>
     */
    public void run() {

        int rc;
        BRKLogger.msgInfo(null, AsynchronousReader.class.getSimpleName(), Constants.METHOD_RUN, MessageFormat.format(Constants.MSG_RUN_START, AsynchronousReader.class.getSimpleName()));

        // ----------------------------------------------------------------------------------------------------------------------- //
        //
        // MAIN LOOP - PROCESS MESSAGES
        //
        // ----------------------------------------------------------------------------------------------------------------------- //
        String id = null;

        Field fieldHostName = null;
        Field fieldUserName = null;
        Field fieldMaxLen = null;
        Field fieldWaitTime = null;
        Field fieldRecvType = null;
        Field fieldMesgData = null;
        Field fieldServName = null;
        Method methodJavSixApiGen = null;

        short shortParamSIXRECV = -1;
        short shortParamSIXCLOSE = -1;

        try {
            fieldHostName = classApiSix.getDeclaredField("host_name");
            fieldUserName = classApiSix.getDeclaredField("user_name");
            fieldMaxLen = classApiSix.getDeclaredField("max_len");
            fieldWaitTime = classApiSix.getDeclaredField("wait_time");
            fieldRecvType = classApiSix.getDeclaredField("recv_type");
            fieldMesgData = classApiSix.getDeclaredField("mesg_data");
            fieldServName = classApiSix.getDeclaredField("serv_name");
            shortParamSIXRECV = classApiSix.getDeclaredField("SIX_RECV").getShort(null);
            shortParamSIXCLOSE = classApiSix.getDeclaredField("SIX_CLOSE").getShort(null);
            methodJavSixApiGen = classApiSix.getMethod("javasix_apigen", short.class);
        } catch (Exception e2) {
            BRKLogger.msgError(id, AsynchronousReader.class.getSimpleName(), Constants.METHOD_RUN, Constants.MSG_ERROR_APIXSIX_QUEUE, e2);
            return;
        }

        int longitudMensaje;
        byte[] byteArrMessage;

        String requestingInterfaceFromSix;

        while (continuaBroker && Broker.isContinuaTodoBroker()) {
            // -------------------------------------------------------------------------------------------------------------- //
            //
            // CALL SIX_RCVREQ FUNCTION (Receive request from SIX)
            //
            // -------------------------------------------------------------------------------------------------------------- //

            try {

                fieldHostName.set(this.instanceApiSix, "");
                fieldUserName.set(this.instanceApiSix, "");
                fieldMaxLen.setShort(this.instanceApiSix, (short) maxMsgLen);
                fieldWaitTime.setShort(this.instanceApiSix, (short) 0);
                fieldRecvType.setByte(this.instanceApiSix, (byte) (new Character('W')).charValue());
                BRKLogger.msgDebug(null, AsynchronousReader.class.getSimpleName(), Constants.METHOD_RUN, "Esperando leer de la cola...");

                /* 
                 * El siguiente WHILE es para imedir que se sigan leyendo transacciones cuando no hay hilos de atencion disponibles
                 * Los workers deben reducir el contador que se incrementa
                 */
                while (true) {
                    synchronized (tokenSynchro) {
                        if (Broker.getCurrentTransactions().intValue() >= numThreads) {
                            try {
                                BRKLogger.msgDebug(null, AsynchronousReader.class.getSimpleName(), Constants.METHOD_RUN, MessageFormat.format(MSG_NO_THREADS_ENABLE, new Object[]{Broker.getCurrentTransactions().intValue()}));
                                tokenSynchro.wait(1000);
                            } catch (InterruptedException e) {
                                continue;
                            }
                        } else {
                            break;
                        }
                    }
                }

                rc = ((Integer) methodJavSixApiGen.invoke(instanceApiSix, shortParamSIXRECV)).intValue();

                synchronized (tokenSynchro) {
                    int txnEnCurso = Broker.getCurrentTransactions().incrementAndGet();
                    BRKLogger.msgDebug(null, AsynchronousReader.class.getSimpleName(), Constants.METHOD_RUN, MessageFormat.format(MSG_THREADS_ENABLE, new Object[]{txnEnCurso}));
                }

            } catch (Exception e) {
                BRKLogger.msgError(null, AsynchronousReader.class.getSimpleName(), Constants.METHOD_RUN, Constants.MSG_ERROR_APIXSIX_QUEUE, e);
                continuaBroker = false;
                continue;
            }



            id = idf.getCode();

            switch (rc) {
                case 0:
                    //                  SUCCESS
                    this.dataThread.setStatus(Constants.STATUS_PROCESS);
                    break;
                case 413:
                case -413:
                    //                  SHUTDOWN
                    BRKLogger.msgDebug(id, AsynchronousReader.class.getSimpleName(), Constants.METHOD_RUN, MSG_APISIX_SHUTDOWN);
                    continuaBroker = false;
                    Broker.shutdownControlador(id, numThreads, timeForThreadsMili, brokerIntervalMili);
                    continue;

                case 415:
                case -415:
                    //                  TIMEOUT
                    BRKLogger.msgDebug(id, AsynchronousReader.class.getSimpleName(), Constants.METHOD_RUN, MSG_APISIX_TIMEOUT);
                    this.dataThread.setStatus(Constants.STATUS_READING);
                    continue;
                default:
                    //                  DEFAULT
                    //
                    BRKLogger.msgDebug(id, AsynchronousReader.class.getSimpleName(), Constants.METHOD_RUN, MessageFormat.format(MSG_APISIX_ERROR_CODE, new Object[]{rc}));
                    continuaBroker = false;
                    continue;
            }
            // Deja rastro del consumo de memoria en el log de performance
            BRKLogger.msgDebug(id, AsynchronousReader.class.getSimpleName(), Constants.METHOD_RUN, "MM:["
                    + Runtime.getRuntime().maxMemory() + "] " + "FM:["
                    + Runtime.getRuntime().freeMemory() + "] " + "TM:["
                    + Runtime.getRuntime().totalMemory() + "] " + "AT:["
                    + Thread.currentThread().getThreadGroup().activeCount()
                    + "]");

            //Cadena leida
            try {
                longitudMensaje = fieldMaxLen.getInt(instanceApiSix);
                byteArrMessage = new byte[longitudMensaje];
                System.arraycopy((byte[]) fieldMesgData.get(instanceApiSix), 0, byteArrMessage, 0, longitudMensaje);
                requestingInterfaceFromSix = (String) fieldUserName.get(instanceApiSix);
                BRKLogger.msgDebug(id, AsynchronousReader.class.getSimpleName(), Constants.METHOD_RUN, "Interface obtenida [" + requestingInterfaceFromSix + "], Ijnterfaz parametrizada [" + this.requestInterface + "]");
                requestingInterfaceFromSix = this.requestInterface == null || this.requestInterface.isEmpty() ? requestingInterfaceFromSix : this.requestInterface;
                BRKLogger.msgDebug(id, AsynchronousReader.class.getSimpleName(), Constants.METHOD_RUN, MessageFormat.format(MSG_APISIX_SEND, new Object[]{longitudMensaje, requestingInterfaceFromSix}));
            } catch (Exception e1) {
                BRKLogger.msgError(id, AsynchronousReader.class.getSimpleName(), Constants.METHOD_RUN, Constants.MSG_ERROR_APIXSIX_QUEUE, e1);
                continuaBroker = false;
                continue;
            }

            AsynchronousDTO asynchronousDTO = new AsynchronousDTO();
            asynchronousDTO.checkInBroker();
            asynchronousDTO.setId(id);
            asynchronousDTO.setByteArrMessage(byteArrMessage);
            asynchronousDTO.setRequestingInterface(requestingInterfaceFromSix);


            try {
                boolean insertaOk = colaSixToScj.offer(asynchronousDTO);
                if (!insertaOk) {
                    BRKLogger.msgError(id, AsynchronousReader.class.getSimpleName(), Constants.METHOD_RUN, Constants.MSG_ERROR_WRITE_WORKER_QUEUE, null);
                    // Detenmos todo ya que la situacion es inestable
                    Broker.setContinuaTodoBroker(false);
                    continue;
                }
            } catch (Exception e) {
                BRKLogger.msgError(id, AsynchronousReader.class.getSimpleName(), Constants.METHOD_RUN, Constants.MSG_ERROR_WORKER_QUEUE, e);
                // Detenmos todo ya que la situacion es inestable
                Broker.setContinuaTodoBroker(false);
                continue;
            }

            this.dataThread.setStatus(Constants.STATUS_READING);
        }

        this.dataThread.setStatus(Constants.STATUS_DOWN);


        // ----------------------------------------------------------------------------------------------------------------------- //
        //
        // CALL SIX_CLOSE FUNCTION
        //
        // ----------------------------------------------------------------------------------------------------------------------- //
        BRKLogger.msgDebug(id, AsynchronousReader.class.getSimpleName(), Constants.METHOD_RUN, MessageFormat.format(Constants.MSG_RUN_END, new Object[]{AsynchronousReader.class.getSimpleName()}));

        try {
            fieldServName.set(instanceApiSix, serverName);
            rc = ((Integer) methodJavSixApiGen.invoke(instanceApiSix, shortParamSIXCLOSE)).intValue();
            BRKLogger.msgDebug(null, AsynchronousReader.class.getSimpleName(), Constants.METHOD_RUN, MessageFormat.format(MSG_RUN_APISIX_END, new Object[]{AsynchronousReader.class.getSimpleName(), rc}));
        } catch (Exception e1) {
            BRKLogger.msgError(id, AsynchronousReader.class.getSimpleName(), Constants.METHOD_RUN, Constants.MSG_ERROR_APIXSIX_QUEUE, e1);
        }

    }

    /**
     * Retorna la clase de estados
     *
     * @return Data
     */
    public Data getData() {
        return dataThread;
    }
}
