package com.novatronic.sixwsg.nextel.sixasincrono.server.exception;

/**
 * Clase que maneja las excepciones de los filtros
 *
 * @author Ricardo Castillejo Luna - NOVATRONIC SAC
 * @version 01.00.00
 * @since Created 23-11-2012 <br> <table border=1> <tr> <td
 * align='center'>Version</td> <td align='center'>Fecha</td> <td
 * align='center'>Modificado por</td><td align='center'>Metodo Modificado</td>
 * <td align='center'>Explicacion del cambio</td> </tr>
 * <tr><td>01.00.00</td><td>05-12-2012</td><td>Ricardo Castillejo Luna
 * (RCL)</td><td>todos</td><td>Refactorizacion de Código</td></tr> </table>
 */
public class FilterException extends RuntimeException {

    private static final long serialVersionUID = -2452401899192942926L;

    /**
     * Metodo constructor
     */
    public FilterException() {
        super();
    }

    /**
     * Metodo constructor asigna mensaje y excepcion
     *
     * @param message - mensaje
     * @param cause - excepcion
     */
    public FilterException(String message, Throwable cause) {
        super(message, cause);
    }

    /**
     * Metodo constructor que asigna mensaje
     *
     * @param message - mensaje
     */
    public FilterException(String message) {
        super(message);
    }

    /**
     * Metodo constructor que asigna excepción
     *
     * @param cause - excepcion
     */
    public FilterException(Throwable cause) {
        super(cause);
    }
}
