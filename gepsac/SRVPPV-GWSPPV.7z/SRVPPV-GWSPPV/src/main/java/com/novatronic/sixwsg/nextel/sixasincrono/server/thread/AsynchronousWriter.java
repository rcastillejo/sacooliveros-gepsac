package com.novatronic.sixwsg.nextel.sixasincrono.server.thread;

import com.novatronic.sixwsg.nextel.sixasincrono.logging.BRKLogger;
import com.novatronic.sixwsg.nextel.sixasincrono.server.Broker;
import com.novatronic.sixwsg.nextel.sixasincrono.server.Data;
import com.novatronic.sixwsg.nextel.sixasincrono.util.Constants;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.text.MessageFormat;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.TimeUnit;

/**
 * @author rcastillejo
 *
 */
/**
 * Clase que obtiene el objeto DTO de la cola de comunicacion y almacena en el
 * API SIX
 *
 * @author Ricardo Castillejo Luna - NOVATRONIC SAC
 * @version 01.00.00
 * @since Created 23-11-2012 <br> <table border=1> <tr> <td
 * align='center'>Version</td> <td align='center'>Fecha</td> <td
 * align='center'>Modificado por</td><td align='center'>Metodo Modificado</td>
 * <td align='center'>Explicacion del cambio</td> </tr>
 * <tr><td>01.00.00</td><td>05-12-2012</td><td>Ricardo Castillejo Luna
 * (RCL)</td><td>todos</td><td>Refactorizacion de Código</td></tr> </table>
 */
public class AsynchronousWriter implements Runnable {

    /**
     * Variable indicadora para continuar la ejecucion del Hilo de la instancia
     * de broker
     */
    private boolean continuaBroker = true;
    /**
     * Clase que permite el manejo del API SIX
     */
    private final Class classApiSix;
    /**
     * Variable para referenciar instacia de API SIX
     */
    private Object instanceApiSix;
    /**
     * Clase de estados
     */
    private Data dataThread;
    /**
     * Cola de comunicacion entre hilos
     */
    private BlockingQueue<AsynchronousDTO> colaSCJToSix;
    private static final String MSG_APISIX_RECV = "Se enviaron [{0}] bytes al SIX. rc({1}) con la interface [{2}]";

    /**
     * Metodo constructor de la clase, para una instancia en particular
     *
     * @param classApiSix Clase de API SIX
     * @param dataThread clase de estados
     * @param colaSCJToSix cola de comunicacion
     * @throws InstantiationException
     * @throws IllegalAccessException
     */
    public AsynchronousWriter(Class classApiSix, Data dataThread,
            BlockingQueue<AsynchronousDTO> colaSCJToSix)
            throws InstantiationException, IllegalAccessException {

        this.classApiSix = classApiSix;
        this.instanceApiSix = classApiSix.newInstance();
        this.dataThread = dataThread;
        this.colaSCJToSix = colaSCJToSix;

    }

    /**
     * Metodo con el contexto de ejecucion del hilo, realiza: <br> 1) Lee el
     * mensaje de la cola de comunicacion <br> 2) Arma y envia la trama <br> 4)
     * Escribe el mensaje en el SIX <br>
     */
    public void run() {

        int rc;
        BRKLogger.msgInfo(null, AsynchronousWriter.class.getSimpleName(), Constants.METHOD_RUN, MessageFormat.format(Constants.MSG_RUN_START, AsynchronousWriter.class.getSimpleName()));

        // ----------------------------------------------------------------------------------------------------------------------- //
        //
        // MAIN LOOP - PROCESS MESSAGES
        //
        // ----------------------------------------------------------------------------------------------------------------------- //

        byte[] byteArrMessage;

        AsynchronousDTO asynchronousDTO;
        String id = null;
        String returnTo;

        Field fieldMesgLen = null;
        Field fieldMesgData = null;
        Field fieldDestName = null;
        Method methodJavSixApiGen = null;

        short shortParamSIXSEND = -1;

        try {
            fieldMesgLen = classApiSix.getDeclaredField("mesg_len");
            fieldMesgData = classApiSix.getDeclaredField("mesg_data");
            fieldDestName = classApiSix.getDeclaredField("dest_name");
            shortParamSIXSEND = classApiSix.getDeclaredField("SIX_SEND").getShort(null);
            methodJavSixApiGen = classApiSix.getMethod("javasix_apigen", short.class);
        } catch (Exception e2) {
            BRKLogger.msgError(id, AsynchronousWriter.class.getSimpleName(), Constants.METHOD_RUN, Constants.MSG_ERROR_APIXSIX_QUEUE, e2);
            return;
        }



        LOOP_BROKER:
        while (continuaBroker && Broker.isContinuaTodoBroker()) {
            // -------------------------------------------------------------------------------------------------------------- //
            //
            // Lee el mensaje de cola de comunicacion
            //
            // -------------------------------------------------------------------------------------------------------------- //

            while (true) {
                try {
                    asynchronousDTO = colaSCJToSix.poll(1000, TimeUnit.MILLISECONDS);
                    if (asynchronousDTO != null) {
                        break;
                    } else {
                        if (!continuaBroker || !Broker.isContinuaTodoBroker()) {
                            continue LOOP_BROKER;
                        }
                    }
                } catch (InterruptedException e2) {
                    if (!continuaBroker || !Broker.isContinuaTodoBroker()) {
                        continue LOOP_BROKER;
                    }
                }
            }

            id = asynchronousDTO.getId();
            byteArrMessage = asynchronousDTO.getByteArrMessage();
            returnTo = asynchronousDTO.getRequestingInterface();

            // ----------------------------------------------------------------------------------------------------------------------- //
            //
            // CALL SIX_SNDRSP FUNCTION
            //
            // ----------------------------------------------------------------------------------------------------------------------- //
            try {

                fieldMesgLen.setShort(instanceApiSix, (short) (byteArrMessage.length));
                System.arraycopy(byteArrMessage, 0, (byte[]) fieldMesgData.get(instanceApiSix), 0, byteArrMessage.length);
                fieldDestName.set(instanceApiSix, returnTo);

                rc = ((Integer) methodJavSixApiGen.invoke(instanceApiSix, shortParamSIXSEND)).intValue();

                BRKLogger.msgDebug(id, AsynchronousWriter.class.getSimpleName(), Constants.METHOD_RUN, MessageFormat.format(MSG_APISIX_RECV, byteArrMessage.length, rc, returnTo));
                asynchronousDTO.setResponseCode(rc);
                
            } catch (Exception e1) {
                BRKLogger.msgError(id, AsynchronousWriter.class.getSimpleName(), Constants.METHOD_RUN, Constants.MSG_ERROR_APIXSIX_QUEUE, e1);
                continuaBroker = false;
                continue;
            }

            this.dataThread.setStatus(Constants.STATUS_READING);
        }

        this.dataThread.setStatus(Constants.STATUS_DOWN);

        BRKLogger.msgDebug(id, AsynchronousWriter.class.getSimpleName(), Constants.METHOD_RUN+ " y cierre de API SIX", MessageFormat.format(Constants.MSG_RUN_END, new Object[]{AsynchronousWriter.class.getSimpleName()}));
    }

    /**
     * Retorna la clase de estados
     *
     * @return Data
     */
    public Data getData() {
        return dataThread;
    }
}
