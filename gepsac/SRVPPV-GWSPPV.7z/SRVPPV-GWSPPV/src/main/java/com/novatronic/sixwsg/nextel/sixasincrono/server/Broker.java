/*
 * @(#)Broker.java
 * Copyright (c) 2006 NOVATRONIC SAC
 * All rights reserved.
 * Creado el 03 de Febrero 2006
 */
package com.novatronic.sixwsg.nextel.sixasincrono.server;
//
import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Properties;
import java.util.Set;
import java.util.TreeMap;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.atomic.AtomicInteger;

import sun.misc.Signal;
import sun.misc.SignalHandler;

import com.novatronic.formatter.FormatterFactory;
import com.novatronic.sixwsg.entel.mapper.MapperFactory;
import com.novatronic.sixwsg.entel.proxyrs.ProxyFactory;
import com.novatronic.sixwsg.nextel.sixasincrono.bd.SingletonBDClient;
import com.novatronic.sixwsg.nextel.sixasincrono.logging.BRKLogger;
import com.novatronic.sixwsg.nextel.sixasincrono.server.thread.AsynchronousDTO;
import com.novatronic.sixwsg.nextel.sixasincrono.server.thread.AsynchronousReader;
import com.novatronic.sixwsg.nextel.sixasincrono.server.thread.AsynchronousWriter;
import com.novatronic.sixwsg.nextel.sixasincrono.server.thread.KiwoxSender;
import com.novatronic.sixwsg.nextel.sixasincrono.server.thread.SMSSender;
import com.novatronic.sixwsg.nextel.sixasincrono.server.thread.SynchronousProcess;
import com.novatronic.sixwsg.nextel.sixasincrono.server.thread.Worker;
import com.novatronic.sixwsg.nextel.sixasincrono.util.BrokerType;
import com.novatronic.sixwsg.nextel.sixasincrono.util.Constants;
import com.novatronic.sixwsg.nextel.sixasincrono.util.DTOSMSMessage;
import com.novatronic.sixwsg.nextel.sixasincrono.util.KiwoxMessage;
import com.novatronic.sixwsg.nextel.sixasincrono.utils.factories.BinAdquirienteFactory;
import com.novatronic.sixwsg.nextel.transaction.bucketBalanceSearchFactory.TransactionBucketBalanceSearchFactory;
import com.novatronic.sixwsg.nextel.transactions.bucketBalanceWriteFactory.TransactionBucketBalanceWriteFactory;
import com.novatronic.sixwsg.nextel.transactions.chkConectivityPrepayReadFactory.TransactionChkConectivityPrepayReadFactory;
import com.pe.nova.components.bd.exception.BDException;

/**
 * Clase que distribuye los mensajes del SIX hacia el web services del bbva. La
 * comunicacion entre el broker y web services es via soap xml.
 *
 * @author Ricardo Castillejo Luna - NOVATRONIC SAC
 * @version 01.00.00
 * @since Created 23-11-2012 <br> <table border=1> <tr> <td
 * align='center'>Version</td> <td align='center'>Fecha</td> <td
 * align='center'>Modificado por</td><td align='center'>Metodo Modificado</td>
 * <td align='center'>Explicacion del cambio</td> </tr>
 * <tr><td>01.00.00</td><td>05-12-2012</td><td>Ricardo Castillejo Luna
 * (RCL)</td><td>todos</td><td>Refactorizacion de Código</td></tr> </table>
 */
public class Broker {

    private Broker() {
    }
    //  Variables estaticas para todas las instancias
    private static Data threadData[] = null;
    /**
     * Variable indicadora de analisis de threads en caso de shutdown
     */
    private static boolean yaEntroAnalizar = false;
    /**
     * Variable indicadora de analisis de threads en caso de shutdown
     */
    private static boolean continuaTodoBroker = true;
    /**
     * Objeto thread group para los hilos
     */
    private static ThreadGroup grupoHilos = new ThreadGroup("BrokerThreadGroup");
    /**
     * Clase que permite el manejo del API SIX
     */
    private static Class classApiSix;
    /**
     * Tipificador del tipo de broker Sincrono o Asincrono
     */
    private static BrokerType brokerType;
    /**
     * Total de Transacciones en curso
     */
    private static AtomicInteger currentTransactions = new AtomicInteger(0);
    static FormatterFactory nextelPPVFormatFactory;

    /**
     * Metodo estatico para invocar el shutdown del controlador
     *
     * @param id
     * @param portNumber
     * @param numThreads
     * @param timeForThreadsMili
     * @param brokerIntervalMili
     */
    public static void shutdownControlador(String id, int numThreads, int timeForThreadsMili, int brokerIntervalMili) {

        //  Valida si ya entro a analizar alguno de los threads

        boolean analizar = false;

        synchronized (Broker.class) {
            if (!yaEntroAnalizar) {
                yaEntroAnalizar = true;
                analizar = true;
            }
        }

        if (analizar) {
            // -------------------------------------------------------------------------------------------------------------- //
            //
            // Mecanismo de verificacion de transacciones en proceso					
            //
            // -------------------------------------------------------------------------------------------------------------- //
            int retry = timeForThreadsMili / brokerIntervalMili;
            int c = 1;
            boolean flagChequeo = true;
            while (flagChequeo && retry-- > 0) {
                flagChequeo = false;
                for (int i = 0; i < numThreads; i++) {
                    BRKLogger.msgDebug(id, Broker.class.getSimpleName(), Constants.METHOD_RUN, "Verificando estado del hilo-" + i + ": [" + threadData[i].getStatus() + "]");
                    if (threadData[i].isProcess()) {
                        flagChequeo = true;
                    } else {
                        threadData[i].setStatus(Constants.STATUS_DOWN);
                    }
                }

                if (flagChequeo) {
                    try {
                        BRKLogger.msgDebug(id, Broker.class.getSimpleName(), Constants.METHOD_RUN, "Threads ocupados, esperando 5 segundos para realizar el (" + c + ") reintento.");
                        Thread.sleep(brokerIntervalMili);
                    } catch (Exception e) {
                    }
                }
                c++;
            }
        }

    }

    /**
     * Metodo de ejecucion main
     *
     * @param args Array con los parametros de entrada
     */
    public static void main(String[] args) {

        //  Se leen las propiedades del Broker (broker.properties) y las propiedades de los endpoints ()
        Properties propiedades = null;
        Properties propiedadesBD = null;
        
        try {
            InputStream filePropiedadesBroker = Broker.class.getClassLoader().getResourceAsStream("./broker.properties");
            propiedades = new Properties();
            propiedades.load(filePropiedadesBroker);
            filePropiedadesBroker.close();
        } catch (Exception e) {
            System.out.println("No se ha encontrado el archivo de propiedades: " + e.getMessage() + ". Realizaremos down.");
            System.exit(1);
        }

        // --------------------------------------------------------------------------------- //
        //
        // ASIGNA PARAMETROS
        //
        // --------------------------------------------------------------------------------- //        
        String brokerName = (String) propiedades.getProperty("BrokerName");
        String archCfgLog = (String) propiedades.getProperty("BrokerConfigLog");
        int timeForThreads = Integer.parseInt((String) propiedades.getProperty("BrokerTimeToBusyThreads"));
        int brokerInterval = Integer.parseInt((String) propiedades.getProperty("BrokerInterval"));
        BRKLogger.init(archCfgLog);
        int numThreads = Integer.parseInt((String) propiedades.getProperty("ControllerThreads"));
        short maxMsgLen = (short) Integer.parseInt((String) propiedades.getProperty("ControllerMessageLen"));
        int intSearchBucketBalanceWSTimeout = Integer.parseInt((String) propiedades.getProperty("SearchBucketBalanceWSTimeout"));
        int intWriteBucketBalanceWSTimeout = Integer.parseInt((String) propiedades.getProperty("WriteBucketBalanceWSTimeout"));
        int intChckConectivityPrepayReadWSTimeout = Integer.parseInt((String) propiedades.getProperty("ChckConectivityPrepayReadWSTimeout"));
        String serverName = (String) propiedades.getProperty("SIXServer");
        
        String instanceID = System.getProperty("INSTANCE_ID");
        
        if(!instanceID.equals("000")){
        	serverName = serverName.substring(0, 5) + instanceID;
        }
        
        String formatXML = (String) propiedades.getProperty("FormatXml");
        String strBrokerType = "SYN";
        String requestInterface = propiedades.getProperty("RequestInterface");
        String outputApp = propiedades.getProperty("outputApp","");
        
        //NextelPPVFormatter nextelPPVFormat = new NextelPPVFormatter();
        String urlWsBucketBalanceSearch = "";
        String urlWsBucketBalanceWrite = "";
        String urlWsChckConectivityPrepayRead = "";
        
        String spBDBucketBalanceSearch = "";
        String spBDBucketBalanceWrite = "";
        String spBDChckConectivityPrepayRead = "";
        
        if(outputApp.equals(Constants.BD)){
            try {
                InputStream filePropiedadesBD = Broker.class.getClassLoader().getResourceAsStream("./BDConfig.properties");
                propiedadesBD = new Properties();                
                propiedadesBD.load(filePropiedadesBD);                
                filePropiedadesBD.close();
                BRKLogger.msgInfo(null, Broker.class.getSimpleName(), Constants.METHOD_MAIN, "Se carga aplicacion con salida a BD");
                spBDBucketBalanceSearch = propiedades.getProperty("spBDBucketBalanceSearch");
                spBDBucketBalanceWrite = propiedades.getProperty("spBDBucketBalanceWrite");
                spBDChckConectivityPrepayRead = propiedades.getProperty("spBDChckConectivityPrepayRead");
                SingletonBDClient.init(propiedadesBD, propiedadesBD);
            } catch (IOException e) {
                BRKLogger.msgError(null, Broker.class.getSimpleName(), Constants.METHOD_MAIN, "No se ha encontrado el archivo de propiedades de la BD: " + e.getMessage() + ". Realizaremos down.", e);
                System.exit(1);
            } catch (BDException e) {
                BRKLogger.msgError(null, Broker.class.getSimpleName(), Constants.METHOD_MAIN, "No se pudo conectar a la BD, verifique los parametros. Realizamos down", e);
                System.exit(1);
            }
        }else if(outputApp.equals(Constants.WS)){
            urlWsBucketBalanceSearch = propiedades.getProperty("UrlWSBucketBalanceSearch");
            urlWsBucketBalanceWrite = propiedades.getProperty("UrlWSBucketBalanceWrite");
            urlWsChckConectivityPrepayRead = propiedades.getProperty("UrlWSChckConectivityPrepayRead");
            BRKLogger.msgInfo(null, Broker.class.getSimpleName(), Constants.METHOD_MAIN, "Se carga aplicacion con salida a WS");            
        }else{
            BRKLogger.msgInfo(null, Broker.class.getSimpleName(), Constants.METHOD_MAIN, "No se especifico una aplicacion de salida valida. Realizamos down");
            System.exit(1);
        }

        /**
         * Se carga la lista de codigos de Error y sus correspondientes Mensajes
         */
        BRKLogger.msgInfo(null, Broker.class.getSimpleName(), Constants.METHOD_MAIN, "Iniciando GatewayPPV ["+serverName+"]");
        BRKLogger.msgDebug(null, Broker.class.getSimpleName(), Constants.METHOD_MAIN, "Parametros: " + propiedades.toString());

        // --------------------------------------------------------------------------------- //
        //
        // IDENTIFICACION DE TIPO DE BROKER
        //
        // --------------------------------------------------------------------------------- //
        identificaTipoBroker(strBrokerType);

        // --------------------------------------------------------------------------------- //
        //
        // APERTURANDO LA CONEXION CON EL SIX
        //
        // --------------------------------------------------------------------------------- //
        aperturaConexionSIX(serverName);

        // --------------------------------------------------------------------------------- //
        //
        // CONFIGURACION DEL CERTIFICADO
        //
        // --------------------------------------------------------------------------------- //
        try {
            settingTrustedProperties(propiedades);
        } catch (Exception e) {
            BRKLogger.msgError(null, Broker.class.getSimpleName(), Constants.METHOD_RUN, "NO se ha realizado la configuracion del certificado", e);
            System.exit(1);
        }
        // --------------------------------------------------------------------------------- //
        //
        // CONFIGURACION DE LAS TRANSACCIONES
        //
        // --------------------------------------------------------------------------------- //
        try {
            TransactionBucketBalanceWriteFactory.init(propiedades);
            TransactionBucketBalanceSearchFactory.init(propiedades);
            TransactionChkConectivityPrepayReadFactory.init(propiedades);
        } catch (Exception e) {
            BRKLogger.msgError(null, Broker.class.getSimpleName(), Constants.METHOD_RUN, "NO se ha realizado la configuracion de las transacciones", e);
            System.exit(1);
        }
        // --------------------------------------------------------------------------------- //
        //
        // CONFIGURACION DE LA LISTA DE BINES ADQUIRIENTE
        //
        // --------------------------------------------------------------------------------- //
        try {
            BinAdquirienteFactory.init(propiedades);
        } catch (Exception e) {
            BRKLogger.msgError(null, Broker.class.getSimpleName(), Constants.METHOD_RUN, "NO se ha realizado la configuracion de la lista de Bines Adquiriente", e);
            System.exit(1);
        }

        // --------------------------------------------------------------------------------- //
        //
        // CONFIGURANDO EL FORMATEADOR
        //
        // --------------------------------------------------------------------------------- //
        try {
            InputStream file = Broker.class.getClassLoader().getResourceAsStream(formatXML);
            nextelPPVFormatFactory = new FormatterFactory(file);
            file.close();
        } catch (Exception e) {
            BRKLogger.msgError(null, Broker.class.getSimpleName(), Constants.METHOD_RUN, "NO se ha encontrado el archivo formateador[" + formatXML + "].", e);
            System.exit(1);
        }       
        
        // --------------------------------------------------------------------------------- //
        //
        // CONFIGURANDO EL PROXY
        //
        // --------------------------------------------------------------------------------- //
        String proxyConfig = propiedades.getProperty("proxyrs.config");
        try {
            ProxyFactory.configure(proxyConfig);
        } catch (Exception e) {
            BRKLogger.msgError(null, Broker.class.getSimpleName(), Constants.METHOD_RUN, "Error en la configuracion del proxy[" + proxyConfig + "].", e);
            System.exit(1);
        }
        
        // --------------------------------------------------------------------------------- //
        //
        // CONFIGURANDO EL MAPPER
        //
        // --------------------------------------------------------------------------------- //
        try {
            MapperFactory.init("broker.properties");
        } catch (Exception e) {
            BRKLogger.msgError(null, Broker.class.getSimpleName(), Constants.METHOD_RUN, "Error en la configuracion del proxy[" + proxyConfig + "].", e);
            System.exit(1);
        }
        
        // --------------------------------------------------------------------------------- //
        //
        // INICIANDO HILOS DE ATENCION
        //
        // --------------------------------------------------------------------------------- //


        /*
         * Los procesos syncronicos deben usar uno y solo un Thread para leer de la cola
         * otros Threads deben escribir en la cola a donde se reenvia el mensaje procesado.
         * El Thread que lee y los que escriben deben estar comunicados por una cola Java.
         * deben manejar diferentes instancias de API SIX sino =======> CORE DUMP en la nativa
         * Esto es hasta la version 3.2.1 de SIX... si se tienen revisiones superiores
         * validar ya que puede haber cambiado para mejor 
         */


        /*
         * Carga configuracion de filtros; en caso no hayan filtros los mensajes se pasan sin alterar
         */

        Map<String, Properties> configFiltersMap = null;
        Map<String, String> mapeoInterfacesFiltrosMap = null;

        Map<String, Object> infoFiltros = null;

        String strFilters = propiedades.getProperty("Filters");
        if (strFilters != null && strFilters.trim().length() > 0) {
            BRKLogger.msgDebug(null, Broker.class.getSimpleName(), Constants.METHOD_MAIN, "Procede a cargar informacion para tratamiento de mensajes segun interfaz de procedencia");

            // Leemos configuracion de filtros 
            configFiltersMap = new HashMap<String, Properties>();
            mapeoInterfacesFiltrosMap = new LinkedHashMap<String, String>();

            // Se determinan que filtros estan configurados
            String[] filters = strFilters.split(",");

            // Se lee y separa la configuracion de cada filtro 
            for (String strFilter : filters) {

                Properties propsFilter = new Properties();

                Set llaves = propiedades.keySet();
                for (Object object : llaves) {
                    String llave = (String) object;
                    if (llave.startsWith("Filter." + strFilter + ".")) {
                        String llaveFiltro = llave.replaceFirst("Filter." + strFilter + ".", "");
                        if (llaveFiltro.trim().length() > 0) {
                            propsFilter.setProperty(llaveFiltro.trim(), propiedades.getProperty(llave).trim());
                        }
                    }
                }

                BRKLogger.msgDebug(null, Broker.class.getSimpleName(), Constants.METHOD_MAIN, "Se ha leido configuracion de filtro alias [" + strFilter + "], " + propsFilter);
                configFiltersMap.put(strFilter, propsFilter);

            }

            // Se realiza la carga de mapeos de interfaces y filtros
            Set llaves = propiedades.keySet();
            Map<Integer, Map<String, String>> temporalDefinicionPrioridad = new TreeMap<Integer, Map<String, String>>();
            for (Object object : llaves) {
                String llave = (String) object;
                if (llave.startsWith("Map.")) {
                    String llaveMapeo = llave.replaceFirst("Map.", "");
                    int posicionPrimerPunto = llaveMapeo.indexOf('.');
                    if (posicionPrimerPunto > 0) {
                        // Lo que esta antes del punto es la prioridad
                        int prioridad;
                        String expresionRegular;
                        try {
                            prioridad = Integer.parseInt(llaveMapeo.substring(0, posicionPrimerPunto));
                        } catch (Exception e) {
                            BRKLogger.msgError(null, Broker.class.getSimpleName(), Constants.METHOD_MAIN, "Definicion incorrecta en mapeo: " + llave + "=" + propiedades.getProperty(llave), null);
                            continue;
                        }
                        // Lo que esta despues del punto es la expresion regular
                        if ((llaveMapeo.trim().length() - 1) > posicionPrimerPunto) {
                            expresionRegular = llaveMapeo.substring(posicionPrimerPunto + 1).trim();
                        } else {
                            BRKLogger.msgError(null, Broker.class.getSimpleName(), Constants.METHOD_MAIN, "Definicion incorrecta en mapeo: " + llave + "=" + propiedades.getProperty(llave), null);
                            continue;
                        }
                        if (temporalDefinicionPrioridad.containsKey(prioridad)) {
                            temporalDefinicionPrioridad.get(prioridad).put(expresionRegular, propiedades.getProperty(llave).trim());
                        } else {
                            Map<String, String> temporalMismaPrioridad;
                            temporalMismaPrioridad = new HashMap<String, String>();
                            temporalMismaPrioridad.put(expresionRegular, propiedades.getProperty(llave).trim());
                            temporalDefinicionPrioridad.put(prioridad, temporalMismaPrioridad);
                        }

                    }
                }
            }

            for (Integer prioridad : temporalDefinicionPrioridad.keySet()) {
                Map<String, String> temporalMismaPrioridad = temporalDefinicionPrioridad.get(prioridad);
                mapeoInterfacesFiltrosMap.putAll(temporalMismaPrioridad);
            }

            BRKLogger.msgDebug(null, Broker.class.getSimpleName(), Constants.METHOD_MAIN, "Se han cargado los siguientes mapeos interfaz-filtro: " + mapeoInterfacesFiltrosMap);

            infoFiltros = new HashMap<String, Object>();

            infoFiltros.put("mapeoInterfacesFiltrosMap", mapeoInterfacesFiltrosMap);
            infoFiltros.put("configFiltersMap", configFiltersMap);
        }

        /**
         * Inicialización de Procesos Sincronicos o asincronicos segun sea el
         * caso
         */
        switch (brokerType) {

            case SYN:

                /*
                 * Los procesos syncronicos pueden usar una instancia del API SIX
                 * en un mismo Thread para leer de la cola y responder al SIX
                 */
                threadData = new Data[numThreads];
                Object tokenSynchroSyn = new Object();

                for (int brkId = 0; brkId < numThreads; brkId++) {

                    Data dataThread_i = new Data();
                    threadData[brkId] = dataThread_i;

                    SynchronousProcess synchronousProcess = null;
                    SMSSender smsSender = null;
                    KiwoxSender kiwoxSender = null;
                    // Queue
                    BlockingQueue<DTOSMSMessage> colaSms = new LinkedBlockingQueue<DTOSMSMessage>();
                    BlockingQueue<KiwoxMessage> colaKiwox = new LinkedBlockingQueue<KiwoxMessage>();
                    
                    
                    
                    
                    
                    
                    try {
                        synchronousProcess = new SynchronousProcess(
                                brkId, brokerName, numThreads, maxMsgLen, intSearchBucketBalanceWSTimeout, intWriteBucketBalanceWSTimeout, intChckConectivityPrepayReadWSTimeout,
                                serverName, timeForThreads, brokerInterval, classApiSix,
                                dataThread_i, requestInterface, tokenSynchroSyn, infoFiltros, nextelPPVFormatFactory, urlWsBucketBalanceSearch, urlWsBucketBalanceWrite, urlWsChckConectivityPrepayRead,
                        spBDBucketBalanceSearch,
                        spBDBucketBalanceWrite,
                        spBDChckConectivityPrepayRead,outputApp,colaSms,colaKiwox,propiedades); // Add Queue
                        
                        // New Trhread (QUeue)
                       
                        String urlServicioEnvioSMS = propiedades.getProperty("UrlWSEnvioDeSms");
                        String urlWsdlEnvioSMS = propiedades.getProperty("UrlWSDLEnvioDeSms");
                        smsSender = new SMSSender(colaSms, urlServicioEnvioSMS, urlWsdlEnvioSMS, propiedades);
                        kiwoxSender = new KiwoxSender(colaKiwox, propiedades);
                        
                        
                    } catch (Exception e) {

                        BRKLogger.msgError(null, Broker.class.getSimpleName(), "main", "No se pudo crear proceso sincrono [" + brkId + "]", e);
                        System.exit(10);

                    }

                    Thread exeBroker = new Thread(grupoHilos, synchronousProcess);
                    exeBroker.setName("ProcessSIX" + brkId);
                    exeBroker.start();

                    Thread exeSMSSender = new Thread(smsSender);
                    exeSMSSender.setName("SMSSender" + brkId);
                    exeSMSSender.start();

                    Thread exeKiwoxSender = new Thread(kiwoxSender);
                    exeKiwoxSender.setName("KiwoxSender" + brkId);
                    exeKiwoxSender.start();
                    
                }

                break;

            case ASY:

                threadData = new Data[numThreads + 2];
                Data dataThreadI;
                Thread exeBroker;


                BlockingQueue<AsynchronousDTO> colaSixToSCJ = new LinkedBlockingQueue<AsynchronousDTO>();
                BlockingQueue<AsynchronousDTO> colaSCJToSix = new LinkedBlockingQueue<AsynchronousDTO>();

                Object tokenSynchro = new Object();

                /**
                 * Inicio de la modificacion del Broker para el GatewayWS Banca
                 * Movil
                 */
                /**
                 * Se quitaron variables innecesarias para este proceso del
                 * Worker y se adicionaron para la comunicacion del web services
                 *
                 * Autor: Ricardo Castillejo Luna
                 */
                for (int workerId = 0; workerId < numThreads; workerId++) {

                    dataThreadI = new Data();
                    threadData[workerId] = dataThreadI;

                    Worker worker = null;

                    try {
                        worker = new Worker(
                                workerId,
                                maxMsgLen, intSearchBucketBalanceWSTimeout, intWriteBucketBalanceWSTimeout, intChckConectivityPrepayReadWSTimeout,
                                dataThreadI, colaSixToSCJ, colaSCJToSix,
                                tokenSynchro, infoFiltros, nextelPPVFormatFactory, urlWsBucketBalanceSearch, urlWsBucketBalanceWrite, urlWsChckConectivityPrepayRead,
                                spBDBucketBalanceSearch,
                                spBDBucketBalanceWrite,
                                spBDChckConectivityPrepayRead,outputApp);
                    } catch (Exception e) {

                        BRKLogger.msgError(null, Broker.class.getSimpleName(), Constants.METHOD_RUN, "No se pudo crear proceso Asincrono Worker[" + workerId + "]", e);
                        System.exit(10);

                    }

                    exeBroker = new Thread(grupoHilos, worker);
                    exeBroker.setName("Worker_" + workerId);
                    exeBroker.start();

                }


                dataThreadI = new Data();
                threadData[numThreads + 1] = dataThreadI;

                AsynchronousWriter asynchronousWriter = null;

                try {
                    asynchronousWriter = new AsynchronousWriter(
                            classApiSix,
                            dataThreadI,
                            colaSCJToSix);
                } catch (Exception e) {

                    BRKLogger.msgError(null, Broker.class.getSimpleName(), Constants.METHOD_RUN, "No se pudo crear proceso Asincrono SCJ to SIX", e);
                    System.exit(10);

                }

                exeBroker = new Thread(grupoHilos, asynchronousWriter);
                exeBroker.setName("WriterToSIX");
                exeBroker.start();


                dataThreadI = new Data();
                threadData[numThreads + 1] = dataThreadI;

                AsynchronousReader asynchronousReader = null;

                try {
                    asynchronousReader = new AsynchronousReader(
                            brokerName, numThreads,
                            maxMsgLen, serverName,
                            timeForThreads, brokerInterval, classApiSix,
                            dataThreadI, colaSixToSCJ, tokenSynchro, requestInterface);
                } catch (Exception e) {

                    BRKLogger.msgError(null, Broker.class.getSimpleName(), Constants.METHOD_RUN, "No se pudo crear proceso Asincrono SIX to SCJ", e);
                    System.exit(10);

                }

                exeBroker = new Thread(grupoHilos, asynchronousReader);
                exeBroker.setName("ReaderFromSIX");
                exeBroker.start();


                /**
                 * Fin de la modificacion del Broker para el GatewayWS Banca
                 * Movil
                 */
                // --------------------------------------------------------------------------------- //
                //
                // REGISTRO DE MANEJADOR DE SE�AL DE SHUTDOWN
                //
                // --------------------------------------------------------------------------------- //
                registroSignalHandler(timeForThreads, brokerInterval, numThreads);

                break;

            default:
                break;

        }

    }

    /**
     * Metodo que apertura la conexion al six.
     *
     * @param serverName - nombre del servidor six
     */
    private static void aperturaConexionSIX(String serverName) {
        int rc = -1;
        try {

            classApiSix = Class.forName(brokerType.getClassName());
            BRKLogger.msgDebug(null, Broker.class.getSimpleName(), Constants.METHOD_MAIN, "Carga dinamica de clase de APISIX[" + classApiSix.getName() + "]");

            //Creamos objeto de instancia de API para apertura en SIX
            Object instanceApiSix = classApiSix.newInstance();

            Field field;
            field = classApiSix.getDeclaredField("serv_name");
            field.set(instanceApiSix, serverName);
            field = classApiSix.getDeclaredField("SIX_OPEN");
            short shortParam = field.getShort(null);

            Method method = null;

            switch (brokerType) {
                case SYN:
                    field = classApiSix.getDeclaredField("appl_prof");
                    field.setByte(instanceApiSix, (byte) (new Character('N')).charValue());

                    field = classApiSix.getDeclaredField("appl_mode");
                    field.setByte(instanceApiSix, (byte) (new Character('S')).charValue());

                    method = classApiSix.getMethod("javasix_apiloc", short.class);

                    break;

                case ASY:

                    field = classApiSix.getDeclaredField("serv_type");
                    field.setByte(instanceApiSix, (byte) (new Character('D')).charValue());

                    method = classApiSix.getMethod("javasix_apigen", short.class);

                    break;
                default:
                    BRKLogger.msgError(null, Broker.class.getSimpleName(), Constants.METHOD_RUN, "Tipo de BROKER no es SYNCRONO ni ASINCRONO.", null);
                    System.exit(5);
            }

            BRKLogger.msgDebug(null, Broker.class.getSimpleName(), Constants.METHOD_MAIN, "Aperturamos conexion con el SIX: [" + serverName + "]");
            rc = ((Integer) method.invoke(instanceApiSix, shortParam)).intValue();


        } catch (Exception e) {
            BRKLogger.msgError(null, Broker.class.getSimpleName(), Constants.METHOD_MAIN, "Ocurrio un error al incializar el APISIX", e);
            System.exit(4);
        }

        if (rc != 0) {
            BRKLogger.msgError(null, Broker.class.getSimpleName(), Constants.METHOD_MAIN, "Error al aperturar conexion con el SIX: rc(" + rc + ")", null);
            System.exit(3);
        } else {
            BRKLogger.msgInfo(null, Broker.class.getSimpleName(), Constants.METHOD_MAIN, "Conexion establecida con el SIX. rc(" + rc + ")");
        }
    }

    /**
     * Metodo que apertura la conexion al six.
     *
     * @param properties - Contiene las variales de configuracion del aplicativo
     * @throws SecurityException
     * @throws NullPointerException
     * @throws IllegalArgumentException
     */
    private static void settingTrustedProperties(Properties properties) {
        String userDir;

        String flagCertificado = properties.getProperty("SslFlag");

        if (flagCertificado.equals(Constants.CERTIFICADO_HABILITADO)) {

            userDir = System.getProperty(properties.getProperty("SslPath")) + System.getProperty("file.separator");

            BRKLogger.msgDebug(null, Broker.class.getSimpleName(), Constants.METHOD_MAIN, "Asignando la configuracion del certificado ruta - raiz:[" + userDir + "]");

            System.setProperty("javax.net.ssl.trustStore", userDir + properties.getProperty("TrustStoreFile"));
            System.setProperty("javax.net.ssl.keyStore", userDir + properties.getProperty("KeyStoreFile"));
            System.setProperty("javax.net.ssl.trustStorePassword", properties.getProperty("TrustStorePassword"));
            System.setProperty("javax.net.ssl.keyStorePassword", properties.getProperty("KeyStorePassword"));

        } else {

            BRKLogger.msgDebug(null, Broker.class.getSimpleName(), Constants.METHOD_MAIN, "No se realizo la configuracion de Certificados, debido a que esta accion no ha sido habilitado");

        }

    }

    /**
     * Metodo que intercepta las seniales USR1 y USR2 desde el Sistema
     * Operativo.
     *
     * @param numThreads - número de hilos a evaluar
     * @param timeForThreads - tiempo total en segundos para la evaluacion de
     * los hilos
     * @param brokerInterval - intervalo en segundos para la verificacion de
     * hilos
     */
    private static void registroSignalHandler(int timeForThreads, int brokerInterval, int numThreads) {
        BRKLogger.msgDebug(null, Broker.class.getSimpleName(), Constants.METHOD_MAIN, "Registrando listener de senial.");
        SignalHandler sigHnd = new Broker.SignalUSR2Handler(numThreads, timeForThreads, brokerInterval);
        Signal.handle(new Signal("USR2"), sigHnd);
    }

    /**
     * Metodo que identifica el tipo de Broker
     *
     * @param strBrokerType - tipo de broker
     */
    private static void identificaTipoBroker(String strBrokerType) {
        for (BrokerType tipoBroker : BrokerType.values()) {
            if (tipoBroker.name().equals(strBrokerType)) {
                brokerType = tipoBroker;
            }
        }
    }

    /**
     * Metodo que asigna el estado del broker
     *
     * @param continuaTodoBroker - estado del broker a asignar
     */
    public static void setContinuaTodoBroker(boolean continuaTodoBroker) {
        Broker.continuaTodoBroker = continuaTodoBroker;
    }

    /**
     * Metodo que devuelve el estado del broker
     *
     * @return boolean con el estado del broker
     */
    public static boolean isContinuaTodoBroker() {
        return continuaTodoBroker;
    }

    /**
     * Metodo que asigna el Total de Transacciones en curso
     *
     * @param currentTransactions - Total de Transacciones en curso
     */
    public static void setCurrentTransactions(AtomicInteger currentTransactions) {
        Broker.currentTransactions = currentTransactions;
    }

    /**
     * Metodo que devuelve el Total de Transacciones en curso
     *
     * @return AtomicInteger Total de Transacciones en curso
     */
    public static AtomicInteger getCurrentTransactions() {
        return currentTransactions;
    }

    /**
     * Clase para la intercepcion las seniales USR1 y USR2 desde el Sistema
     * Operativo.
     *
     * @author Ricardo Castillejo Luna - NOVATRONIC SAC
     * @version 01.00.00
     * @since Creado 23-11-2012 <br> <table border=1> <tr> <td
     * align='center'>Version</td> <td align='center'>Fecha</td> <td
     * align='center'>Modificado por</td><td align='center'>Metodo
     * Modificado</td> <td align='center'>Explicacion del cambio</td> </tr>
     * <tr><td>01.00.00</td><td>05-12-2012</td><td>Ricardo Castillejo Luna
     * (RCL)</td><td>todos</td><td>Refactorizacion de Código</td></tr> </table>
     */
    private static class SignalUSR2Handler implements SignalHandler {

        /**
         * Número de hilos a evaluar
         */
        private int numThreads;
        /**
         * Tiempo total en milisegundos para la evaluacion de los hilos
         */
        private int timeForThreadsMili;
        /*
         *Intervalo en milisegundos para la verificacion de hilos 
         */
        private int brokerIntervalMili;

        /*
         * Metodo constructor
         * @param numThreads - número de hilos a evaluar
         * @param timeForThreads - tiempo total en segundos para la evaluacion de los
         * hilos
         * @param brokerInterval - intervalo en segundos para la verificacion de hilos
         */
        public SignalUSR2Handler(int numThreads,
                int timeForThreads, int brokerInterval) {
            super();
            this.numThreads = numThreads;
            this.timeForThreadsMili = timeForThreads * Constants.MILIS;
            this.brokerIntervalMili = brokerInterval * Constants.MILIS;
        }

        /*
         * Metodo handle
         * @param sig - senial del sistema operativo
         */
        public void handle(Signal sig) {
            BRKLogger.msgInfo(null, this.getClass().getSimpleName(), "handle", "Se ha recibido la senial USR2");

            // Indicamos que deben finalizar todos los hilos todos los hilos
            // que se encunetran en ejecucion.
            setContinuaTodoBroker(false);
            shutdownControlador(null, numThreads, timeForThreadsMili, brokerIntervalMili);
            BRKLogger.msgInfo(null, this.getClass().getSimpleName(), "handle", "Se finaliza la maquina virtual...");
            System.exit(0);
        }
    };

    public Map<String, Object> cargarFiltros(Properties propiedades) {

        Map<String, Properties> configFiltersMap = null;
        Map<String, String> mapeoInterfacesFiltrosMap = null;

        Map<String, Object> infoFiltros = null;

        String strFilters = propiedades.getProperty("Filters");
        if (strFilters != null && strFilters.trim().length() > 0) {
            BRKLogger.msgDebug(null, Broker.class.getSimpleName(), Constants.METHOD_MAIN, "Procede a cargar informacion para tratamiento de mensajes segun interfaz de procedencia");

            // Leemos configuracion de filtros 
            configFiltersMap = new HashMap<String, Properties>();
            mapeoInterfacesFiltrosMap = new LinkedHashMap<String, String>();

            // Se determinan que filtros estan configurados
            String[] filters = strFilters.split(",");

            // Se lee y separa la configuracion de cada filtro 
            for (String strFilter : filters) {

                Properties propsFilter = new Properties();

                Set llaves = propiedades.keySet();
                for (Object object : llaves) {
                    String llave = (String) object;
                    if (llave.startsWith("Filter." + strFilter + ".")) {
                        String llaveFiltro = llave.replaceFirst("Filter." + strFilter + ".", "");
                        if (llaveFiltro.trim().length() > 0) {
                            propsFilter.setProperty(llaveFiltro.trim(), propiedades.getProperty(llave).trim());
                        }
                    }
                }

                BRKLogger.msgDebug(null, Broker.class.getSimpleName(), Constants.METHOD_MAIN, "Se ha leido configuracion de filtro alias [" + strFilter + "], " + propsFilter);
                configFiltersMap.put(strFilter, propsFilter);

            }

            // Se realiza la carga de mapeos de interfaces y filtros
            Set llaves = propiedades.keySet();
            Map<Integer, Map<String, String>> temporalDefinicionPrioridad = new TreeMap<Integer, Map<String, String>>();
            for (Object object : llaves) {
                String llave = (String) object;
                if (llave.startsWith("Map.")) {
                    String llaveMapeo = llave.replaceFirst("Map.", "");
                    int posicionPrimerPunto = llaveMapeo.indexOf('.');
                    if (posicionPrimerPunto > 0) {
                        // Lo que esta antes del punto es la prioridad
                        int prioridad;
                        String expresionRegular;
                        try {
                            prioridad = Integer.parseInt(llaveMapeo.substring(0, posicionPrimerPunto));
                        } catch (Exception e) {
                            BRKLogger.msgError(null, Broker.class.getSimpleName(), Constants.METHOD_MAIN, "Definicion incorrecta en mapeo: " + llave + "=" + propiedades.getProperty(llave), null);
                            continue;
                        }
                        // Lo que esta despues del punto es la expresion regular
                        if ((llaveMapeo.trim().length() - 1) > posicionPrimerPunto) {
                            expresionRegular = llaveMapeo.substring(posicionPrimerPunto + 1).trim();
                        } else {
                            BRKLogger.msgError(null, Broker.class.getSimpleName(), Constants.METHOD_MAIN, "Definicion incorrecta en mapeo: " + llave + "=" + propiedades.getProperty(llave), null);
                            continue;
                        }
                        if (temporalDefinicionPrioridad.containsKey(prioridad)) {
                            temporalDefinicionPrioridad.get(prioridad).put(expresionRegular, propiedades.getProperty(llave).trim());
                        } else {
                            Map<String, String> temporalMismaPrioridad;
                            temporalMismaPrioridad = new HashMap<String, String>();
                            temporalMismaPrioridad.put(expresionRegular, propiedades.getProperty(llave).trim());
                            temporalDefinicionPrioridad.put(prioridad, temporalMismaPrioridad);
                        }

                    }
                }
            }

            for (Integer prioridad : temporalDefinicionPrioridad.keySet()) {
                Map<String, String> temporalMismaPrioridad = temporalDefinicionPrioridad.get(prioridad);
                mapeoInterfacesFiltrosMap.putAll(temporalMismaPrioridad);
            }

            BRKLogger.msgDebug(null, Broker.class.getSimpleName(), Constants.METHOD_MAIN, "Se han cargado los siguientes mapeos interfaz-filtro: " + mapeoInterfacesFiltrosMap);

            infoFiltros = new HashMap<String, Object>();

            infoFiltros.put("mapeoInterfacesFiltrosMap", mapeoInterfacesFiltrosMap);
            infoFiltros.put("configFiltersMap", configFiltersMap);
        }

        return infoFiltros;
    }
}
