/*
 * @(#)Data.java
 * Copyright (c) 2006 NOVATRONIC SAC
 * All rights reserved.
 * Creado el 22 de Febrero 2006
 */
package com.novatronic.sixwsg.nextel.sixasincrono.server;

import com.novatronic.sixwsg.nextel.sixasincrono.util.Constants;

/**
 * Clase de estados
 *
 * @author Ricardo Castillejo Luna - NOVATRONIC SAC
 * @version 01.00.00
 * @since Created 23-11-2012 <br> <table border=1> <tr> <td
 * align='center'>Version</td> <td align='center'>Fecha</td> <td
 * align='center'>Modificado por</td><td align='center'>Metodo Modificado</td>
 * <td align='center'>Explicacion del cambio</td> </tr>
 * <tr><td>01.00.00</td><td>05-12-2012</td><td>Ricardo Castillejo Luna
 * (RCL)</td><td>todos</td><td>Refactorizacion de Código</td></tr> </table>
 */
public class Data {

    /**
     * Estado de la clase
     */
    private String sta;

    /**
     * Metodo constructor
     */
    public Data() {
        sta = Constants.STATUS_UP;
    }

    /**
     * Metodo que asigna el estado de la clase
     *
     * @param s - estado
     */
    public void setStatus(String s) {
        sta = s;
    }

    /**
     * Metodo que verifica si el proceso se encuentra detenido
     *
     * @return boolean
     */
    public boolean isDown() {
        if (sta.compareTo(Constants.STATUS_DOWN) == 0) {
            return (true);
        }
        return (false);
    }

    /**
     * Metodo que verifica si el proceso se encuentra en proceso
     *
     * @return boolean
     */
    public boolean isProcess() {
        if (sta.compareTo(Constants.STATUS_PROCESS) == 0) {
            return (true);
        }
        return (false);
    }

    /**
     * Metodo que retorna el estado de la clase
     *
     * @return String - estado de la clase
     */
    public String getStatus() {
        return (sta);
    }
}
