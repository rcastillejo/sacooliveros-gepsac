
package com.novatronic.sixwsg.nextel.sixasincrono.server.thread;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.TimeUnit;

import javax.xml.namespace.QName;
import javax.xml.ws.Binding;
import javax.xml.ws.BindingProvider;
import javax.xml.ws.handler.Handler;


import pe.com.nextel.webservices.WSSendSingleSMS;
import pe.com.nextel.webservices.WSSendSingleSMS_Service;
import pe.com.nextel.webservices.types.Message;
import pe.com.nextel.webservices.types.SendSingleMessageElement;
import pe.com.nextel.webservices.types.SendSingleMessageResponseElement;

import com.novatronic.sixwsg.nextel.proxyws.jaxws.handlers.LogHandler;
import com.novatronic.sixwsg.nextel.sixasincrono.logging.BRKLogger;
import com.novatronic.sixwsg.nextel.sixasincrono.util.DTOSMSMessage;

/**
 *
 * @author jbejar
 */
public class SMSSender implements Runnable{
    
    
    private final BlockingQueue<DTOSMSMessage> colaMensajes;
    private final WSSendSingleSMS portEnvioSMS;

    public SMSSender(BlockingQueue<DTOSMSMessage> colaMensajes, String urlServicioEnvioSMS, String strURLWSDL, Properties propiedades) throws MalformedURLException {
        this.colaMensajes = colaMensajes;
        
        WSSendSingleSMS_Service wsSendSingleSMS = new WSSendSingleSMS_Service(new URL(strURLWSDL), new QName("http://webservices.nextel.com.pe/", "WSSendSingleSMS"));
        portEnvioSMS = wsSendSingleSMS.getWSSendSingleSMS();

        BindingProvider bp = (BindingProvider) portEnvioSMS;
        bp.getRequestContext().put(BindingProvider.ENDPOINT_ADDRESS_PROPERTY, urlServicioEnvioSMS);
        bp.getRequestContext().put(propiedades.getProperty("PropTimeoutConnectEnvioSMS"), propiedades.getProperty("TimeoutConnectEnvioSMS"));
        bp.getRequestContext().put(propiedades.getProperty("PropTimeoutEnvioSMS"), propiedades.getProperty("TimeoutEnvioSMS"));
        
		Binding binding = bp.getBinding();
		// List<Handler> handlerChain = binding.getHandlerChain();
		List<Handler> handlerChain = new ArrayList<Handler>();
		// Enabling XML LOG
		handlerChain.add(new LogHandler());
		binding.setHandlerChain(handlerChain);
        
    }

    
    @Override
    public void run() {
        
        DTOSMSMessage smsPorEnviar = null;
        
        while (true) {
            
            try {
                smsPorEnviar = this.colaMensajes.poll(5, TimeUnit.SECONDS);
                //log.debug("valor de smsPorEnviar["+smsPorEnviar+"]");
                if(smsPorEnviar==null){
                    // Chequear variable de control
                    continue;
                }
                
                // ENvia SMS
                // Usar proxy
                SendSingleMessageElement ele = new SendSingleMessageElement();
        
                Message message = new Message();
                message.setArea(smsPorEnviar.getArea());
                message.setMessage(smsPorEnviar.getMensaje());
                message.setPhone(smsPorEnviar.getTelefono());
        
                ele.setObjMessage(message);
        
                SendSingleMessageResponseElement response = portEnvioSMS.sendSingleMessage(ele);
        
                // LOG
                BRKLogger.msgDebug(null, "SMSSender", "run", "Envio de SMS a["+smsPorEnviar.getTelefono()+"] RC["+response.getResult()+"]");
                
            } catch (InterruptedException ex) {
            	BRKLogger.msgError(null, "SMSSender", "run", "Error en envio de SMS", ex);
            }
            
        }
        
    }
    
}
