package com.novatronic.sixwsg.nextel.sixasincrono.server.thread;

import com.novatronic.formatter.Formatter;
import com.novatronic.formatter.FormatterFactory;
import com.novatronic.formatter.exception.FormatterException;
import com.novatronic.formatter.internal.InternalFormat;
import com.novatronic.sixwsg.nextel.sixasincrono.logging.BRKLogger;
import com.novatronic.sixwsg.nextel.sixasincrono.server.Broker;
import com.novatronic.sixwsg.nextel.sixasincrono.server.Data;
import com.novatronic.sixwsg.nextel.sixasincrono.server.FilterMessage;
import com.novatronic.sixwsg.nextel.sixasincrono.server.exception.FilterException;
import com.novatronic.sixwsg.nextel.sixasincrono.server.thread.Worker;
import com.novatronic.sixwsg.nextel.sixasincrono.util.Constants;
import com.novatronic.sixwsg.nextel.sixasincrono.util.WebServiceUtils;
import com.novatronic.proxyws.WS_BucketBalanceSearchStub;
import com.novatronic.proxyws.WS_BucketBalanceWriteStub;
import com.novatronic.proxyws.WS_CheckConectivityPrepayReadStub;

import java.text.MessageFormat;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Properties;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.TimeUnit;
import java.util.regex.Pattern;

import org.apache.axis2.AxisFault;

/**
 * @author rcastillejo
 *
 */
/**
 * Clase que obtiene el objeto DTO de la cola de comunicacion de lectura la
 * prepara en formato XML y envia al web services, el cual retorna un objeto xml
 * y es formateado en ISO y almacenado en la cola de comunicacion de escritura
 *
 * @author Ricardo Castillejo Luna - NOVATRONIC SAC
 * @version 01.00.00
 * @since Created 23-11-2012 <br> <table border=1> <tr> <td
 * align='center'>Version</td> <td align='center'>Fecha</td> <td
 * align='center'>Modificado por</td><td align='center'>Metodo Modificado</td>
 * <td align='center'>Explicacion del cambio</td> </tr>
 * <tr><td>01.00.00</td><td>05-12-2012</td><td>Ricardo Castillejo Luna
 * (RCL)</td><td>todos</td><td>Refactorizacion de Código</td></tr> </table>
 */
public class Worker implements Runnable {

    /**
     * Variable indicadora para continuar la ejecucion del Hilo de la instancia
     * de broker
     */
    private boolean continuaBroker = true;
    /**
     * Variable que establece el identificador del worker
     */
    private int workerId;
    /**
     * Variable para establecer el tamaño de la trama ISO
     */
    private short maxMsgLen;
    /**
     * Clase de estados
     */
    private Data dataThread;
    private int timeoutMiliSearchBucketBalance;
    private int timeoutMiliWriteBucketBalance;
    private int timeoutMiliChckConectivityPrepayRead;
    /**
     * Cola de comunicacion de lectura
     */
    private BlockingQueue<AsynchronousDTO> colaSIXtoSCJ;
    /**
     * Cola de comunicacion de escritura
     */
    private BlockingQueue<AsynchronousDTO> colaSCJtoSIX;
    /**
     * Objeto de token sincrono
     */
    private Object tokenSynchro;
    /**
     * Mapa para de token sincrono
     */
    private Map<String, FilterMessage> filtersMap;
    private Map<String, Pattern> patronesSeleccionFiltro;
    private Map<String, String> mapeoInterfacesFiltrosMap;
    /**
     * Clase para el formateo de las tramas XMl e ISO para el requerimiento y
     * respuesta
     */
    private FormatterFactory nextelPPVFormatFactory;
    /**
     * Clase para el proxyws
     */
    private WS_BucketBalanceSearchStub proxyBucketBalanceSearch;
    private WS_BucketBalanceWriteStub proxyBucketBalanceWrite;
    private WS_CheckConectivityPrepayReadStub proxyCheckConectivityPrepayRead;
    private static final String MSG_ERROR_QUEUE_POLL = "Error al aniadir en la {0} de {1}";
    private static final String QUEUE = "Cola de comunicacion";
    private static final String QUEUE_READER = "Lectura";
    private static final String MSG_THREAD_RELEASE = "Liberamos transaccion. [{0}] transacciones en curso.";
    private static final String MSG_THREAD_CAPABILITY_ERROR = "ADVERTENCIA. Transacciones en curso [{0}] no deberia ser menor a cero.";
    /**
     * Identificador de Formatrador de Entrada
     */
    private static final String ID_FORMATEADOR_ENTRADA = "FormatoPPVREM";
    /**
     * Identificador de Formatrador de Entrada
     */
    private static final String ID_FORMATEADOR_SALIDA = "FormatoREMPPV";
    /**
     * Nombre de stored procedures para insercion a BD
     */
    private String spBDBucketBalanceSearch;
    private String spBDBucketBalanceWrite;
    private String spBDChckConectivityPrepayRead;
    
    private String outputApp;

    /**
     * Metodo constructor de la clase, para una instancia en particular
     *
     * @param writerId Numero del hilo
     * @param maxMsgLen Maximo longitud para el mensaje
     * @param timeoutSearchBucketBalance Maximo tiempo de espera para la
     * respuesta del controlador
     * @param colaSIXtoSCJ Cola de comunicacion de lectura
     * @param colaSCJtoSIX Cola de comunicacion de escritura
     * @param tokenSynchro token de sincronizacion
     * @param infoFiltros filtros (bin o token)
     * @param transFinancieraFormat formateador
     * @param urlWSBucketBalanceSearch endpoint del servicio BBVA
     * @param spBDChckConectivityPrepayRead 
     * @param spBDBucketBalanceWrite 
     * @param spBDBucketBalanceSearch 
     * @param outputApp 
     * @throws ClassNotFoundException
     * @throws IllegalAccessException
     * @throws InstantiationException
     * @throws AxisFault
     * @throws FilterException
     */
    @SuppressWarnings({"rawtypes", "unchecked"})
    public Worker(int writerId,
            short maxMsgLen, int timeoutSearchBucketBalance, int timeoutWriteBucketBalance, int timeoutChckConectivityPrepayRead, Data dataThread,
            BlockingQueue<AsynchronousDTO> colaSIXtoSCJ,
            BlockingQueue<AsynchronousDTO> colaSCJtoSIX,
            Object tokenSynchro, Map<String, Object> infoFiltros,
            FormatterFactory transFinancieraFormat, String urlWSBucketBalanceSearch, String urlWSBucketBalanceWrite, String urlWSChckConectivityPrepayRead, String spBDBucketBalanceSearch, String spBDBucketBalanceWrite, String spBDChckConectivityPrepayRead, String outputApp)
            throws ClassNotFoundException, InstantiationException,
            IllegalAccessException, AxisFault, FilterException {

        this.workerId = writerId;
        this.maxMsgLen = maxMsgLen;
        this.timeoutMiliSearchBucketBalance = timeoutSearchBucketBalance * Constants.MILIS;
        this.timeoutMiliWriteBucketBalance = timeoutWriteBucketBalance * Constants.MILIS;
        this.timeoutMiliChckConectivityPrepayRead = timeoutChckConectivityPrepayRead * Constants.MILIS;

        this.dataThread = dataThread;
        this.colaSIXtoSCJ = colaSIXtoSCJ;
        this.colaSCJtoSIX = colaSCJtoSIX;
        this.tokenSynchro = tokenSynchro;

        if (infoFiltros != null) {
            this.mapeoInterfacesFiltrosMap = (Map<String, String>) infoFiltros.get("mapeoInterfacesFiltrosMap");

            this.patronesSeleccionFiltro = new LinkedHashMap<String, Pattern>();

            this.filtersMap = new HashMap<String, FilterMessage>();

            for (String regex : mapeoInterfacesFiltrosMap.keySet()) {
                Pattern pattern = Pattern.compile(regex);
                patronesSeleccionFiltro.put(regex, pattern);
            }

            Map<String, Properties> configFiltersMap = (Map<String, Properties>) infoFiltros.get("configFiltersMap");

            for (String aliasFiltro : configFiltersMap.keySet()) {
                Properties propiedadesFiltro = configFiltersMap.get(aliasFiltro);
                Class classFilter = Class.forName(propiedadesFiltro.getProperty("class"));
                FilterMessage filtro = (FilterMessage) classFilter.newInstance();
                filtro.setAlias(aliasFiltro);
                filtro.configure(propiedadesFiltro);
                filtersMap.put(aliasFiltro, filtro);
            }

        }

        this.nextelPPVFormatFactory = transFinancieraFormat;
        this.outputApp = outputApp;
        
        if(outputApp.equals(Constants.BD)){
            this.spBDBucketBalanceSearch =spBDBucketBalanceSearch; 
            this.spBDBucketBalanceWrite = spBDBucketBalanceWrite; 
            this.spBDChckConectivityPrepayRead = spBDChckConectivityPrepayRead;            
        }else if(outputApp.equals(Constants.WS)){
            proxyBucketBalanceSearch = new WS_BucketBalanceSearchStub(urlWSBucketBalanceSearch);
            proxyBucketBalanceSearch._getServiceClient().getOptions().setTimeOutInMilliSeconds(timeoutMiliSearchBucketBalance);
    
            proxyBucketBalanceWrite = new WS_BucketBalanceWriteStub(urlWSBucketBalanceWrite);
            proxyBucketBalanceWrite._getServiceClient().getOptions().setTimeOutInMilliSeconds(timeoutMiliWriteBucketBalance);
    
            proxyCheckConectivityPrepayRead = new WS_CheckConectivityPrepayReadStub(urlWSChckConectivityPrepayRead);
            proxyCheckConectivityPrepayRead._getServiceClient().getOptions().setTimeOutInMilliSeconds(timeoutMiliChckConectivityPrepayRead);
        }
    }

    /**
     * Metodo con el contexto de ejecucion del hilo, realiza: <br> 1) Lee el
     * mensaje de la cola de comunicacion <br> 2) Arma y envia la trama del web
     * services <br> 3) Recibe y desdobla la trama del web services <br> 4)
     * Escribe el mensaje en el SIX <br>
     */
    public void run() {

        BRKLogger.msgInfo(null, Worker.class.getSimpleName(), Constants.METHOD_RUN, MessageFormat.format(Constants.MSG_RUN_START, new Object[]{workerId}));

        // ----------------------------------------------------------------------------------------------------------------------- //
        //
        // MAIN LOOP - PROCESS MESSAGES
        //
        // ----------------------------------------------------------------------------------------------------------------------- //

        byte[] byteArrMensaje;

        AsynchronousDTO asynchronousDTO = null;
        String id = null;

        LOOP_BROKER:
        while (continuaBroker && Broker.isContinuaTodoBroker()) {


            // -------------------------------------------------------------------------------------------------------------- //
            //
            // Lee el mensaje de cola de comunicacion
            //
            // -------------------------------------------------------------------------------------------------------------- //
            while (true) {
                try {
                    asynchronousDTO = colaSIXtoSCJ.poll(1000, TimeUnit.MILLISECONDS);
                    if (asynchronousDTO != null) {
                        break;
                    } else {
                        if (!continuaBroker || !Broker.isContinuaTodoBroker()) {
                            continue LOOP_BROKER;
                        }
                    }
                } catch (InterruptedException e2) {
                    if (!continuaBroker || !Broker.isContinuaTodoBroker()) {
                        continue LOOP_BROKER;
                    }
                }
            }

            // ----------------------------------------------------------------------------------------------------------------------- //
            //
            // Obtenemos Mensaje del DTO
            //
            // ----------------------------------------------------------------------------------------------------------------------- //
            id = asynchronousDTO.getId();
            byteArrMensaje = asynchronousDTO.getByteArrMessage();
            asynchronousDTO.getCheckInBroker();

            /*
             * PREPARACION de mensaje
             * Filtro de salida
             * 
             * Si no hay filtros no se hace nada con el mensajey se envia tal cual
             */

            FilterMessage filtroAAplicar = null;

            if (mapeoInterfacesFiltrosMap != null) {
                // Hay filtros
                // Identificamos la interfaz de donde viene
                String interfazSolicitante = asynchronousDTO.getRequestingInterface();
                // Evaluamos a que patron aplica
                for (String regex : patronesSeleccionFiltro.keySet()) {
                    Pattern pattern = patronesSeleccionFiltro.get(regex);
                    if (pattern.matcher(interfazSolicitante).matches()) {
                        filtroAAplicar = filtersMap.get(mapeoInterfacesFiltrosMap.get(regex));
                        BRKLogger.msgDebug(id, Worker.class.getSimpleName(), Constants.METHOD_RUN, "Aplica por expresion regular [" + regex + "] Alias de filtro encontrado [" + filtroAAplicar.getAlias() + "]");
                        try {
                            byteArrMensaje = filtroAAplicar.filterOut(byteArrMensaje);
                        } catch (FilterException e) {
                            BRKLogger.msgError(id, Worker.class.getSimpleName(), Constants.METHOD_RUN, "FilterException procesar mensaje antes de enviar", e);
                            continuaBroker = false;
                            continue LOOP_BROKER;
                        }
                        break;
                    }
                }
                if (filtroAAplicar == null) {
                    BRKLogger.msgDebug(id, Worker.class.getSimpleName(), Constants.METHOD_RUN, "No se encontro ningun filtro por aplicar a interfaz [" + interfazSolicitante + "]");
                }
            }

            // ----------------------------------------------------------------------------------------------------------------------- //
            //
            // RECEIVE RESPONSE MESSAGE (from Controlador Java)
            //
            // ----------------------------------------------------------------------------------------------------------------------- //
            short longLeidaS2J;
            byte[] bdata = new byte[maxMsgLen];

            boolean esTimeOut = false;
            String sMensaje;
            String output = null;

            /**
             * Inicio de la modificacion para el Gateway Web Services de Banca
             * Móvil
             *
             * Autor: Ricardo Castillejo Luna
             */
            try {

                asynchronousDTO.checkOutToSCJ();

                //1ero leo la trama ISO
                sMensaje = new String(byteArrMensaje);
                BRKLogger.msgDebug(id, Worker.class.getSimpleName(), Constants.METHOD_RUN, " trama ISO recibida = {" + sMensaje + "}");

                //2. Convertir la trama ISO obtenida en el paso anterior a Internal Format
                Formatter formaterEntrada = nextelPPVFormatFactory.getFormatter(ID_FORMATEADOR_ENTRADA);
                InternalFormat requerimientoIF = null;
                try {

                    requerimientoIF = formaterEntrada.createInternalFormatFromFrame(sMensaje);
                    BRKLogger.msgDebug(id, Worker.class.getSimpleName(), Constants.METHOD_RUN, " internal format de la trama ISO leida = " + requerimientoIF + "");

                } catch (FormatterException fe) {
                    BRKLogger.msgError(id, Worker.class.getSimpleName(), Constants.METHOD_RUN, "FormatterException al formatear mensaje ISO", fe);
                    throw fe;
                }

                String strTransaccion = requerimientoIF.getValue("bmp.3");
                Integer intTransaccion = Integer.valueOf(strTransaccion);

                BRKLogger.msgDebug(id, Worker.class.getSimpleName(), Constants.METHOD_RUN, " strTransaccion = " + strTransaccion + ", transaccion = " + intTransaccion);

                //3. Se envía el requerimiento y se recibe la respuesta del Autorizador, con la cual se arma la trama xml
                InternalFormat ifRes = requerimientoIF;
                ifRes.remove("MTI");

                output = WebServiceUtils.enviarReqRecibirRespuesta(strTransaccion, requerimientoIF, proxyBucketBalanceSearch, proxyBucketBalanceWrite, proxyCheckConectivityPrepayRead, nextelPPVFormatFactory, outputApp,spBDBucketBalanceSearch,spBDBucketBalanceWrite,spBDChckConectivityPrepayRead);

                BRKLogger.msgDebug(id, Worker.class.getSimpleName(), Constants.METHOD_RUN, " se armo la data aplicativa xml=" + output);

                asynchronousDTO.checkInFromSCJ();

                BRKLogger.msgPerf(id, 1, Worker.class.getSimpleName(), "", asynchronousDTO.getCheckOutToSCJ(), asynchronousDTO.getCheckInFromSCJ());

                if (output == null || output.isEmpty()) {
                    BRKLogger.msgError(id, Worker.class.getSimpleName(), Constants.METHOD_RUN, "Longitud de la respuesta menor a cero. Descartaremos el mensaje simulando un timeout.", null);

                    bdata = new byte[0];

                    /*
                     * Identifico el escenario de TIMEOUT para no responder nada hacia el SIX
                     */

                    esTimeOut = true;
                } else {
                    //  Preparando el mensaje para escribir en el SIX
                    longLeidaS2J = (short) output.length();

                    BRKLogger.msgDebug(id, Worker.class.getSimpleName(), Constants.METHOD_RUN, "Respuesta: [" + longLeidaS2J + "] bytes recibidos del controlador.");

                    bdata = output.getBytes();
                }
            } catch (Exception e) {
                if (e.getCause() instanceof FormatterException) {
                    esTimeOut = true;
                } else {
                    BRKLogger.msgError(id, Worker.class.getSimpleName(), Constants.METHOD_RUN, "ConnectTimeoutException al enviar o recibir mensaje de respuesta del controlador: [" + e.getMessage() + "]", e);
                    esTimeOut = true;
                }
            } catch (Throwable e) {
                BRKLogger.msgError(id, Worker.class.getSimpleName(), Constants.METHOD_RUN, "Throwable al enviar o recibir del web services: [" + e.getMessage() + "]", e);
                continuaBroker = false;
                /**
                 * Consultar, si hay un error, se decrece la cantidad de
                 * atencion o se mantiene, de ser mantenido y persistir esta
                 * excepcion lo mas probable es que llegue en un momento e que
                 * dejara de atender
                 */
                continue;
            }

            /**
             * Fin de la modificacion para el Gateway Web Services de Banca
             * Móvil
             *
             * Autor: Ricardo Castillejo Luna
             */
            /*
             * SI ES TIMEOUT
             * No mandamos Nada de regreso al SIX
             * Tampoco confirmamos 
             */
            if (!esTimeOut) {

                /*
                 * Tratamiento de mensaje
                 * Filtro entrada
                 * 
                 * Si no hay filtros no se hace nada con el mensaje y se envia tal cual
                 */
                if (filtroAAplicar != null) {
                    try {
                        bdata = filtroAAplicar.filterIn(bdata);
                    } catch (FilterException e) {
                        BRKLogger.msgError(id, Worker.class.getSimpleName(), Constants.METHOD_RUN, "FilterException procesar mensaje despues de recibir", e);
                        continuaBroker = false;
                        continue LOOP_BROKER;
                    }
                }



                // ----------------------------------------------------------------------------------------------------------------------- //
                //
                // Actualizamoes el DTO
                //
                // ----------------------------------------------------------------------------------------------------------------------- //
                byteArrMensaje = new byte[bdata.length];
                System.arraycopy(bdata, 0, byteArrMensaje, 0, bdata.length);
                asynchronousDTO.setByteArrMessage(byteArrMensaje);
                asynchronousDTO.setWorkerId(this.workerId);

                // ----------------------------------------------------------------------------------------------------------------------- //
                //
                // CALL SIX_SNDRSP FUNCTION
                //
                // ----------------------------------------------------------------------------------------------------------------------- //

                try {
                    colaSCJtoSIX.offer(asynchronousDTO);
                } catch (Exception e) {
                    BRKLogger.msgError(id, Worker.class.getSimpleName(), Constants.METHOD_RUN, MessageFormat.format(MSG_ERROR_QUEUE_POLL, new Object[]{QUEUE, QUEUE_READER}), e);
                }


            }


            /*
             * Reducimos los contadores de transacciones en curso
             */
            synchronized (tokenSynchro) {
                int txnEnCurso = Broker.getCurrentTransactions().decrementAndGet();
                if (txnEnCurso < 0) {
                    /*
                     * No deberia bajar menos de CERO, en todo caso, lo dejamos abierto para ver si pasa.
                     */
                    BRKLogger.msgError(id, Worker.class.getSimpleName(), Constants.METHOD_RUN, MessageFormat.format(MSG_THREAD_CAPABILITY_ERROR, new Object[]{txnEnCurso}), null);
                } else {
                    tokenSynchro.notify();
                    BRKLogger.msgDebug(id, Worker.class.getSimpleName(), Constants.METHOD_RUN, MessageFormat.format(MSG_THREAD_RELEASE, new Object[]{txnEnCurso}));
                }
            }

            asynchronousDTO.checkOutBroker();

            BRKLogger.msgPerf(id, 0, Worker.class.getSimpleName(), "", asynchronousDTO.getCheckInBroker(), asynchronousDTO.getCheckOutBroker());

            this.dataThread.setStatus(Constants.STATUS_READING);
        }

        this.dataThread.setStatus(Constants.STATUS_DOWN);

        BRKLogger.msgInfo(null, Worker.class.getSimpleName(), Constants.METHOD_RUN, MessageFormat.format(Constants.MSG_RUN_END, new Object[]{workerId}));

    }

    /**
     * Retorna la clase de estados
     *
     * @return Data
     */
    public Data getData() {
        return dataThread;
    }
}
