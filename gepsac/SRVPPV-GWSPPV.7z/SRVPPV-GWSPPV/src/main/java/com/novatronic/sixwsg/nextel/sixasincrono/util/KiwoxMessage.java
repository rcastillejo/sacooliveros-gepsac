/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.novatronic.sixwsg.nextel.sixasincrono.util;

import com.novatronic.sixwsg.entel.model.EventResponse;
import javax.ws.rs.core.MultivaluedMap;

/**
 *
 * @author rcastillejo
 */
public class KiwoxMessage {

    private String id;
    private MultivaluedMap request;
    private EventResponse response;
    private int retry;
    private boolean finish;

    public KiwoxMessage() {
        this.retry = 0;
    }

    public KiwoxMessage(String id, MultivaluedMap request) {
        this();
        this.id = id;
        this.request = request;
    }

    public String getId() {
        return id;
    }

    public MultivaluedMap getRequest() {
        return request;
    }

    public EventResponse getResponse() {
        return response;
    }

    public void setResponse(EventResponse response) {
        this.response = response;
    }

    public void retry() {
        retry++;
    }

    public int getRetry() {
        return retry;
    }
    
    public boolean hasResponse(){
        return response != null;
    }
    
    public boolean isRetryExcess(){
        return response == null && retry > 0;
    }
        
    public void finish(){
        finish = Boolean.TRUE;
    }

    public boolean isFinish() {
        return finish;
    }

    @Override
    public String toString() {
        return "KiwoxMessage{" + "id=" + id + ", request=" + request + ", response=" + response + ", retry=" + retry + ", finish=" + finish + '}';
    }
    
}
