/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.novatronic.sixwsg.nextel.sixasincrono.utils.factories;

import com.novatronic.sixwsg.nextel.sixbws.wsnextel.exception.TrxnException;
import com.novatronic.sixwsg.nextel.transactions.bucketBalanceWriteFactory.TransactionBucketBalanceWriteFactory;

import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 *
 * @author ebajalqui
 */
public class CodigoRespuestaFactory {

    private static final Logger log = LoggerFactory.getLogger(TransactionBucketBalanceWriteFactory.class);
    private static Map<String, String> codigos_Error;
    private static final String CONF_CODIGOS_ERROR = "Codigos_Error";
    private static final String COD_ERROR = "codigoError.";

    public CodigoRespuestaFactory() {
    }

    /**
     * Metodo que carga la configuracion para la fabrica de transacciones
     *
     * @param config - Properties que contiene la estructura de las
     * transacciones a configurar.
     */
    public static void init(Properties config) {
        String codigosError;
        String[] keys;

        codigosError = config.getProperty(CONF_CODIGOS_ERROR);

        validateConf(config);

        codigos_Error = new HashMap<String, String>();

        log.trace("Configurando transacciones [{}]", codigosError);
        keys = codigosError.split(",");

        for (String key : keys) {

            addTransaction(key, config);
            log.debug("Transaccion configurada [ " + key + " ]");
        }

        log.debug("Transacciones configuradas [llaves={}, transacciones={}]", codigosError, codigos_Error);

    }

    private static void validateConf(Properties config) {
        if (!config.containsKey(CONF_CODIGOS_ERROR)) {
            throw new TrxnException("Debe especificar los codigos de transacciones en la propiedad [" + CONF_CODIGOS_ERROR + "]");
        }
    }

    private static void addTransaction(String key, Properties config) {
        String binAdqValue;
        try {

            validateConfTransaction(key, config);

            binAdqValue = config.getProperty(COD_ERROR + key);

            log.trace("[{}] Nombre transaccion obtenida [{}={}]", new Object[]{key, COD_ERROR + key, binAdqValue});

            codigos_Error.put(key, binAdqValue);
            log.trace("[{}] Transaccion agregada [{}]", key, binAdqValue);
        } catch (Exception e) {
            throw new TrxnException("No se pudo crear la transaccion [" + key + "]", e);
        }
    }

    private static void validateConfTransaction(String key, Properties config) {
        if (!config.containsKey(COD_ERROR + key)) {
            throw new TrxnException("Debe especificar la configuracion para la transaccion [" + COD_ERROR + key + "]");
        }
    }

    /**
     * Retorna transaccion de acuerdo a la llave especificada.
     *
     * @param key - Identificador de la transaccion
     * @return {@link Transaction}
     */
    public static String getMensajeError(String key) {
        String binAdqValue;

        try {
            binAdqValue = codigos_Error.get(key);
            log.trace("[{}] Clase transaccion instanciada [{}]", key, binAdqValue);
            return binAdqValue;
        } catch (Exception e) {
            throw new TrxnException("No se pudo instanciar la transaccion [" + key + "]", e);
        }
    }

    public static Map<String, String> getCodigosError() {
        return codigos_Error;
    }

    public static void setTransactions(Map<String, String> listaCodigosError) {
        CodigoRespuestaFactory.codigos_Error = listaCodigosError;
    }
}
