/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.novatronic.sixwsg.nextel.transactions.bucketBalanceWriteFactory;

import java.rmi.RemoteException;

import com.novatronic.formatter.FormatterFactory;
import com.novatronic.formatter.internal.InternalFormat;
import com.novatronic.proxyws.WS_BucketBalanceWriteStub;
import com.novatronic.proxyws.WS_BucketBalanceWriteStub.WriteBucketBalanceElement;
import com.novatronic.proxyws.WS_BucketBalanceWriteStub.WriteBucketBalanceResponseElement;
import com.novatronic.sixwsg.nextel.sixasincrono.logging.BRKLogger;
import com.novatronic.sixwsg.nextel.transactions.bucketBalanceWriteFactory.TransactionBucketBalanceWrite;

/**
 *
 * @author ebajalqui
 */
public abstract class TransactionBucketBalanceWriteImp implements TransactionBucketBalanceWrite {

    private static final String MSG_TIMEOUT = "TIME OUT - ERROR TELCO";
    private static final String ID_FORMATEADOR_SALIDA = "FormatoREMPPV";
    private static final String COD_TRANSACCION_APROBADA = "0";
    private static final String COD_ERROR_CONTENT = "1414";
    private static final String COD_ERROR_OUTPUT = "1415";
    private static final String COD_ERROR_RECEIVE_MESSAGE = "1413";
    private static final String COD_ERROR_UNEXPECTED = "1416";

    public WriteBucketBalanceResponseElement process(WriteBucketBalanceElement request, WS_BucketBalanceWriteStub proxy) throws Exception {
        try {
            return handle(request, proxy);
        } catch (Exception ex) {

            BRKLogger.msgError("", TransactionBucketBalanceWriteImp.class.getSimpleName(), " process ", "Error al Enviar Requerimiento", ex);
            throw ex;
        }
    }

    public WriteBucketBalanceElement generarRequest(InternalFormat requestIF) throws Exception {

        try {
            return generarBucketBalanceElement(requestIF);
        } catch (Exception e) {
            BRKLogger.msgError("", TransactionBucketBalanceWriteImp.class.getSimpleName(), " generarRequest ", "Error al generar Requerimiento", e);
            throw e;
        }

    }

    public String generarResponse(WriteBucketBalanceResponseElement response, InternalFormat requestIF, FormatterFactory formatter) throws Exception {

        try {
            return generarTramaRespuesta(response, requestIF, formatter);
        } catch (Exception e) {
            BRKLogger.msgError("", TransactionBucketBalanceWriteImp.class.getSimpleName(), " generarResponse ", "Error al generar Respuesta", e);
            throw e;
        }
    }

    public String sendReceiveData(String prCodeTransaccion, InternalFormat requerimientoIF, WS_BucketBalanceWriteStub proxyBucketBalanceWrite, FormatterFactory nextelFormatterFactory) throws Exception {

        String respuesta = "";
        WriteBucketBalanceElement request = null;

        request = generarRequest(requerimientoIF);
        WriteBucketBalanceResponseElement response = process(request, proxyBucketBalanceWrite);

        if (response != null || response.getResult() != null) {

            respuesta = generarResponse(response, requerimientoIF, nextelFormatterFactory);

        } else {

            respuesta = "";
            BRKLogger.msgDebug("", TransactionBucketBalanceWriteImp.class.getSimpleName(), " sendReceiveData", "Se obtuvo una respuesta Nula");

        }

        return respuesta;

    }

    protected abstract WriteBucketBalanceResponseElement handle(WriteBucketBalanceElement request, WS_BucketBalanceWriteStub proxy) throws RemoteException;

    protected abstract WriteBucketBalanceElement generarBucketBalanceElement(InternalFormat requestIF);

    protected abstract String generarTramaRespuesta(WriteBucketBalanceResponseElement response, InternalFormat requestIF, FormatterFactory formatter);
}
