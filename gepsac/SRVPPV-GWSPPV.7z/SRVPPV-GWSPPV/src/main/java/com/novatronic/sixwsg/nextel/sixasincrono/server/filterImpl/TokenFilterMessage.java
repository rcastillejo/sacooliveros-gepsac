package com.novatronic.sixwsg.nextel.sixasincrono.server.filterImpl;

import com.novatronic.sixwsg.nextel.sixasincrono.server.FilterMessage;
import com.novatronic.sixwsg.nextel.sixasincrono.server.exception.FilterException;
import java.util.Properties;

/**
 * Clase que configura el filtro de TOKEN y realiza el filtrado de la trama
 *
 * @author Ricardo Castillejo Luna - NOVATRONIC SAC
 * @version 01.00.00
 * @since Created 23-11-2012 <br> <table border=1> <tr> <td
 * align='center'>Version</td> <td align='center'>Fecha</td> <td
 * align='center'>Modificado por</td><td align='center'>Metodo Modificado</td>
 * <td align='center'>Explicacion del cambio</td> </tr>
 * <tr><td>01.00.00</td><td>05-12-2012</td><td>Ricardo Castillejo Luna
 * (RCL)</td><td>todos</td><td>Refactorizacion de Código</td></tr> </table>
 */
public class TokenFilterMessage implements FilterMessage {

    private String alias;
    private int tokenLength;
    private byte[] token;

    /**
     * {@inheritDoc }
     */
    public void configure(Properties configuration) throws FilterException {
        try {
            this.tokenLength = Integer.parseInt(configuration.getProperty("tokenLength"));
        } catch (Exception e) {
            //No se ha hecho pruebas de cobertura para los casos alternos
            throw new FilterException("Longitud de token mal especificada", e);
        }
        this.token = new byte[tokenLength];
    }

    /**
     * {@inheritDoc }
     */
    public byte[] filterOut(byte[] message) throws FilterException {
        try {
            System.arraycopy(message, 0, token, 0, tokenLength);
            byte[] retorno = new byte[message.length - tokenLength];
            System.arraycopy(message, tokenLength, retorno, 0, retorno.length);
            return retorno;
        } catch (Exception e) {
            //No se ha hecho pruebas de cobertura para los casos alternos
            throw new FilterException("No se pudo aplicar filtro de salida", e);
        }
    }

    /**
     * {@inheritDoc }
     */
    public byte[] filterIn(byte[] message) throws FilterException {
        try {
            byte[] retorno = new byte[message.length + tokenLength];
            System.arraycopy(token, 0, retorno, 0, tokenLength);
            System.arraycopy(message, 0, retorno, tokenLength, message.length);
            return retorno;
        } catch (Exception e) {
            //No se ha hecho pruebas de cobertura para los casos alternos
            throw new FilterException("No se pudo aplicar filtro de regreso", e);
        }
    }

    /**
     * {@inheritDoc }
     */
    public String getAlias() {
        if (alias != null && alias.trim().length() > 0) {
            return alias;
        } else {
            return BinFilterMessage.class.getName();
        }
    }

    /**
     * {@inheritDoc }
     */
    public void setAlias(String alias) {
        this.alias = alias;
    }
}
