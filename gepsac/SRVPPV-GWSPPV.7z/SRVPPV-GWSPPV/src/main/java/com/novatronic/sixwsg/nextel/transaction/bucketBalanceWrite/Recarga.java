/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.novatronic.sixwsg.nextel.transaction.bucketBalanceWrite;

import com.novatronic.formatter.Formatter;
import com.novatronic.formatter.FormatterFactory;
import com.novatronic.formatter.exception.FormatterException;
import com.novatronic.formatter.internal.InternalFormat;
import com.novatronic.proxyws.WS_BucketBalanceWriteStub;
import com.novatronic.proxyws.WS_BucketBalanceWriteStub.WriteBucketBalanceElement;
import com.novatronic.proxyws.WS_BucketBalanceWriteStub.WriteBucketBalanceResponseElement;
import com.novatronic.sixwsg.nextel.sixasincrono.logging.BRKLogger;
import com.novatronic.sixwsg.nextel.sixasincrono.util.Constants;
import com.novatronic.sixwsg.nextel.sixasincrono.util.FormaterUtils;
import com.novatronic.sixwsg.nextel.sixasincrono.util.WebServiceUtils;
import com.novatronic.sixwsg.nextel.sixasincrono.utils.factories.BinAdquirienteFactory;
import com.novatronic.sixwsg.nextel.transaction.bucketBalanceSearch.Consulta;
import com.novatronic.sixwsg.nextel.transaction.bucketBalanceWrite.Recarga;
import com.novatronic.sixwsg.nextel.transactions.bucketBalanceWriteFactory.TransactionBucketBalanceWriteImp;

import java.math.BigDecimal;
import java.rmi.RemoteException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

/**
 *
 * @author ebajalqui
 */
public class Recarga extends TransactionBucketBalanceWriteImp {

    private final static String ID_APP = "244";
    private static final String PREFIJO_OPERACION_DEFAULT = "SIX   ";
    private static final String PREFIJO_OPERACION_CAREM = "PREPAY-ONLINE-";
    private static final String SUFIJO_OPERACION_NUM_ORIG = "REC";
    private static final String USERNAME = "SIX PPV";
    private static final String BUCKET_ALIAS = "RECHARGE";
    private static final String DOLARES = "DOL";
    private static final String SOLES = "SOL";
    private static final String VALOR_MONEDA_DEFAULT = "   ";
    private final static String TIPO_MENSAJE_RECARGA = "0210";
    /**
     * Identificador de Formatrador de Entrada
     */
    private static final String ID_FORMATEADOR_SALIDA = "FormatoREMPPV";

    @Override
    protected WriteBucketBalanceResponseElement handle(WriteBucketBalanceElement request, WS_BucketBalanceWriteStub proxy) throws RemoteException {
        return proxy.writeBucketBalance(request);
    }

    @Override
    protected WriteBucketBalanceElement generarBucketBalanceElement(InternalFormat requestIF) {

        WriteBucketBalanceElement reqElemento = new WriteBucketBalanceElement();

        String AnhoActual = String.valueOf(Calendar.getInstance().get(Calendar.YEAR));

        WS_BucketBalanceWriteStub.BucketBalanceWriteIn reqElementoIn = new WS_BucketBalanceWriteStub.BucketBalanceWriteIn();

        reqElementoIn.setIdApp(ID_APP);

        String codProdValue = requestIF.getValue("datos_ppv.tipid");
        String operation_carem_value = PREFIJO_OPERACION_CAREM + codProdValue;
        reqElementoIn.setOPERATION_CAREM(operation_carem_value);

        String montoValueStr = requestIF.getValue("monto");
        BRKLogger.msgDebug(null, WebServiceUtils.class.getSimpleName(), "error123456 ", "monto0000000: "+montoValueStr);
        //Double monto = Double.valueOf(montoValueStr);
        //Double monto = FormaterUtils.formatearDoubleReq(montoValueStr);
        BigDecimal montoTranformado =new BigDecimal(montoValueStr.toString());
        //Double monto = 	Double.parseDouble(montoTranformado.toString());	
        Double monto = 	montoTranformado.doubleValue();
        
        BRKLogger.msgDebug(null, WebServiceUtils.class.getSimpleName(), "error123456 ", "monto0: "+monto);
        
        reqElementoIn.setRECHARGE_AMOUNT(monto);

        reqElementoIn.setBUCKET_ALIAS(BUCKET_ALIAS);
        reqElementoIn.setUSERNAME(USERNAME);

        String monedaValue = requestIF.getValue("moneda");

        if (monedaValue.equals("604")) {

            reqElementoIn.setBUCKET_UNIT(SOLES);

        } else {
            if (monedaValue.equals("840")) {

                reqElementoIn.setBUCKET_UNIT(DOLARES);

            } else {

                reqElementoIn.setBUCKET_UNIT(VALOR_MONEDA_DEFAULT);

            }
        }

        reqElementoIn.setBUCKET_OPERATION(SUFIJO_OPERACION_NUM_ORIG);
        reqElementoIn.setID_PARAM(codProdValue);

        String fec_txnValue = requestIF.getValue("fec_txn");
        String hor_txnValue = requestIF.getValue("hor_txn");
		String operationDateTimeValue = fec_txnValue.substring(2, 4) + "/"
				+ fec_txnValue.substring(0, 2) + "/" + AnhoActual + " "
				+ hor_txnValue.substring(0, 2) + ":"
				+ hor_txnValue.substring(2, 4) + ":"
				+ hor_txnValue.substring(4, 6);

        reqElementoIn.setOPERATION_DATE(operationDateTimeValue);

        String comercioValue = requestIF.getValue("comercio");
        reqElementoIn.setENTITY_CODE(comercioValue);

        String prefijoOperacion = "";
        String binAcqValue = requestIF.getValue("bin_acq");
        if (BinAdquirienteFactory.getListaBinesAdquiriente().containsKey(binAcqValue)) {
            prefijoOperacion = BinAdquirienteFactory.getValue(binAcqValue);
        } else {
            prefijoOperacion = PREFIJO_OPERACION_DEFAULT;
        }

        String numDocumentoValue = requestIF.getValue("datos_ppv.numppv");
        String numPPVOperacion = FormaterUtils.formatearNumero(numDocumentoValue, 12);

        reqElementoIn.setOPERATION_NUM(prefijoOperacion + numPPVOperacion + SUFIJO_OPERACION_NUM_ORIG);

        String tipIdValue = requestIF.getValue("datos_ppv.id");
        reqElementoIn.setDES_PARAM(tipIdValue);

        reqElemento.setBucketBalanceWriteIn(reqElementoIn);

        return reqElemento;
    }

    @Override
    protected String generarTramaRespuesta(WriteBucketBalanceResponseElement response, InternalFormat requestIF, FormatterFactory formatterFactory) {

        String tramaRespuesta = "";

        InternalFormat responseIF = new InternalFormat("FormatoREMPPV");

        responseIF.add("tip_msg", TIPO_MENSAJE_RECARGA);

        String panReqValue = requestIF.getValue("pan");
        responseIF.add("pan", panReqValue);

        String prCodeReqValue = requestIF.getValue("prcode");
        responseIF.add("prcode", prCodeReqValue);

        if (response.getResult().getBucketBalancesOut() != null) {

            double montoValue = response.getResult().getBucketBalancesOut()[0].getBUCKET_AMOUNT();

            if (!(Double.compare(montoValue, Double.NaN) == 0)) {

                String montoValueStr = String.valueOf(montoValue);
                responseIF.add("monto", montoValueStr);

            } else {

                String montoValueStr = FormaterUtils.formatearNumero("0", 12);
                responseIF.add("monto", montoValueStr);

            }

        } else {

            String montoValueStr = FormaterUtils.formatearNumero("0", 12);
            responseIF.add("monto", montoValueStr);

        }

        String fecTxnReqValue = requestIF.getValue("fec_txn");
        responseIF.add("fec_txn", fecTxnReqValue);

        String horTxnReqValue = requestIF.getValue("hor_txn");
        responseIF.add("hor_txn", horTxnReqValue);

        String traceReqValue = requestIF.getValue("trace");
        responseIF.add("trace", traceReqValue);

        String fecCapReqValue = requestIF.getValue("fec_cap");
        responseIF.add("fec_cap", fecCapReqValue);

        String binAcqReqValue = requestIF.getValue("bin_acq");
        responseIF.add("bin_acq", binAcqReqValue);

        String numRefReqValue = requestIF.getValue("num_ref");
        responseIF.add("num_ref", numRefReqValue);

        String codAutReqValue = requestIF.getValue("cod_aut");
        responseIF.add("cod_aut", codAutReqValue);

        String codRspValue = response.getResult().getCodError();

        if (FormaterUtils.formatearNumero(codRspValue, 1).equals("0")) {

            responseIF.add("cod_rsp", "00");
        } else {

            responseIF.add("cod_rsp", "99");
        }

        String termIdReqValue = requestIF.getValue("term_id");
        responseIF.add("term_id", termIdReqValue);

        String comercioReqValue = requestIF.getValue("comercio");
        responseIF.add("comercio", comercioReqValue);

        /* Datos PPV*/

        String formatoDatosPPVValue = FormaterUtils.formatearCadena("", 2);
        responseIF.add("datos_ppv1.formato", formatoDatosPPVValue);

        String codProcDatosPPVValue = FormaterUtils.formatearCadena("", 11);
        responseIF.add("datos_ppv1.cod_proc", codProcDatosPPVValue);

        String codTelcDatosPPVValue = FormaterUtils.formatearCadena("", 11);
        responseIF.add("datos_ppv1.cod_telc", codTelcDatosPPVValue);

        String codProdDatosPPVValue = FormaterUtils.formatearCadena("", 8);
        responseIF.add("datos_ppv1.cod_prod", codProdDatosPPVValue);

        String tipIdDatosPPVValue = FormaterUtils.formatearCadena("", 2);
        responseIF.add("datos_ppv1.tipid", tipIdDatosPPVValue);

        String idDatosPPVValue = FormaterUtils.formatearCadena("", 20);
        responseIF.add("datos_ppv1.id", idDatosPPVValue);

        String oriRspDatosPPVValue = FormaterUtils.formatearCadena("", 1);
        responseIF.add("datos_ppv1.orirsp", oriRspDatosPPVValue);

        String rspExtDatosPPVValue = FormaterUtils.formatearCadena("", 2);
        responseIF.add("datos_ppv1.rspext", rspExtDatosPPVValue);

        String desExtDatosPPVValue = FormaterUtils.formatearCadena("", 16);
        responseIF.add("datos_ppv1.desext", desExtDatosPPVValue);

        String tipTxnDatosPPVValue = FormaterUtils.formatearCadena("", 2);
        responseIF.add("datos_ppv1.tiptxn", tipTxnDatosPPVValue);

        String medPagDatosPPVValue = FormaterUtils.formatearCadena("", 2);
        responseIF.add("datos_ppv1.medpag", medPagDatosPPVValue);

        String tipCtaDatosPPVValue = FormaterUtils.formatearCadena("", 2);
        responseIF.add("datos_ppv1.tipcta", tipCtaDatosPPVValue);

        String fillerDatosPPVValue = FormaterUtils.formatearCadena("", 176);
        responseIF.add("datos_ppv1.filler", fillerDatosPPVValue);

        /**/

        String monedaReqValue = requestIF.getValue("moneda");
        responseIF.add("moneda", monedaReqValue);

        String bin1ReqValue = requestIF.getValue("bin1");
        responseIF.add("bin1", bin1ReqValue);

        String acct1ReqValue = requestIF.getValue("acct_1");
        responseIF.add("acct_1", acct1ReqValue);

        String bin2ReqValue = requestIF.getValue("bin2");
        responseIF.add("bin2", bin2ReqValue);

        String acct2ReqValue = requestIF.getValue("acct_2");
        responseIF.add("acct_2", acct2ReqValue);

        String codautOReqValue = requestIF.getValue("prcode");
        responseIF.add("codaut_o", codautOReqValue);

        String datosAdmValue = FormaterUtils.formatearCadena("", 40);
        responseIF.add("datos_adm", datosAdmValue);

        /* Completando los datos del datos_ppv_2*/

        String formatoReqValue = requestIF.getValue("datos_ppv.formato");
        responseIF.add("datos_ppv2.formato", formatoReqValue);

        String codProcReqValue = requestIF.getValue("datos_ppv.codproc");
        responseIF.add("datos_ppv2.cod_proc", codProcReqValue);

        String codTelcReqValue = requestIF.getValue("datos_ppv.codtelc");
        responseIF.add("datos_ppv2.cod_telc", codTelcReqValue);

        String codProdReqValue = requestIF.getValue("datos_ppv.codprod");
        responseIF.add("datos_ppv2.cod_prod", codProdReqValue);

        String tipIdReqValue = requestIF.getValue("datos_ppv.tipid");
        responseIF.add("datos_ppv2.tipid", tipIdReqValue);

        String idReqValue = requestIF.getValue("datos_ppv.id");;
        responseIF.add("datos_ppv2.id", idReqValue);

        String pinIndReqValue = FormaterUtils.formatearNumero("", 1);
        responseIF.add("datos_ppv2.pin_ind", pinIndReqValue);

        String pinBinReqValue = FormaterUtils.formatearCadena("", 11);
        responseIF.add("datos_ppv2.pin_bin", pinBinReqValue);

        String pinMetodoReqValue = FormaterUtils.formatearNumero("", 2);
        responseIF.add("datos_ppv2.pin_metodo", pinMetodoReqValue);

        String pinLongitudReqValue = FormaterUtils.formatearNumero("", 2);
        responseIF.add("datos_ppv2.pin_longitud", pinLongitudReqValue);

        String pinCifradoReqValue = FormaterUtils.formatearCadena("", 32);
        responseIF.add("datos_ppv2.pin_cifrado", pinCifradoReqValue);

        responseIF.add("datos_ppv2.saldo_moneda", monedaReqValue);

        if (response.getResult().getBucketBalancesOut() != null) {

            double bucketBalance = response.getResult().getBucketBalancesOut()[0].getBUCKET_BALANCE();

            if (!(Double.compare(bucketBalance, Double.NaN) == 0)) {

                String saldoImporteValue = String.valueOf(bucketBalance);
                responseIF.add("datos_ppv2.saldo_importe", saldoImporteValue);

            } else {

                String saldoImporteValue = FormaterUtils.formatearNumero("0", 12);
                responseIF.add("datos_ppv2.saldo_importe", saldoImporteValue);

            }

        } else {

            String saldoImporteValue = FormaterUtils.formatearNumero("0", 12);
            responseIF.add("datos_ppv2.saldo_importe", saldoImporteValue);

        }



        String saldoMinutosValue = FormaterUtils.formatearNumero("", 6);
        responseIF.add("datos_ppv2.saldo_minutos", saldoMinutosValue);


        SimpleDateFormat formateadorFechaIn = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
        SimpleDateFormat formateadorFechaOut = new SimpleDateFormat("yyyyMMdd");

        if (response.getResult().getBucketBalancesOut() != null) {

            if (response.getResult().getBucketBalancesOut()[0].getBUCKET_EXP_DATE() != null) {

                Date fechaIn = null;
                String fechaFormateada = "";
                String fechaInStr = response.getResult().getBucketBalancesOut()[0].getBUCKET_EXP_DATE();

                try {

                    fechaIn = formateadorFechaIn.parse(fechaInStr);

                } catch (Exception e) {
                    BRKLogger.msgError(null, Consulta.class.getSimpleName(), Constants.METHOD_RUN, "Error en el Parseo de la fecha de Entrada", e);
                }

                try {

                    fechaFormateada = formateadorFechaOut.format(fechaIn);

                } catch (Exception ex) {
                    BRKLogger.msgError(null, Consulta.class.getSimpleName(), Constants.METHOD_RUN, "Error en el Formateo de la fecha de Salida", ex);
                }

                responseIF.add("datos_ppv2.rec_caducidad", FormaterUtils.formatearCadena(fechaFormateada, 8));

            } else {

                responseIF.add("datos_ppv2.rec_caducidad", FormaterUtils.formatearCadena("", 8));
            }


        } else {

            responseIF.add("datos_ppv2.rec_caducidad", FormaterUtils.formatearCadena("", 8));

        }

        String recVigenciaValue = FormaterUtils.formatearNumero("", 4);
        responseIF.add("datos_ppv2.rec_vigencia", recVigenciaValue);

        if (response.getResult().getBucketBalancesOut() != null) {

            if (response.getResult().getBucketBalancesOut()[0].getMSG_REC() != null) {

                String mkt1Value = response.getResult().getBucketBalancesOut()[0].getMSG_REC();
                responseIF.add("datos_ppv2.mkt1", FormaterUtils.formatearCadena(mkt1Value, 40));

            } else {

                responseIF.add("datos_ppv2.mkt1", FormaterUtils.formatearCadena("", 40));
            }

        } else {

            responseIF.add("datos_ppv2.mkt1", FormaterUtils.formatearCadena("", 40));

        }

        if (response.getResult().getBucketBalancesOut() != null) {

            if (response.getResult().getBucketBalancesOut()[0].getMSG_REC() != null) {

                String mkt1Value = response.getResult().getBucketBalancesOut()[0].getMSG_REC();
                responseIF.add("datos_ppv2.mkt1", FormaterUtils.formatearCadena(mkt1Value, 40));

            } else {

                responseIF.add("datos_ppv2.mkt1", FormaterUtils.formatearCadena("", 40));
            }

        } else {

            responseIF.add("datos_ppv2.mkt1", FormaterUtils.formatearCadena("", 40));

        }

        if (response.getResult().getBucketBalancesOut() != null) {

            if (response.getResult().getBucketBalancesOut()[0].getMSG_MKT() != null) {

                String mkt2Value = response.getResult().getBucketBalancesOut()[0].getMSG_MKT();
                responseIF.add("datos_ppv2.mkt2", FormaterUtils.formatearCadena(mkt2Value, 40));
            } else {
                responseIF.add("datos_ppv2.mkt2", FormaterUtils.formatearCadena("", 40));
            }

        } else {

            responseIF.add("datos_ppv2.mkt2", FormaterUtils.formatearCadena("", 40));

        }

        String oriRspValue = FormaterUtils.formatearCadena("2", 1);
        responseIF.add("datos_ppv2.orirsp", oriRspValue);


        String rspExtReqValue = response.getResult().getCodError();

        if (rspExtReqValue.equals("0")) {

            responseIF.add("datos_ppv2.rspext", FormaterUtils.formatearNumero(rspExtReqValue, 4));
        } else {

            responseIF.add("datos_ppv2.rspext", "0666");
        }

        if (response.getResult().getErrMsg() != null) {

            String desExtValue = FormaterUtils.formatearCadena(response.getResult().getErrMsg(), 30);
            responseIF.add("datos_ppv2.desext", desExtValue);

        } else {
            responseIF.add("datos_ppv2.desext", FormaterUtils.formatearCadena("", 30));
        }

        String numPpvReqValue = requestIF.getValue("datos_ppv.numppv");
        responseIF.add("datos_ppv2.no_ope_ppv", numPpvReqValue);

        String noDocAutValue = FormaterUtils.formatearCadena("", 16);
        responseIF.add("datos_ppv2.no_doc_aut", noDocAutValue);

        if (response.getResult().getBucketBalancesOut() != null) {


            Long nroOpeTelcoLng = response.getResult().getBucketBalancesOut()[0].getOPERATION_ID();

            if (nroOpeTelcoLng > 0) {

                String noOpeTelcoValue = FormaterUtils.formatearCadena(String.valueOf(nroOpeTelcoLng), 16);
                responseIF.add("datos_ppv2.no_doc_telco", noOpeTelcoValue);
            } else {

                responseIF.add("datos_ppv2.no_doc_telco", FormaterUtils.formatearCadena("", 16));
            }

        } else {

            responseIF.add("datos_ppv2.no_doc_telco", FormaterUtils.formatearCadena("", 16));

        }

        if (response.getResult().getBucketBalancesOut() != null) {

            Long nroOpeTelcoLng = response.getResult().getBucketBalancesOut()[0].getOPERATION_ID();

            if (nroOpeTelcoLng > 0) {

                String noOpeTelcoValue = FormaterUtils.formatearCadena(String.valueOf(nroOpeTelcoLng), 16);
                responseIF.add("datos_ppv2.no_doc_telco", noOpeTelcoValue);
            } else {

                responseIF.add("datos_ppv2.no_doc_telco", FormaterUtils.formatearCadena("", 16));
            }

        } else {

            responseIF.add("datos_ppv2.no_doc_telco", FormaterUtils.formatearCadena("", 16));

        }

        String impTotalValue = FormaterUtils.formatearNumero("0", 6);
        responseIF.add("datos_ppv2.imp_total", impTotalValue);

        String numRegTotalValue = FormaterUtils.formatearNumero("0", 3);
        responseIF.add("datos_ppv2.num_reg_total", numRegTotalValue);

        String numRegEnviadoValue = FormaterUtils.formatearNumero("0", 3);
        responseIF.add("datos_ppv2.num_reg_enviado", numRegEnviadoValue);

        String denominacionValue = FormaterUtils.formatearNumero("0", 4);
        responseIF.add("datos_ppv2.denominacion", denominacionValue);

        String cantidadValue = FormaterUtils.formatearNumero("0", 6);
        responseIF.add("datos_ppv2.cantidad", cantidadValue);

        String fillerValue = FormaterUtils.formatearCadena("", 521);
        responseIF.add("datos_ppv2.filler", fillerValue);

        /**/

        String macReqValue = requestIF.getValue("mac");
        responseIF.add("mac", macReqValue);

        BRKLogger.msgDebug(null, Recarga.class.getSimpleName(), Constants.METHOD_GENERAR_TRAMA_RESPUESTA, " Internal Format de Respuesta = " + responseIF + "");

        try {

            Formatter formateador = formatterFactory.getFormatter(ID_FORMATEADOR_SALIDA);
            tramaRespuesta = formateador.getFrameFromInternalFormat(responseIF).toString();

            BRKLogger.msgDebug(null, Recarga.class.getSimpleName(), Constants.METHOD_RUN, "trama ISO a enviar = {" + tramaRespuesta + "}");

        } catch (FormatterException fe) {
            BRKLogger.msgError(null, Recarga.class.getSimpleName(), Constants.METHOD_RUN, "Formateo, FormatterException al formatear mensaje ISO", fe);
            throw fe;
        }

        return tramaRespuesta;
    }
}
