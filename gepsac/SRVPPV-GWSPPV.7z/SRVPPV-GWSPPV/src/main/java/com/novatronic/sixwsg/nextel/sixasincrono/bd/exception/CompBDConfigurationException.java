package com.novatronic.sixwsg.nextel.sixasincrono.bd.exception;

/**
 *
 * @author lgonzales
 */
public class CompBDConfigurationException extends RuntimeException{

    /**
     * 
     */
    private static final long serialVersionUID = 1L;

    public CompBDConfigurationException(Throwable cause) {
        super(cause);
    }

    public CompBDConfigurationException(String message, Throwable cause) {
        super(message, cause);
    }

    public CompBDConfigurationException(String message) {
        super(message);
    }

    public CompBDConfigurationException() {
    }
    
}
