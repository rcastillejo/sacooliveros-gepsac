/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.novatronic.sixwsg.nextel.sixasincrono.server.thread;

import com.novatronic.sixwsg.entel.proxyrs.ProxyFactory;
import com.novatronic.sixwsg.nextel.sixasincrono.util.KiwoxMessage;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;
import javax.ws.rs.core.MultivaluedHashMap;
import javax.ws.rs.core.MultivaluedMap;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 *
 * @author rcastillejo
 */
public class KiwoxSenderTest {

    private static final Logger log = LoggerFactory.getLogger(KiwoxSenderTest.class);
    private static Properties config;
    private static Properties configWithoutRetry;
    private static Properties configWithoutRetryWait;

    public KiwoxSenderTest() {
    }

    @BeforeClass
    public static void setUpClass() throws IOException {
        InputStream file;
        
        file = KiwoxSenderTest.class.getClassLoader().getResourceAsStream("broker.properties");
        config = new Properties();
        config.load(file);
        
        file = KiwoxSenderTest.class.getClassLoader().getResourceAsStream("brokerNoRetry.properties");
        configWithoutRetry = new Properties();
        configWithoutRetry.load(file);
        
        file = KiwoxSenderTest.class.getClassLoader().getResourceAsStream("brokerNoRetryWait.properties");
        configWithoutRetryWait = new Properties();
        configWithoutRetryWait.load(file);
        
        ProxyFactory.configure(config.getProperty("proxyrs.config"));
    }

    @AfterClass
    public static void tearDownClass() {
    }

    @Before
    public void setUp() {
    }

    @After
    public void tearDown() {
    }

    /**
     * Test of run method, of class KiwoxSender.
     */
    @Test
    public void testRun() throws Exception {
        log.debug("run");
        KiwoxSender instance;
        BlockingQueue<KiwoxMessage> queue;
        MultivaluedMap request;
        KiwoxMessage msgKiwox;
        

        request = new MultivaluedHashMap();
        queue = new LinkedBlockingQueue<KiwoxMessage>();
        instance = new KiwoxSender(queue, config);

        request.addFirst("msisdn", "56994791017");
        request.addFirst("product", "rec001");
        request.addFirst("paymentType", "3.27");
        request.addFirst("retailer", "visa");
        request.addFirst("branch", "rxt001");
        request.addFirst("purchaseValue", "txp001");

        msgKiwox = new KiwoxMessage(Thread.currentThread().getName(), request);
        queue.offer(msgKiwox);
        
        Thread t = new Thread(instance);
        t.start();
        
        while(!msgKiwox.isFinish()){
            log.debug("Mensaje enviando ... ["+msgKiwox+"]");
            Thread.sleep(500);
        }
        
        log.debug("Estado del Mensaje ["+msgKiwox+"]");        
        
    }

    @Test
    public void testRunWithoutRetry() throws Exception {
        log.debug("testRunWithoutRetry");
        KiwoxSender instance;
        BlockingQueue<KiwoxMessage> queue;  
        
 
        queue = new LinkedBlockingQueue<KiwoxMessage>();
        instance = new KiwoxSender(queue, configWithoutRetry);
 
        
        Assert.assertEquals(0, instance.getRetry());
        Assert.assertEquals(0, instance.getRetryWait());
        
        log.debug("Estado del Mensaje ["+instance+"]"); 
    }

    @Test
    public void testRunWithoutRetryWait() throws Exception {
        log.debug("testRunWithoutRetry");
        KiwoxSender instance;
        BlockingQueue<KiwoxMessage> queue;  
        
 
        queue = new LinkedBlockingQueue<KiwoxMessage>();
        instance = new KiwoxSender(queue, configWithoutRetryWait);
 
        
        Assert.assertNotEquals(0, instance.getRetry());
        Assert.assertEquals(1000, instance.getRetryWait());
        
        log.debug("Estado del Mensaje ["+instance+"]"); 
    }
}
